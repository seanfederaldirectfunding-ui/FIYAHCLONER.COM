#!/bin/bash

# FIYAHCLONER AI NEXUS - Deployment Verification Script
# This script verifies all files and configurations are ready for deployment

echo "🔥 FIYAHCLONER AI NEXUS - Deployment Verification"
echo "=================================================="
echo ""

# Color codes
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

ERRORS=0
WARNINGS=0

# Function to check if file exists
check_file() {
    if [ -f "$1" ]; then
        echo -e "${GREEN}✓${NC} $1"
    else
        echo -e "${RED}✗${NC} $1 - MISSING"
        ((ERRORS++))
    fi
}

# Function to check if directory exists
check_dir() {
    if [ -d "$1" ]; then
        echo -e "${GREEN}✓${NC} $1/"
    else
        echo -e "${RED}✗${NC} $1/ - MISSING"
        ((ERRORS++))
    fi
}

echo "📁 Checking Core Configuration Files..."
check_file "package.json"
check_file "next.config.mjs"
check_file "tsconfig.json"
check_file "netlify.toml"
check_file ".gitignore"
check_file ".env.example"
echo ""

echo "📄 Checking Documentation Files..."
check_file "README.md"
check_file "DEPLOYMENT.md"
check_file "QUICKSTART.md"
check_file "PRE_DEPLOYMENT_CHECKLIST.md"
check_file "TROUBLESHOOTING.md"
check_file "API_DOCUMENTATION.md"
check_file "GOOGLE_AI_INTEGRATION.md"
check_file "STRIPE_SETUP.md"
check_file "FINAL_VERIFICATION_REPORT.md"
echo ""

echo "🎨 Checking App Structure..."
check_dir "app"
check_file "app/layout.tsx"
check_file "app/page.tsx"
check_file "app/globals.css"
check_dir "app/api"
check_dir "app/admin"
check_dir "app/pricing"
check_dir "app/handyman"
echo ""

echo "🔌 Checking API Routes..."
check_file "app/api/generate/route.ts"
check_file "app/api/admin/login/route.ts"
check_file "app/api/admin/verify/route.ts"
check_file "app/api/google-ai/image/route.ts"
check_file "app/api/google-ai/video/route.ts"
check_file "app/api/google-ai/voice/route.ts"
echo ""

echo "🧩 Checking Components..."
check_dir "components"
check_file "components/index.ts"
check_file "components/header.tsx"
check_file "components/hero.tsx"
check_file "components/universal-ai-maker.tsx"
check_file "components/page-master.tsx"
check_file "components/google-ai-showcase.tsx"
check_file "components/ai-capabilities.tsx"
check_file "components/admin-login.tsx"
check_file "components/admin-dashboard.tsx"
check_file "components/handyman-dashboard.tsx"
check_file "components/pricing-cards.tsx"
check_file "components/checkout.tsx"
check_dir "components/ui"
check_dir "components/handyman"
echo ""

echo "📚 Checking Library Files..."
check_dir "lib"
check_file "lib/index.ts"
check_file "lib/utils.ts"
check_file "lib/stripe.ts"
check_file "lib/products.ts"
check_file "lib/google-ai.ts"
echo ""

echo "⚙️ Checking Actions..."
check_dir "app/actions"
check_file "app/actions/stripe.ts"
echo ""

echo "🔍 Checking Environment Variables..."
if [ -f ".env.example" ]; then
    echo -e "${GREEN}✓${NC} .env.example exists"
    
    # Check for required variables in .env.example
    required_vars=("STRIPE_SECRET_KEY" "STRIPE_PUBLISHABLE_KEY" "NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY")
    
    for var in "${required_vars[@]}"; do
        if grep -q "$var" .env.example; then
            echo -e "${GREEN}  ✓${NC} $var documented"
        else
            echo -e "${YELLOW}  ⚠${NC} $var not documented"
            ((WARNINGS++))
        fi
    done
else
    echo -e "${RED}✗${NC} .env.example missing"
    ((ERRORS++))
fi
echo ""

echo "📦 Checking Package Dependencies..."
if [ -f "package.json" ]; then
    required_deps=("next" "react" "stripe" "lucide-react" "tailwindcss")
    
    for dep in "${required_deps[@]}"; do
        if grep -q "\"$dep\"" package.json; then
            echo -e "${GREEN}  ✓${NC} $dep"
        else
            echo -e "${RED}  ✗${NC} $dep - MISSING"
            ((ERRORS++))
        fi
    done
fi
echo ""

echo "=================================================="
echo "📊 Verification Summary"
echo "=================================================="

if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
    echo -e "${GREEN}✓ All checks passed! Ready for deployment.${NC}"
    echo ""
    echo "Next steps:"
    echo "1. Review PRE_DEPLOYMENT_CHECKLIST.md"
    echo "2. Set up environment variables"
    echo "3. Deploy to Netlify or your preferred platform"
    exit 0
elif [ $ERRORS -eq 0 ]; then
    echo -e "${YELLOW}⚠ $WARNINGS warning(s) found.${NC}"
    echo "Review warnings above. Deployment may proceed with caution."
    exit 0
else
    echo -e "${RED}✗ $ERRORS error(s) found.${NC}"
    echo -e "${YELLOW}⚠ $WARNINGS warning(s) found.${NC}"
    echo ""
    echo "Please fix errors before deploying."
    exit 1
fi
