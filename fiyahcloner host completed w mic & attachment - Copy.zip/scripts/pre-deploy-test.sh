#!/bin/bash

# FIYAHCLONER AI NEXUS - Pre-Deployment Test Script
# Run this script before deploying to ensure 100% readiness

set -e

echo "🚀 FIYAHCLONER AI NEXUS - Pre-Deployment Test"
echo "=============================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test counter
TESTS_PASSED=0
TESTS_FAILED=0

# Function to print test result
print_result() {
    if [ $1 -eq 0 ]; then
        echo -e "${GREEN}✅ PASS${NC} - $2"
        ((TESTS_PASSED++))
    else
        echo -e "${RED}❌ FAIL${NC} - $2"
        ((TESTS_FAILED++))
    fi
}

echo "1️⃣  Checking Node.js version..."
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -ge 18 ]; then
    print_result 0 "Node.js version ($NODE_VERSION) is compatible"
else
    print_result 1 "Node.js version ($NODE_VERSION) is too old (need 18+)"
fi

echo ""
echo "2️⃣  Installing dependencies..."
if npm install --silent; then
    print_result 0 "Dependencies installed successfully"
else
    print_result 1 "Dependency installation failed"
fi

echo ""
echo "3️⃣  Running TypeScript type check..."
if npm run type-check; then
    print_result 0 "TypeScript compilation successful"
else
    print_result 1 "TypeScript errors found"
fi

echo ""
echo "4️⃣  Running ESLint..."
if npm run lint; then
    print_result 0 "Code quality check passed"
else
    print_result 1 "Linting errors found"
fi

echo ""
echo "5️⃣  Building production bundle..."
if npm run build; then
    print_result 0 "Production build successful"
else
    print_result 1 "Build failed"
fi

echo ""
echo "6️⃣  Checking required files..."
REQUIRED_FILES=(
    "package.json"
    "next.config.mjs"
    "tsconfig.json"
    ".env.example"
    "netlify.toml"
    "vercel.json"
    "README.md"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        print_result 0 "File exists: $file"
    else
        print_result 1 "Missing file: $file"
    fi
done

echo ""
echo "7️⃣  Checking critical directories..."
REQUIRED_DIRS=(
    "app"
    "components"
    "lib"
    "public"
)

for dir in "${REQUIRED_DIRS[@]}"; do
    if [ -d "$dir" ]; then
        print_result 0 "Directory exists: $dir"
    else
        print_result 1 "Missing directory: $dir"
    fi
done

echo ""
echo "8️⃣  Checking API routes..."
API_ROUTES=(
    "app/api/admin/login/route.ts"
    "app/api/ai-backend/assistance/route.ts"
    "app/api/ai-backend/analyze/route.ts"
    "app/api/ai-backend/generate/route.ts"
    "app/api/genius/chat/route.ts"
)

for route in "${API_ROUTES[@]}"; do
    if [ -f "$route" ]; then
        print_result 0 "API route exists: $route"
    else
        print_result 1 "Missing API route: $route"
    fi
done

echo ""
echo "9️⃣  Checking environment variables..."
if [ -f ".env.example" ]; then
    print_result 0 ".env.example file exists"
    echo "   Remember to set these variables in production:"
    grep -E "^[A-Z_]+=" .env.example | sed 's/=.*//' | sed 's/^/   - /'
else
    print_result 1 ".env.example file missing"
fi

echo ""
echo "=============================================="
echo "📊 TEST SUMMARY"
echo "=============================================="
echo -e "${GREEN}Passed: $TESTS_PASSED${NC}"
echo -e "${RED}Failed: $TESTS_FAILED${NC}"
echo ""

if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "${GREEN}🎉 ALL TESTS PASSED!${NC}"
    echo -e "${GREEN}✅ System is 100% ready for deployment!${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. Set environment variables on your hosting platform"
    echo "  2. Run: netlify deploy --prod  (for Netlify)"
    echo "  3. Or run: vercel --prod  (for Vercel)"
    echo ""
    exit 0
else
    echo -e "${RED}⚠️  SOME TESTS FAILED!${NC}"
    echo "Please fix the issues above before deploying."
    echo ""
    exit 1
fi
