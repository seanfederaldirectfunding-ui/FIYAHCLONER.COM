export interface Product {
  id: string
  name: string
  description: string
  priceInCents: number
  credits: number // Added credits field for credit system
  features: string[]
  popular?: boolean
}

// This is the source of truth for all products.
// All UI to display products should pull from this array.
// IDs passed to the checkout session should be the same as IDs from this array.
export const PRODUCTS: Product[] = [
  {
    id: "starter-plan",
    name: "Starter",
    description: "Perfect for individuals and small projects",
    priceInCents: 2999, // Updated to $29.99
    credits: 1000, // 1,000 credits per month
    features: [
      "1,000 Credits/Month",
      "Access to 10 AI Models",
      "Universal AI Maker",
      "Image Generation",
      "Basic Video Generation",
      "Code Generation",
      "Page Master Tool",
      "Email Support",
    ],
  },
  {
    id: "pro-plan",
    name: "Professional",
    description: "For professionals and growing businesses",
    priceInCents: 4999, // Updated to $49.99
    credits: 5000, // 5,000 credits per month
    popular: true,
    features: [
      "5,000 Credits/Month",
      "Access to 25+ AI Models",
      "Unlimited AI Maker Access",
      "Advanced Image Generation",
      "Enhanced Video Generation",
      "Voice & Music Generation",
      "Priority Processing",
      "Digital Handyman Tools",
      "Priority Support",
      "API Access",
    ],
  },
  {
    id: "enterprise-plan",
    name: "Enterprise",
    description: "For large teams and organizations",
    priceInCents: 9999, // Updated to $99.99
    credits: 20000, // 20,000 credits per month
    features: [
      "20,000 Credits/Month",
      "Unlimited AI Model Access",
      "Premium Everything",
      "Custom AI Model Training",
      "Dedicated Account Manager",
      "White-label Options",
      "Advanced Analytics",
      "SLA Guarantee",
      "24/7 Premium Support",
      "Custom Integrations",
    ],
  },
]
