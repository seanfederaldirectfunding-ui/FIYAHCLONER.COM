// Google AI Studio Integration
// This file provides utilities for integrating Google AI Studio resources
// NOTE: All API calls should be made server-side only for security

export const GOOGLE_AI_MODELS = {
  // Gemini Models
  GEMINI_2_5_PRO: {
    id: "gemini-2.5-pro",
    name: "Gemini 2.5 Pro",
    description: "Most capable model for complex reasoning and multimodal tasks",
    capabilities: ["text", "image", "video", "audio", "code"],
    maxTokens: 2000000,
  },
  GEMINI_2_0_FLASH: {
    id: "gemini-2.0-flash",
    name: "Gemini 2.0 Flash",
    description: "Fastest model optimized for speed and efficiency",
    capabilities: ["text", "image", "video", "audio", "code"],
    maxTokens: 1000000,
  },
  GEMINI_2_0_FLASH_THINKING: {
    id: "gemini-2.0-flash-thinking",
    name: "Gemini 2.0 Flash Thinking",
    description: "Enhanced reasoning with visible thought process",
    capabilities: ["text", "reasoning", "code"],
    maxTokens: 32000,
  },

  // Image Generation
  IMAGEN_3: {
    id: "imagen-3",
    name: "Imagen 3",
    description: "Photorealistic image generation with exceptional quality",
    capabilities: ["image-generation"],
    maxResolution: "2048x2048",
  },

  // Video Generation
  VEO_2: {
    id: "veo-2",
    name: "Veo 2",
    description: "Cinematic video generation with realistic physics",
    capabilities: ["video-generation"],
    maxDuration: "60s",
    maxResolution: "4K",
  },

  // Audio & Voice
  GEMINI_TTS: {
    id: "gemini-tts",
    name: "Gemini Text-to-Speech",
    description: "Natural, hyper-realistic voice synthesis",
    capabilities: ["text-to-speech"],
    voices: ["male", "female", "neutral"],
  },

  GEMINI_NATIVE_AUDIO: {
    id: "gemini-native-audio",
    name: "Gemini Native Audio",
    description: "Direct audio understanding and generation",
    capabilities: ["audio-understanding", "audio-generation"],
  },
}

export const GOOGLE_AI_CAPABILITIES = {
  multimodal: {
    name: "Multimodal Understanding",
    description: "Process text, images, video, and audio simultaneously",
    models: ["gemini-2.5-pro", "gemini-2.0-flash"],
  },
  reasoning: {
    name: "Advanced Reasoning",
    description: "Complex problem-solving with visible thought process",
    models: ["gemini-2.5-pro", "gemini-2.0-flash-thinking"],
  },
  imageGeneration: {
    name: "Photorealistic Images",
    description: "Generate high-quality, realistic images",
    models: ["imagen-3"],
  },
  videoGeneration: {
    name: "Cinematic Video",
    description: "Create professional-quality video content",
    models: ["veo-2"],
  },
  voiceSynthesis: {
    name: "Natural Voice",
    description: "Hyper-realistic text-to-speech",
    models: ["gemini-tts", "gemini-native-audio"],
  },
  codeGeneration: {
    name: "Code Generation",
    description: "Advanced coding assistance and generation",
    models: ["gemini-2.5-pro", "gemini-2.0-flash"],
  },
}

// Helper function to get model by capability
export function getModelsByCapability(capability: keyof typeof GOOGLE_AI_CAPABILITIES) {
  return GOOGLE_AI_CAPABILITIES[capability]
}

// Helper function to check if a model supports a capability
export function modelSupportsCapability(modelId: string, capability: string): boolean {
  const model = Object.values(GOOGLE_AI_MODELS).find((m) => m.id === modelId)
  return model?.capabilities.includes(capability) ?? false
}

// API configuration helper - SERVER-SIDE ONLY
// This function should only be called from API routes or server components
export function getGoogleAIConfig() {
  // Only access server-side environment variable
  const apiKey = process.env.GOOGLE_AI_API_KEY

  if (!apiKey) {
    console.warn("[v0] Google AI API key not configured. Add GOOGLE_AI_API_KEY to environment variables.")
  }

  return {
    apiKey,
    baseUrl: "https://generativelanguage.googleapis.com/v1beta",
    models: GOOGLE_AI_MODELS,
  }
}
