import "server-only"

import Stripe from "stripe"

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-12-18.acacia",
  typescript: true,
})

// Stripe account ID for connected account operations
export const STRIPE_ACCOUNT_ID = "acct_1032D82eZvKYlo2C"
