# FIYAHCLONER AI NEXUS

**The Most Advanced AI Platform** - Combining the power of 14 elite AI models working collaboratively to create anything you need, plus Genius - your empathetic AI assistant.

![FIYAHCLONER](https://img.shields.io/badge/FIYAHCLONER-AI%20NEXUS-purple?style=for-the-badge)
![Next.js](https://img.shields.io/badge/Next.js-16.0-black?style=for-the-badge&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0-blue?style=for-the-badge&logo=typescript)
![Stripe](https://img.shields.io/badge/Stripe-Integrated-green?style=for-the-badge&logo=stripe)

## Features

### 🤖 Universal AI Maker
14 powerful AI models collaborate in real-time to produce the best results:
- **GPT-5** - Advanced reasoning & code generation
- **Claude 3.5 Sonnet** - Creative writing & analysis
- **Gemini 2.5 Pro** - 2M token context window
- **Gemini 2.0 Flash** - Fastest multimodal AI
- **DeepSeek R1** - Mathematical reasoning
- **Grok 2** - Real-time information
- **Llama 3.3** - Open-source power
- **Flux Pro** - Photorealistic images
- **Imagen 3** - Google's image generation
- **Sora** - Cinematic video generation
- **Veo 2** - 4K video generation
- **ElevenLabs** - Natural voice synthesis
- **Gemini TTS** - Hyper-realistic audio
- **Udio** - Professional music creation

### ✨ Genius AI Assistant
Your empathetic voice-enabled customer service AI:
- **Voice Conversation** - Speak naturally using microphone & speaker
- **Emotional Intelligence** - Understands and responds with empathy
- **Human-like Voice** - Natural, engaging speech synthesis
- **Smart Notepad** - Genius can write important notes for you
- **Marketing Language** - Persado-inspired emotional engagement
- **Real-time Chat** - Instant text and voice responses
- **Customer Service** - Professional, caring assistance

### 🎯 Page Master
- Analyze any website structure
- Navigate and learn page layouts
- Generate step-by-step tutorials
- Visual element identification
- Automated task guidance

### 🔧 Digital Handyman
Complete toolkit for developers:
- **Code Analyzer** - Deep syntax & security scanning
- **Website Health Check** - Performance, SEO, accessibility
- **Deployment Expert** - One-click deploy to any platform
- **Migration Tool** - Seamless hosting transfers
- **AI Error Fixer** - Instant problem solving

### 💳 Stripe Integration
- Secure payment processing
- Multiple pricing tiers (Starter $29, Professional $99, Enterprise $299)
- Embedded checkout experience
- Subscription management ready
- Connected account: `acct_1032D82eZvKYlo2C`

### 🔐 Admin Panel
- Master admin authentication
- System statistics dashboard
- User management
- Real-time monitoring

## Quick Start

1. **Clone the repository**
   \`\`\`bash
   git clone <your-repo-url>
   cd fiyahcloner
   \`\`\`

2. **Install dependencies**
   \`\`\`bash
   npm install
   \`\`\`

3. **Set up environment variables**
   \`\`\`bash
   cp .env.example .env.local
   \`\`\`
   
   Edit `.env.local` and add your keys:
   \`\`\`env
   STRIPE_SECRET_KEY=sk_test_...
   STRIPE_PUBLISHABLE_KEY=pk_test_...
   NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
   OPENAI_API_KEY=sk-...
   ANTHROPIC_API_KEY=sk-ant-...
   XAI_API_KEY=xai-...
   GROQ_API_KEY=gsk_...
   GOOGLE_AI_API_KEY=your_google_ai_key
   \`\`\`

4. **Run development server**
   \`\`\`bash
   npm run dev
   \`\`\`

5. **Open your browser**
   \`\`\`
   http://localhost:3000
   \`\`\`

## Project Structure

\`\`\`
fiyahcloner/
├── app/
│   ├── page.tsx                 # Homepage
│   ├── layout.tsx               # Root layout
│   ├── genius/                  # Genius AI Assistant
│   ├── admin/                   # Admin panel
│   ├── handyman/                # Digital Handyman tools
│   ├── pricing/                 # Pricing & checkout
│   ├── api/
│   │   ├── genius/              # Genius chat API
│   │   ├── admin/               # Admin authentication
│   │   ├── google-ai/           # Google AI endpoints
│   │   └── generate/            # AI generation
│   └── actions/                 # Server actions
│       └── stripe.ts            # Stripe checkout
├── components/
│   ├── genius-assistant.tsx     # Genius AI interface
│   ├── universal-ai-maker.tsx   # Main AI interface
│   ├── page-master.tsx          # Website analyzer
│   ├── google-ai-showcase.tsx   # Google AI features
│   ├── admin-login.tsx          # Admin authentication
│   ├── handyman/                # Handyman tools
│   └── ui/                      # UI components
├── lib/
│   ├── stripe.ts                # Stripe client
│   ├── products.ts              # Product definitions
│   ├── google-ai.ts             # Google AI config
│   └── utils.ts                 # Utilities
├── netlify.toml                 # Netlify config
├── DEPLOYMENT.md                # Deployment guide
├── GOOGLE_AI_INTEGRATION.md     # Google AI setup
└── README.md                    # This file
\`\`\`

## Features Overview

### Genius AI Assistant
Your empathetic voice-enabled AI companion:
1. **Voice Chat:** Click microphone to start speaking
2. **Natural Conversation:** Genius responds with human-like voice
3. **Emotional Intelligence:** Understands feelings and responds with empathy
4. **Smart Notepad:** Genius writes important information for you
5. **Text Chat:** Type messages when voice isn't convenient
6. **Customer Service:** Professional assistance with a caring touch

**Genius Capabilities:**
- Clones ChatGPT's advanced conversational abilities
- Uses Persado-inspired emotional language for engagement
- Provides empathetic, understanding responses
- Writes to notepad when you need to remember something
- Speaks with natural, human-like voice synthesis
- Maintains context throughout conversations

### Universal AI Maker
The core of FIYAHCLONER - 14 AI models working together:
- Real-time collaboration visualization
- Automatic model selection based on task
- Streaming responses for instant feedback
- Multi-modal output (text, images, video, audio)
- Google AI Studio integration (5 models)

### Page Master
Navigate and learn any website:
1. Enter target URL
2. Describe your goal
3. AI analyzes page structure
4. Get step-by-step instructions
5. Visual element highlighting

### Digital Handyman
Professional developer toolkit:
- **Code Analyzer:** Syntax, security, performance checks
- **Health Check:** SEO, speed, accessibility scores
- **Deployment:** Vercel, Netlify, AWS, Azure support
- **Migration:** Zero-downtime hosting transfers
- **Error Fixer:** AI-powered debugging

## API Routes

### Genius AI
- `POST /api/genius/chat` - Voice & text conversation

### Google AI
- `POST /api/google-ai/image` - Imagen 3 generation
- `POST /api/google-ai/video` - Veo 2 video creation
- `POST /api/google-ai/voice` - Gemini TTS synthesis

### Admin Authentication
- `POST /api/admin/login` - Admin login
- `POST /api/admin/verify` - Token verification

### AI Generation
- `POST /api/generate` - Universal AI generation

### Stripe
- Server Action: `startCheckoutSession(productId)` - Create checkout

## Tech Stack

- **Framework:** Next.js 16.0 (App Router)
- **Language:** TypeScript 5
- **Styling:** Tailwind CSS 4
- **UI Components:** Radix UI + shadcn/ui
- **AI SDK:** Vercel AI SDK 5
- **Voice:** Web Speech API + Speech Synthesis
- **Payments:** Stripe
- **Deployment:** Netlify
- **Authentication:** Custom JWT-based

## Development

### Run locally
\`\`\`bash
npm run dev
\`\`\`

### Build for production
\`\`\`bash
npm run build
npm start
\`\`\`

### Lint code
\`\`\`bash
npm run lint
\`\`\`

## Security

- Password hashing with SHA-256
- Secure session tokens
- Environment variable protection
- Input validation on all forms
- HTTPS enforced in production
- Rate limiting ready

## Performance

- Server-side rendering (SSR)
- Static generation where possible
- Image optimization
- Code splitting
- Lazy loading components
- Streaming responses

## Browser Support

- Chrome (latest) - **Recommended for voice features**
- Firefox (latest)
- Safari (latest)
- Edge (latest) - **Recommended for voice features**

**Note:** Voice features (Genius AI Assistant) work best in Chrome and Edge due to Web Speech API support.

## Deployment

### Deploy to Netlify

See [DEPLOYMENT.md](./DEPLOYMENT.md) for complete deployment instructions.

**Quick Deploy:**
\`\`\`bash
# Install Netlify CLI
npm install -g netlify-cli

# Login
netlify login

# Deploy
netlify deploy --prod
\`\`\`

### Environment Variables Required

\`\`\`env
# Stripe (Required for payments)
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...

# Optional AI API Keys
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
XAI_API_KEY=xai-...
GROQ_API_KEY=gsk_...
GOOGLE_AI_API_KEY=your_google_ai_key
\`\`\`

## Admin Access

Master admin credentials:
- **Email:** `sean.federaldirectfunding@gmail.com`
- **Password:** `Rasta4iva`

Access the admin panel at: `/admin`

## Contributing

This is a private project. For access or questions, contact:
**sean.federaldirectfunding@gmail.com**

## License

Proprietary - All rights reserved

## Support

For technical support or questions:
- Email: sean.federaldirectfunding@gmail.com
- Admin Panel: `/admin`

## Roadmap

- [x] Universal AI Maker with 14 models
- [x] Genius AI Assistant with voice
- [x] Google AI Studio integration
- [x] Page Master website analyzer
- [x] Digital Handyman toolkit
- [x] Stripe payment integration
- [x] Admin authentication
- [ ] Real AI model API integration
- [ ] Database for user management
- [ ] Webhook handlers for Stripe
- [ ] Advanced analytics dashboard
- [ ] API rate limiting
- [ ] Multi-language support
- [ ] Mobile app version
- [ ] ElevenLabs voice integration for Genius

---

**Built with ❤️ by FIYAHCLONER Team**

Powered by Next.js, Stripe, Google AI Studio, and cutting-edge AI technology.
