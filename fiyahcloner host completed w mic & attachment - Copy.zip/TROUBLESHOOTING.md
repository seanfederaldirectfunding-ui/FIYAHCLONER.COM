# FIYAHCLONER AI NEXUS - Troubleshooting Guide

## Common Issues and Solutions

### Build Errors

#### Issue: "Module not found" errors
**Solution:**
\`\`\`bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
\`\`\`

#### Issue: TypeScript errors during build
**Solution:**
The project is configured with `ignoreBuildErrors: true` in next.config.mjs for flexibility. However, you can check types manually:
\`\`\`bash
npm run type-check
\`\`\`

### Deployment Issues

#### Issue: Netlify build fails
**Solution:**
1. Check build logs for specific error
2. Verify Node version (should be 18+)
3. Ensure all dependencies are in package.json
4. Check netlify.toml configuration

#### Issue: Environment variables not working
**Solution:**
1. Verify variables are added in Netlify dashboard
2. Check variable names match exactly (case-sensitive)
3. Redeploy after adding variables
4. For client-side variables, ensure they start with `NEXT_PUBLIC_`

### Stripe Integration Issues

#### Issue: Checkout not loading
**Solution:**
1. Verify `STRIPE_PUBLISHABLE_KEY` and `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` are set
2. Check browser console for errors
3. Ensure Stripe account is active
4. Verify product IDs in lib/products.ts match your Stripe products

#### Issue: "Invalid API key" error
**Solution:**
1. Confirm you're using the correct key format (sk_test_... or sk_live_...)
2. Check for extra spaces in environment variable
3. Verify key is from correct Stripe account
4. Regenerate key if necessary

### Admin Login Issues

#### Issue: Cannot log in to admin panel
**Solution:**
1. Verify credentials:
   - Email: sean.federaldirectfunding@gmail.com
   - Password: Rasta4iva
2. Clear browser cache and cookies
3. Check browser console for errors
4. Verify API route is accessible: /api/admin/login

#### Issue: "Invalid token" after login
**Solution:**
1. Clear localStorage: `localStorage.clear()`
2. Log in again
3. Check if token expiration is too short

### Google AI Integration Issues

#### Issue: Google AI features not working
**Solution:**
1. Verify `GOOGLE_AI_API_KEY` is set
2. Check API key has correct permissions in Google Cloud Console
3. Ensure billing is enabled for Google AI Studio
4. Check API quotas and limits

### Performance Issues

#### Issue: Slow page load times
**Solution:**
1. Enable image optimization in next.config.mjs
2. Implement lazy loading for heavy components
3. Check network tab for large assets
4. Consider CDN for static assets

#### Issue: High memory usage during build
**Solution:**
1. Increase Node memory: `NODE_OPTIONS=--max-old-space-size=4096 npm run build`
2. Check for memory leaks in components
3. Optimize large dependencies

### UI/UX Issues

#### Issue: Components not rendering correctly
**Solution:**
1. Check browser console for errors
2. Verify all required UI components are installed
3. Clear browser cache
4. Check for CSS conflicts

#### Issue: Mobile layout broken
**Solution:**
1. Test responsive breakpoints
2. Check Tailwind classes are correct
3. Verify viewport meta tag in layout.tsx
4. Test on actual devices, not just browser DevTools

### API Route Issues

#### Issue: API routes returning 404
**Solution:**
1. Verify route file structure matches Next.js conventions
2. Check file naming (route.ts, not route.tsx)
3. Ensure proper export: `export async function POST(request: NextRequest)`
4. Restart development server

#### Issue: CORS errors
**Solution:**
Add CORS headers to API routes:
\`\`\`typescript
return NextResponse.json(data, {
  headers: {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  },
})
\`\`\`

## Getting Help

If you encounter issues not covered here:

1. **Check Documentation:**
   - README.md
   - DEPLOYMENT.md
   - GOOGLE_AI_INTEGRATION.md
   - STRIPE_SETUP.md

2. **Review Logs:**
   - Browser console (F12)
   - Netlify build logs
   - Server logs (if applicable)

3. **Common Commands:**
   \`\`\`bash
   # Clear Next.js cache
   rm -rf .next
   
   # Reinstall dependencies
   rm -rf node_modules && npm install
   
   # Check for outdated packages
   npm outdated
   
   # Update packages
   npm update
   \`\`\`

4. **Debug Mode:**
   Add console.log statements with [v0] prefix:
   \`\`\`typescript
   console.log("[v0] Debug info:", data)
   \`\`\`

## Emergency Rollback

If deployment breaks production:

### Netlify:
1. Go to Deploys tab
2. Find last working deployment
3. Click "Publish deploy"

### Vercel:
\`\`\`bash
vercel rollback
\`\`\`

## Contact Support

For critical issues:
- Email: sean.federaldirectfunding@gmail.com
- Check GitHub Issues (if repository is public)
- Review Next.js documentation: https://nextjs.org/docs

---

**Last Updated:** January 2025
