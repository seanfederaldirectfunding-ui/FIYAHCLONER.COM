"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, LogOut, Users, Activity, Database, Settings, BarChart3, Lock, CheckCircle2, Zap } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function AdminDashboard() {
  const [adminEmail, setAdminEmail] = useState("")
  const [loginTime, setLoginTime] = useState("")
  const { toast } = useToast()

  useEffect(() => {
    const email = localStorage.getItem("admin_email")
    const time = localStorage.getItem("admin_login_time")
    if (email) setAdminEmail(email)
    if (time) {
      const date = new Date(time)
      setLoginTime(date.toLocaleString())
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("admin_token")
    localStorage.removeItem("admin_email")
    localStorage.removeItem("admin_login_time")

    toast({
      title: "Logged Out",
      description: "You have been successfully logged out",
    })

    window.location.reload()
  }

  const stats = [
    { label: "Total Users", value: "1,247", icon: Users, color: "text-blue-500" },
    { label: "Active Sessions", value: "892", icon: Activity, color: "text-green-500" },
    { label: "Database Size", value: "45.2 GB", icon: Database, color: "text-purple-500" },
    { label: "API Requests", value: "2.4M", icon: Zap, color: "text-yellow-500" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      {/* Header */}
      <header className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Shield className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Master Admin Dashboard</h1>
                <p className="text-xs text-muted-foreground">FIYAHCLONER AI NEXUS</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium">{adminEmail}</p>
                <p className="text-xs text-muted-foreground">Logged in: {loginTime}</p>
              </div>
              <Button onClick={handleLogout} variant="outline" className="gap-2 bg-transparent">
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container px-4 py-8">
        {/* Welcome Banner */}
        <Card className="p-6 mb-8 bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-primary/20">
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-full bg-primary/20 flex items-center justify-center">
              <CheckCircle2 className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-1">Welcome Back, Master Admin</h2>
              <p className="text-muted-foreground">You have full access to all system controls and configurations</p>
            </div>
          </div>
        </Card>

        {/* Stats Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center ${stat.color}`}>
                  <stat.icon className="h-6 w-6" />
                </div>
                <Badge variant="secondary">Live</Badge>
              </div>
              <p className="text-3xl font-bold mb-1">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </Card>
          ))}
        </div>

        {/* Admin Controls */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
            <div className="h-12 w-12 rounded-lg bg-blue-500/10 flex items-center justify-center mb-4">
              <Users className="h-6 w-6 text-blue-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">User Management</h3>
            <p className="text-sm text-muted-foreground mb-4">Manage user accounts, permissions, and access levels</p>
            <Button variant="outline" className="w-full bg-transparent">
              Manage Users
            </Button>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
            <div className="h-12 w-12 rounded-lg bg-green-500/10 flex items-center justify-center mb-4">
              <Activity className="h-6 w-6 text-green-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">System Monitor</h3>
            <p className="text-sm text-muted-foreground mb-4">View real-time system performance and health metrics</p>
            <Button variant="outline" className="w-full bg-transparent">
              View Metrics
            </Button>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
            <div className="h-12 w-12 rounded-lg bg-purple-500/10 flex items-center justify-center mb-4">
              <Database className="h-6 w-6 text-purple-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Database Control</h3>
            <p className="text-sm text-muted-foreground mb-4">Manage databases, backups, and data integrity</p>
            <Button variant="outline" className="w-full bg-transparent">
              Manage Database
            </Button>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
            <div className="h-12 w-12 rounded-lg bg-yellow-500/10 flex items-center justify-center mb-4">
              <BarChart3 className="h-6 w-6 text-yellow-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Analytics</h3>
            <p className="text-sm text-muted-foreground mb-4">View detailed analytics and usage reports</p>
            <Button variant="outline" className="w-full bg-transparent">
              View Analytics
            </Button>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
            <div className="h-12 w-12 rounded-lg bg-red-500/10 flex items-center justify-center mb-4">
              <Lock className="h-6 w-6 text-red-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Security Settings</h3>
            <p className="text-sm text-muted-foreground mb-4">Configure security policies and access controls</p>
            <Button variant="outline" className="w-full bg-transparent">
              Security Settings
            </Button>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
            <div className="h-12 w-12 rounded-lg bg-indigo-500/10 flex items-center justify-center mb-4">
              <Settings className="h-6 w-6 text-indigo-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">System Settings</h3>
            <p className="text-sm text-muted-foreground mb-4">Configure global system settings and preferences</p>
            <Button variant="outline" className="w-full bg-transparent">
              System Settings
            </Button>
          </Card>
        </div>

        {/* System Status */}
        <Card className="p-6 mt-8">
          <h3 className="text-lg font-semibold mb-4">System Status</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">API Services</span>
              <Badge className="bg-green-500">Operational</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Database Connection</span>
              <Badge className="bg-green-500">Connected</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">AI Models</span>
              <Badge className="bg-green-500">Active</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Storage</span>
              <Badge className="bg-yellow-500">78% Used</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Backup Status</span>
              <Badge className="bg-green-500">Up to Date</Badge>
            </div>
          </div>
        </Card>
      </main>
    </div>
  )
}
