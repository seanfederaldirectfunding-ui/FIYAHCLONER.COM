"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Globe, Zap, Search, Smartphone, Link2, Shield, TrendingUp } from "lucide-react"

interface HealthMetric {
  name: string
  score: number
  status: "excellent" | "good" | "fair" | "poor"
  details: string
  icon: React.ReactNode
}

export function WebsiteHealthCheck() {
  const [url, setUrl] = useState("")
  const [checking, setChecking] = useState(false)
  const [metrics, setMetrics] = useState<HealthMetric[]>([])
  const [overallScore, setOverallScore] = useState(0)

  const checkHealth = async () => {
    setChecking(true)

    // Simulate health check
    await new Promise((resolve) => setTimeout(resolve, 3000))

    const mockMetrics: HealthMetric[] = [
      {
        name: "Performance",
        score: 92,
        status: "excellent",
        details: "Page loads in 1.2s - Excellent speed",
        icon: <Zap className="h-5 w-5" />,
      },
      {
        name: "SEO",
        score: 85,
        status: "good",
        details: "Good meta tags, missing some structured data",
        icon: <Search className="h-5 w-5" />,
      },
      {
        name: "Mobile",
        score: 88,
        status: "good",
        details: "Responsive design with minor improvements needed",
        icon: <Smartphone className="h-5 w-5" />,
      },
      {
        name: "Security",
        score: 95,
        status: "excellent",
        details: "HTTPS enabled, security headers configured",
        icon: <Shield className="h-5 w-5" />,
      },
      {
        name: "Links",
        score: 78,
        status: "fair",
        details: "3 broken links found",
        icon: <Link2 className="h-5 w-5" />,
      },
      {
        name: "Accessibility",
        score: 90,
        status: "excellent",
        details: "WCAG 2.1 AA compliant",
        icon: <TrendingUp className="h-5 w-5" />,
      },
    ]

    const avgScore = Math.round(mockMetrics.reduce((acc, m) => acc + m.score, 0) / mockMetrics.length)

    setMetrics(mockMetrics)
    setOverallScore(avgScore)
    setChecking(false)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "excellent":
        return "text-green-500"
      case "good":
        return "text-blue-500"
      case "fair":
        return "text-yellow-500"
      case "poor":
        return "text-red-500"
      default:
        return "text-muted-foreground"
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "excellent":
        return "bg-green-500/10 text-green-500 border-green-500/50"
      case "good":
        return "bg-blue-500/10 text-blue-500 border-blue-500/50"
      case "fair":
        return "bg-yellow-500/10 text-yellow-500 border-yellow-500/50"
      case "poor":
        return "bg-red-500/10 text-red-500 border-red-500/50"
      default:
        return ""
    }
  }

  return (
    <div className="space-y-6">
      {/* Input Section */}
      <Card className="p-6 border-border/50 bg-card/50 backdrop-blur">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/10">
              <Globe className="h-5 w-5 text-green-500" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Website URL</h3>
              <p className="text-sm text-muted-foreground">Enter your website URL for health check</p>
            </div>
          </div>

          <div className="flex gap-3">
            <Input
              placeholder="https://example.com"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="flex-1"
            />
            <Button onClick={checkHealth} disabled={!url || checking}>
              {checking ? "Checking..." : "Check Health"}
            </Button>
          </div>
        </div>
      </Card>

      {/* Overall Score */}
      {metrics.length > 0 && (
        <Card className="p-6 border-border/50 bg-gradient-to-br from-green-500/10 to-blue-500/10">
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Overall Health Score</h3>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold">{overallScore}</span>
                <span className="text-muted-foreground">/100</span>
              </div>
              <p className="text-sm text-muted-foreground">
                {overallScore >= 90
                  ? "Excellent"
                  : overallScore >= 75
                    ? "Good"
                    : overallScore >= 60
                      ? "Fair"
                      : "Needs Improvement"}
              </p>
            </div>
            <div className="flex h-24 w-24 items-center justify-center rounded-full border-4 border-green-500">
              <span className="text-2xl font-bold text-green-500">{overallScore}</span>
            </div>
          </div>
        </Card>
      )}

      {/* Metrics Grid */}
      {metrics.length > 0 && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {metrics.map((metric, index) => (
            <Card key={index} className="p-6 border-border/50 bg-card/50 backdrop-blur">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`flex h-10 w-10 items-center justify-center rounded-lg ${getStatusColor(metric.status)} bg-current/10`}
                    >
                      {metric.icon}
                    </div>
                    <div>
                      <h4 className="font-semibold">{metric.name}</h4>
                      <Badge variant="outline" className={`text-xs ${getStatusBadge(metric.status)}`}>
                        {metric.status}
                      </Badge>
                    </div>
                  </div>
                  <span className={`text-2xl font-bold ${getStatusColor(metric.status)}`}>{metric.score}</span>
                </div>

                <Progress value={metric.score} className="h-2" />

                <p className="text-sm text-muted-foreground">{metric.details}</p>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Empty State */}
      {metrics.length === 0 && !checking && (
        <Card className="p-12 border-border/50 bg-card/50 backdrop-blur">
          <div className="flex flex-col items-center justify-center text-center">
            <Globe className="h-16 w-16 text-muted-foreground/50 mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Health Check Yet</h3>
            <p className="text-sm text-muted-foreground max-w-md">
              Enter your website URL above and click "Check Health" to get a comprehensive analysis
            </p>
          </div>
        </Card>
      )}
    </div>
  )
}
