"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Code, AlertCircle, CheckCircle2, AlertTriangle, Zap, Shield, TrendingUp } from "lucide-react"

interface AnalysisResult {
  severity: "error" | "warning" | "info" | "success"
  category: string
  message: string
  line?: number
  suggestion?: string
}

export function CodeAnalyzer() {
  const [code, setCode] = useState("")
  const [analyzing, setAnalyzing] = useState(false)
  const [results, setResults] = useState<AnalysisResult[]>([])

  const analyzeCode = async () => {
    setAnalyzing(true)

    // Simulate AI analysis
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const mockResults: AnalysisResult[] = [
      {
        severity: "success",
        category: "Syntax",
        message: "No syntax errors detected",
      },
      {
        severity: "warning",
        category: "Performance",
        message: "Inefficient loop detected",
        line: 15,
        suggestion: "Consider using Array.map() instead of forEach for better performance",
      },
      {
        severity: "info",
        category: "Best Practices",
        message: "Consider adding TypeScript types",
        line: 8,
        suggestion: "Adding type annotations will improve code maintainability",
      },
      {
        severity: "error",
        category: "Security",
        message: "Potential XSS vulnerability",
        line: 23,
        suggestion: "Sanitize user input before rendering to prevent XSS attacks",
      },
      {
        severity: "success",
        category: "Code Quality",
        message: "Code follows consistent formatting",
      },
    ]

    setResults(mockResults)
    setAnalyzing(false)
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "error":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case "success":
        return <CheckCircle2 className="h-4 w-4 text-green-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-blue-500" />
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "error":
        return "border-red-500/50 bg-red-500/10"
      case "warning":
        return "border-yellow-500/50 bg-yellow-500/10"
      case "success":
        return "border-green-500/50 bg-green-500/10"
      default:
        return "border-blue-500/50 bg-blue-500/10"
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Input Section */}
      <Card className="p-6 border-border/50 bg-card/50 backdrop-blur">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-500/10">
              <Code className="h-5 w-5 text-blue-500" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Code Input</h3>
              <p className="text-sm text-muted-foreground">Paste your code for analysis</p>
            </div>
          </div>

          <Textarea
            placeholder="Paste your code here..."
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="min-h-[400px] font-mono text-sm"
          />

          <div className="flex gap-3">
            <Button onClick={analyzeCode} disabled={!code || analyzing} className="flex-1">
              {analyzing ? "Analyzing..." : "Analyze Code"}
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setCode("")
                setResults([])
              }}
            >
              Clear
            </Button>
          </div>

          {/* Analysis Categories */}
          <div className="grid grid-cols-3 gap-2 pt-4 border-t">
            <div className="flex items-center gap-2 text-sm">
              <Shield className="h-4 w-4 text-blue-500" />
              <span className="text-muted-foreground">Security</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Zap className="h-4 w-4 text-yellow-500" />
              <span className="text-muted-foreground">Performance</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="h-4 w-4 text-green-500" />
              <span className="text-muted-foreground">Quality</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Results Section */}
      <Card className="p-6 border-border/50 bg-card/50 backdrop-blur">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold">Analysis Results</h3>
              <p className="text-sm text-muted-foreground">
                {results.length > 0 ? `${results.length} issues found` : "No analysis yet"}
              </p>
            </div>
            {results.length > 0 && (
              <Badge variant="outline" className="gap-1">
                <CheckCircle2 className="h-3 w-3" />
                Analyzed
              </Badge>
            )}
          </div>

          <div className="space-y-3 max-h-[500px] overflow-y-auto">
            {results.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Code className="h-12 w-12 text-muted-foreground/50 mb-3" />
                <p className="text-sm text-muted-foreground">Paste your code and click analyze to see results</p>
              </div>
            ) : (
              results.map((result, index) => (
                <Card key={index} className={`p-4 ${getSeverityColor(result.severity)}`}>
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2">
                        {getSeverityIcon(result.severity)}
                        <span className="font-medium text-sm">{result.category}</span>
                      </div>
                      {result.line && (
                        <Badge variant="secondary" className="text-xs">
                          Line {result.line}
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm">{result.message}</p>
                    {result.suggestion && (
                      <div className="pt-2 border-t border-border/50">
                        <p className="text-xs text-muted-foreground">
                          <span className="font-medium">Suggestion:</span> {result.suggestion}
                        </p>
                      </div>
                    )}
                  </div>
                </Card>
              ))
            )}
          </div>
        </div>
      </Card>
    </div>
  )
}
