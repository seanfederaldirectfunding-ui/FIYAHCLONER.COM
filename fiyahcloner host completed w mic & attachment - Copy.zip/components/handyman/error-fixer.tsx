"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Lightbulb, Copy, CheckCircle2 } from "lucide-react"

export function ErrorFixer() {
  const [error, setError] = useState("")
  const [fixing, setFixing] = useState(false)
  const [solution, setSolution] = useState<{
    problem: string
    cause: string
    solution: string
    code?: string
  } | null>(null)
  const [copied, setCopied] = useState(false)

  const fixError = async () => {
    setFixing(true)

    // Simulate AI analysis
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setSolution({
      problem: "TypeError: Cannot read property 'map' of undefined",
      cause: "The data array is undefined when the component first renders, before the API call completes.",
      solution: "Add optional chaining or a conditional check to ensure the array exists before calling .map()",
      code: `// Before (Error)
{data.map(item => <div>{item.name}</div>)}

// After (Fixed)
{data?.map(item => <div>{item.name}</div>)}

// Or with conditional
{data && data.map(item => <div>{item.name}</div>)}`,
    })

    setFixing(false)
  }

  const copyCode = () => {
    if (solution?.code) {
      navigator.clipboard.writeText(solution.code)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="space-y-4">
      <Textarea
        placeholder="Paste your error message here..."
        value={error}
        onChange={(e) => setError(e.target.value)}
        className="min-h-[120px] font-mono text-sm"
      />

      <Button onClick={fixError} disabled={!error || fixing} className="w-full">
        {fixing ? "Analyzing..." : "Fix Error"}
      </Button>

      {solution && (
        <Card className="p-6 space-y-4 border-green-500/50 bg-green-500/5">
          <div className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-yellow-500" />
            <h4 className="font-semibold">Solution Found</h4>
          </div>

          <div className="space-y-3">
            <div>
              <Badge variant="outline" className="mb-2">
                Problem
              </Badge>
              <p className="text-sm">{solution.problem}</p>
            </div>

            <div>
              <Badge variant="outline" className="mb-2">
                Cause
              </Badge>
              <p className="text-sm text-muted-foreground">{solution.cause}</p>
            </div>

            <div>
              <Badge variant="outline" className="mb-2">
                Solution
              </Badge>
              <p className="text-sm">{solution.solution}</p>
            </div>

            {solution.code && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline">Code Example</Badge>
                  <Button variant="ghost" size="sm" onClick={copyCode} className="h-8 gap-2">
                    {copied ? (
                      <>
                        <CheckCircle2 className="h-4 w-4" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4" />
                        Copy
                      </>
                    )}
                  </Button>
                </div>
                <pre className="p-4 rounded-lg bg-black/50 text-sm overflow-x-auto">
                  <code>{solution.code}</code>
                </pre>
              </div>
            )}
          </div>
        </Card>
      )}
    </div>
  )
}
