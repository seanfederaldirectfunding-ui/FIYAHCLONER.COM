"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Rocket, CheckCircle2, Loader2, Server, Globe, Lock } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface DeploymentStep {
  name: string
  status: "pending" | "in-progress" | "completed" | "error"
  message: string
}

export function DeploymentTool() {
  const [platform, setPlatform] = useState("")
  const [repoUrl, setRepoUrl] = useState("")
  const [deploying, setDeploying] = useState(false)
  const [steps, setSteps] = useState<DeploymentStep[]>([])

  const startDeployment = async () => {
    setDeploying(true)

    const deploymentSteps: DeploymentStep[] = [
      { name: "Connecting to repository", status: "pending", message: "" },
      { name: "Installing dependencies", status: "pending", message: "" },
      { name: "Building application", status: "pending", message: "" },
      { name: "Configuring environment", status: "pending", message: "" },
      { name: "Deploying to platform", status: "pending", message: "" },
      { name: "Setting up SSL certificate", status: "pending", message: "" },
      { name: "Configuring DNS", status: "pending", message: "" },
    ]

    setSteps(deploymentSteps)

    // Simulate deployment process
    for (let i = 0; i < deploymentSteps.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      setSteps((prev) =>
        prev.map((step, index) => {
          if (index === i) {
            return { ...step, status: "in-progress", message: "Processing..." }
          }
          return step
        }),
      )

      await new Promise((resolve) => setTimeout(resolve, 1000))

      setSteps((prev) =>
        prev.map((step, index) => {
          if (index === i) {
            return { ...step, status: "completed", message: "Completed successfully" }
          }
          return step
        }),
      )
    }

    setDeploying(false)
  }

  const getStepIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle2 className="h-5 w-5 text-green-500" />
      case "in-progress":
        return <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />
      default:
        return <div className="h-5 w-5 rounded-full border-2 border-muted-foreground/30" />
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Configuration Section */}
      <Card className="p-6 border-border/50 bg-card/50 backdrop-blur">
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-500/10">
              <Rocket className="h-5 w-5 text-purple-500" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Deployment Configuration</h3>
              <p className="text-sm text-muted-foreground">Configure your deployment settings</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="platform">Hosting Platform</Label>
              <Select value={platform} onValueChange={setPlatform}>
                <SelectTrigger id="platform">
                  <SelectValue placeholder="Select platform" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="vercel">Vercel</SelectItem>
                  <SelectItem value="netlify">Netlify</SelectItem>
                  <SelectItem value="aws">AWS</SelectItem>
                  <SelectItem value="azure">Azure</SelectItem>
                  <SelectItem value="digitalocean">DigitalOcean</SelectItem>
                  <SelectItem value="heroku">Heroku</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="repo">Repository URL</Label>
              <Input
                id="repo"
                placeholder="https://github.com/username/repo"
                value={repoUrl}
                onChange={(e) => setRepoUrl(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="branch">Branch</Label>
              <Input id="branch" placeholder="main" defaultValue="main" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="domain">Custom Domain (Optional)</Label>
              <Input id="domain" placeholder="example.com" />
            </div>
          </div>

          <Button onClick={startDeployment} disabled={!platform || !repoUrl || deploying} className="w-full">
            {deploying ? "Deploying..." : "Start Deployment"}
          </Button>

          {/* Platform Features */}
          <div className="pt-4 border-t space-y-3">
            <p className="text-sm font-medium">Included Features:</p>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                Auto SSL
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                CDN
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                CI/CD
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                Analytics
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Deployment Progress */}
      <Card className="p-6 border-border/50 bg-card/50 backdrop-blur">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold">Deployment Progress</h3>
              <p className="text-sm text-muted-foreground">
                {steps.length > 0 ? "Deployment in progress" : "Ready to deploy"}
              </p>
            </div>
            {steps.length > 0 && steps.every((s) => s.status === "completed") && (
              <Badge className="bg-green-500/10 text-green-500 border-green-500/50">Deployed</Badge>
            )}
          </div>

          {steps.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Rocket className="h-16 w-16 text-muted-foreground/50 mb-4" />
              <p className="text-sm text-muted-foreground max-w-sm">
                Configure your deployment settings and click "Start Deployment" to begin
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {steps.map((step, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="mt-0.5">{getStepIcon(step.status)}</div>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium">{step.name}</p>
                    {step.message && <p className="text-xs text-muted-foreground">{step.message}</p>}
                  </div>
                </div>
              ))}

              {steps.every((s) => s.status === "completed") && (
                <Card className="p-4 bg-green-500/10 border-green-500/50 mt-6">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                      <span className="font-semibold text-green-500">Deployment Successful!</span>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Globe className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">URL:</span>
                        <a href="#" className="text-primary hover:underline">
                          https://your-app.vercel.app
                        </a>
                      </div>
                      <div className="flex items-center gap-2">
                        <Lock className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">SSL:</span>
                        <span className="text-green-500">Active</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Server className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">Status:</span>
                        <span className="text-green-500">Online</span>
                      </div>
                    </div>
                  </div>
                </Card>
              )}
            </div>
          )}
        </div>
      </Card>
    </div>
  )
}
