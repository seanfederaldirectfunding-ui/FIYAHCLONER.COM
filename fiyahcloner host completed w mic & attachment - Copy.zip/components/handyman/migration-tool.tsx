"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowRightLeft, CheckCircle2, Database, FileText, Mail, Globe } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface MigrationItem {
  name: string
  type: "files" | "database" | "email" | "dns"
  size: string
  status: "pending" | "migrating" | "completed"
  progress: number
}

export function MigrationTool() {
  const [sourceHost, setSourceHost] = useState("")
  const [targetHost, setTargetHost] = useState("")
  const [migrating, setMigrating] = useState(false)
  const [items, setItems] = useState<MigrationItem[]>([])
  const [overallProgress, setOverallProgress] = useState(0)

  const startMigration = async () => {
    setMigrating(true)

    const migrationItems: MigrationItem[] = [
      { name: "Website Files", type: "files", size: "2.4 GB", status: "pending", progress: 0 },
      { name: "Database", type: "database", size: "856 MB", status: "pending", progress: 0 },
      { name: "Email Accounts", type: "email", size: "1.2 GB", status: "pending", progress: 0 },
      { name: "DNS Records", type: "dns", size: "12 KB", status: "pending", progress: 0 },
    ]

    setItems(migrationItems)

    // Simulate migration process
    for (let i = 0; i < migrationItems.length; i++) {
      setItems((prev) => prev.map((item, index) => (index === i ? { ...item, status: "migrating" } : item)))

      // Simulate progress
      for (let progress = 0; progress <= 100; progress += 10) {
        await new Promise((resolve) => setTimeout(resolve, 200))
        setItems((prev) => prev.map((item, index) => (index === i ? { ...item, progress } : item)))
        setOverallProgress((i * 100 + progress) / migrationItems.length)
      }

      setItems((prev) =>
        prev.map((item, index) => (index === i ? { ...item, status: "completed", progress: 100 } : item)),
      )
    }

    setMigrating(false)
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "files":
        return <FileText className="h-5 w-5 text-blue-500" />
      case "database":
        return <Database className="h-5 w-5 text-purple-500" />
      case "email":
        return <Mail className="h-5 w-5 text-green-500" />
      case "dns":
        return <Globe className="h-5 w-5 text-orange-500" />
      default:
        return null
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500/10 text-green-500 border-green-500/50">Completed</Badge>
      case "migrating":
        return <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/50">Migrating</Badge>
      default:
        return <Badge variant="outline">Pending</Badge>
    }
  }

  return (
    <div className="space-y-6">
      {/* Configuration Section */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="p-6 border-border/50 bg-card/50 backdrop-blur">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-500/10">
                <ArrowRightLeft className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Source Hosting</h3>
                <p className="text-sm text-muted-foreground">Current hosting provider</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="source">Source Platform</Label>
                <Select value={sourceHost} onValueChange={setSourceHost}>
                  <SelectTrigger id="source">
                    <SelectValue placeholder="Select source" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cpanel">cPanel</SelectItem>
                    <SelectItem value="wordpress">WordPress.com</SelectItem>
                    <SelectItem value="wix">Wix</SelectItem>
                    <SelectItem value="squarespace">Squarespace</SelectItem>
                    <SelectItem value="godaddy">GoDaddy</SelectItem>
                    <SelectItem value="bluehost">Bluehost</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="source-url">Source URL</Label>
                <Input id="source-url" placeholder="https://old-site.com" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="source-creds">Access Credentials</Label>
                <Input id="source-creds" type="password" placeholder="API Key or Password" />
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-6 border-border/50 bg-card/50 backdrop-blur">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/10">
                <ArrowRightLeft className="h-5 w-5 text-green-500 rotate-180" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Target Hosting</h3>
                <p className="text-sm text-muted-foreground">New hosting provider</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="target">Target Platform</Label>
                <Select value={targetHost} onValueChange={setTargetHost}>
                  <SelectTrigger id="target">
                    <SelectValue placeholder="Select target" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vercel">Vercel</SelectItem>
                    <SelectItem value="netlify">Netlify</SelectItem>
                    <SelectItem value="aws">AWS</SelectItem>
                    <SelectItem value="azure">Azure</SelectItem>
                    <SelectItem value="digitalocean">DigitalOcean</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="target-url">Target URL</Label>
                <Input id="target-url" placeholder="https://new-site.com" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="target-creds">Access Credentials</Label>
                <Input id="target-creds" type="password" placeholder="API Key or Password" />
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Migration Button */}
      <Card className="p-6 border-border/50 bg-card/50 backdrop-blur">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold">Ready to Migrate</h3>
            <p className="text-sm text-muted-foreground">All data will be transferred with zero downtime</p>
          </div>
          <Button onClick={startMigration} disabled={!sourceHost || !targetHost || migrating} size="lg">
            {migrating ? "Migrating..." : "Start Migration"}
          </Button>
        </div>
      </Card>

      {/* Migration Progress */}
      {items.length > 0 && (
        <>
          <Card className="p-6 border-border/50 bg-gradient-to-br from-orange-500/10 to-purple-500/10">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold">Overall Progress</h3>
                  <p className="text-sm text-muted-foreground">{Math.round(overallProgress)}% complete</p>
                </div>
                <span className="text-3xl font-bold">{Math.round(overallProgress)}%</span>
              </div>
              <Progress value={overallProgress} className="h-3" />
            </div>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            {items.map((item, index) => (
              <Card key={index} className="p-6 border-border/50 bg-card/50 backdrop-blur">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {getTypeIcon(item.type)}
                      <div>
                        <h4 className="font-semibold">{item.name}</h4>
                        <p className="text-sm text-muted-foreground">{item.size}</p>
                      </div>
                    </div>
                    {getStatusBadge(item.status)}
                  </div>

                  {item.status !== "pending" && (
                    <>
                      <Progress value={item.progress} className="h-2" />
                      <p className="text-sm text-muted-foreground text-right">{item.progress}%</p>
                    </>
                  )}
                </div>
              </Card>
            ))}
          </div>

          {items.every((item) => item.status === "completed") && (
            <Card className="p-6 bg-green-500/10 border-green-500/50">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="h-6 w-6 text-green-500" />
                <div>
                  <h3 className="text-lg font-semibold text-green-500">Migration Completed!</h3>
                  <p className="text-sm text-muted-foreground">
                    All data has been successfully transferred to the new hosting platform
                  </p>
                </div>
              </div>
            </Card>
          )}
        </>
      )}
    </div>
  )
}
