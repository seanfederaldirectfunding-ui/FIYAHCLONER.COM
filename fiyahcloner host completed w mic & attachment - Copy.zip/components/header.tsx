"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sparkles, Menu, Shield, Zap } from "lucide-react"
import { useState } from "react"

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <Sparkles className="h-5 w-5 text-primary-foreground" />
          </div>
          <div className="flex flex-col leading-none">
            <span className="text-xl font-bold tracking-tight">FIYAHCLONER</span>
            <span className="text-[10px] font-medium text-muted-foreground">AI NEXUS</span>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          <Link
            href="/chat"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            Chat
          </Link>
          <Link
            href="/ai-backend"
            className="text-sm font-medium text-cyan-600 dark:text-cyan-400 hover:text-cyan-700 dark:hover:text-cyan-300 transition-colors flex items-center gap-1"
          >
            <Zap className="h-3 w-3" />
            AI Backend
          </Link>
          <Link
            href="/images"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            Images
          </Link>
          <Link
            href="/video"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            Video
          </Link>
          <Link
            href="/voice"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            Voice & Music
          </Link>
          <Link
            href="/code"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            Code
          </Link>
          <Link
            href="/business"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            Business
          </Link>
          <Link
            href="/handyman"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            Handyman
          </Link>
          <Link
            href="/genius"
            className="text-sm font-medium text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 transition-colors flex items-center gap-1"
          >
            <Sparkles className="h-3 w-3" />
            Genius
          </Link>
          <Link href="/pricing" className="text-sm font-medium text-purple-400 hover:text-purple-300 transition-colors">
            Pricing
          </Link>
        </nav>

        <div className="flex items-center gap-3">
          <Link href="/admin">
            <Button
              variant="outline"
              size="sm"
              className="hidden md:flex gap-2 border-primary/20 hover:bg-primary/10 bg-transparent"
            >
              <Shield className="h-4 w-4" />
              Admin
            </Button>
          </Link>
          <Button variant="ghost" size="sm" className="hidden md:flex">
            Sign In
          </Button>
          <Link href="/pricing">
            <Button size="sm" className="hidden md:flex">
              Get Started
            </Button>
          </Link>
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden border-t border-border/40 bg-background/95 backdrop-blur">
          <nav className="container flex flex-col gap-4 px-4 py-4">
            <Link href="/chat" className="text-sm font-medium">
              Chat
            </Link>
            <Link
              href="/ai-backend"
              className="text-sm font-medium text-cyan-600 dark:text-cyan-400 flex items-center gap-2"
            >
              <Zap className="h-4 w-4" />
              AI Backend Studio
            </Link>
            <Link href="/images" className="text-sm font-medium">
              Images
            </Link>
            <Link href="/video" className="text-sm font-medium">
              Video
            </Link>
            <Link href="/voice" className="text-sm font-medium">
              Voice & Music
            </Link>
            <Link href="/code" className="text-sm font-medium">
              Code
            </Link>
            <Link href="/business" className="text-sm font-medium">
              Business
            </Link>
            <Link href="/handyman" className="text-sm font-medium">
              Handyman
            </Link>
            <Link
              href="/genius"
              className="text-sm font-medium text-purple-600 dark:text-purple-400 flex items-center gap-2"
            >
              <Sparkles className="h-4 w-4" />
              Genius AI Assistant
            </Link>
            <Link href="/pricing" className="text-sm font-medium text-purple-400">
              Pricing
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
