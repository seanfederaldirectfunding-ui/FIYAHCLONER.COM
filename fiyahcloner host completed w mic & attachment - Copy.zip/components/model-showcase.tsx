import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Cpu, Zap, Sparkles } from "lucide-react"

const models = {
  text: [
    { name: "GPT-5", provider: "OpenAI", speed: "Ultra Fast", quality: "Exceptional" },
    { name: "DeepSeek V3", provider: "DeepSeek", speed: "Lightning", quality: "Superior" },
    { name: "Gemini 2.0", provider: "Google", speed: "Instant", quality: "Outstanding" },
    { name: "Claude 4", provider: "Anthropic", speed: "Fast", quality: "Excellent" },
  ],
  image: [
    { name: "Flux Pro", provider: "Black Forest Labs", speed: "Fast", quality: "Photorealistic" },
    { name: "Midjourney v7", provider: "Midjourney", speed: "Medium", quality: "Artistic" },
    { name: "Stable Diffusion 3.5", provider: "Stability AI", speed: "Ultra Fast", quality: "Versatile" },
  ],
  video: [
    { name: "Sora 2", provider: "OpenAI", speed: "Medium", quality: "Cinematic" },
    { name: "Runway Gen-4", provider: "Runway", speed: "Fast", quality: "Professional" },
    { name: "Kling AI 2.1", provider: "Kuaishou", speed: "Fast", quality: "Realistic" },
  ],
}

export function ModelShowcase() {
  return (
    <section className="py-24">
      <div className="container px-4">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 text-balance">Powered by the World's Best AI Models</h2>
          <p className="text-lg text-muted-foreground text-balance">
            We integrate the top-performing models across all categories
          </p>
        </div>

        <div className="space-y-12">
          <div>
            <div className="mb-6 flex items-center gap-2">
              <Cpu className="h-5 w-5 text-primary" />
              <h3 className="text-2xl font-bold">Text & Chat Models</h3>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              {models.text.map((model) => (
                <Card key={model.name} className="border-border/40 bg-card p-5">
                  <div className="mb-3">
                    <h4 className="text-lg font-semibold mb-1">{model.name}</h4>
                    <p className="text-sm text-muted-foreground">{model.provider}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="gap-1">
                      <Zap className="h-3 w-3" />
                      {model.speed}
                    </Badge>
                    <Badge variant="outline" className="gap-1">
                      <Sparkles className="h-3 w-3" />
                      {model.quality}
                    </Badge>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <div className="mb-6 flex items-center gap-2">
              <Cpu className="h-5 w-5 text-primary" />
              <h3 className="text-2xl font-bold">Image Generation Models</h3>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {models.image.map((model) => (
                <Card key={model.name} className="border-border/40 bg-card p-5">
                  <div className="mb-3">
                    <h4 className="text-lg font-semibold mb-1">{model.name}</h4>
                    <p className="text-sm text-muted-foreground">{model.provider}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="gap-1">
                      <Zap className="h-3 w-3" />
                      {model.speed}
                    </Badge>
                    <Badge variant="outline" className="gap-1">
                      <Sparkles className="h-3 w-3" />
                      {model.quality}
                    </Badge>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <div className="mb-6 flex items-center gap-2">
              <Cpu className="h-5 w-5 text-primary" />
              <h3 className="text-2xl font-bold">Video Generation Models</h3>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {models.video.map((model) => (
                <Card key={model.name} className="border-border/40 bg-card p-5">
                  <div className="mb-3">
                    <h4 className="text-lg font-semibold mb-1">{model.name}</h4>
                    <p className="text-sm text-muted-foreground">{model.provider}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="gap-1">
                      <Zap className="h-3 w-3" />
                      {model.speed}
                    </Badge>
                    <Badge variant="outline" className="gap-1">
                      <Sparkles className="h-3 w-3" />
                      {model.quality}
                    </Badge>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
