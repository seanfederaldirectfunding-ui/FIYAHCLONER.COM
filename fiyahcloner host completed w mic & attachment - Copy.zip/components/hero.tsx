import { Button } from "@/components/ui/button"
import { ArrowRight, Zap } from "lucide-react"

export function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-border/40">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-background" />

      <div className="container relative px-4 py-24 md:py-32">
        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
            <Zap className="h-4 w-4" />
            <span>10 AI Generators Collaborating Together</span>
          </div>

          <h1 className="mb-6 text-5xl font-bold tracking-tight text-balance md:text-7xl">
            <span className="bg-gradient-to-r from-primary via-chart-3 to-chart-5 bg-clip-text text-transparent block mb-2">
              FIYAHCLONER
            </span>
            <span className="text-3xl md:text-5xl block mb-2">AI NEXUS</span>
            <span className="text-2xl md:text-4xl font-semibold">The Most Powerful Collaborative AI Platform</span>
          </h1>

          <p className="mb-8 text-lg text-muted-foreground text-balance md:text-xl leading-relaxed">
            10 elite AI generators working as one unified team. GPT-5, DeepSeek, Gemini, Flux, Sora, and more combine
            their strengths to deliver the best possible results at maximum speed. Not competing—collaborating.
          </p>

          <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Button size="lg" className="gap-2">
              Start Creating
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline">
              View Capabilities
            </Button>
          </div>

          <div className="mt-12 grid grid-cols-2 gap-6 md:grid-cols-4">
            <div className="rounded-lg border border-border/40 bg-card p-4">
              <div className="text-3xl font-bold text-primary">10</div>
              <div className="text-sm text-muted-foreground">AI Collaborators</div>
            </div>
            <div className="rounded-lg border border-border/40 bg-card p-4">
              <div className="text-3xl font-bold text-primary">100%</div>
              <div className="text-sm text-muted-foreground">Teamwork</div>
            </div>
            <div className="rounded-lg border border-border/40 bg-card p-4">
              <div className="text-3xl font-bold text-primary">10x</div>
              <div className="text-sm text-muted-foreground">Faster</div>
            </div>
            <div className="rounded-lg border border-border/40 bg-card p-4">
              <div className="text-3xl font-bold text-primary">∞</div>
              <div className="text-sm text-muted-foreground">Possibilities</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
