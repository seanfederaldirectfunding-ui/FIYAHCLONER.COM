"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Sparkles,
  Zap,
  Users,
  CheckCircle2,
  Loader2,
  Compass,
  AlertCircle,
  Paperclip,
  Mic,
  X,
  File,
} from "lucide-react"

const aiGenerators = [
  { name: "GPT-5", specialty: "Language & Logic", status: "ready", color: "bg-blue-500", source: "OpenAI" },
  {
    name: "Gemini 2.5 Pro",
    specialty: "Multimodal Reasoning",
    status: "ready",
    color: "bg-purple-500",
    source: "Google AI Studio",
  },
  {
    name: "Gemini 2.0 Flash",
    specialty: "Speed & Efficiency",
    status: "ready",
    color: "bg-violet-500",
    source: "Google AI Studio",
  },
  { name: "DeepSeek", specialty: "Deep Analysis", status: "ready", color: "bg-indigo-500", source: "DeepSeek" },
  { name: "Claude Opus", specialty: "Advanced Reasoning", status: "ready", color: "bg-slate-500", source: "Anthropic" },
  {
    name: "Imagen 3",
    specialty: "Photorealistic Images",
    status: "ready",
    color: "bg-pink-500",
    source: "Google AI Studio",
  },
  {
    name: "Flux Pro",
    specialty: "Artistic Images",
    status: "ready",
    color: "bg-rose-500",
    source: "Black Forest Labs",
  },
  { name: "Veo 2", specialty: "Cinematic Video", status: "ready", color: "bg-red-500", source: "Google AI Studio" },
  { name: "Sora 2", specialty: "Video Generation", status: "ready", color: "bg-orange-500", source: "OpenAI" },
  {
    name: "Gemini TTS",
    specialty: "Natural Voice",
    status: "ready",
    color: "bg-green-500",
    source: "Google AI Studio",
  },
  { name: "ElevenLabs", specialty: "Voice Cloning", status: "ready", color: "bg-emerald-500", source: "ElevenLabs" },
  { name: "Runway Gen-4", specialty: "Visual Effects", status: "ready", color: "bg-amber-500", source: "Runway" },
  { name: "Kling AI", specialty: "Motion & Animation", status: "ready", color: "bg-teal-500", source: "Kuaishou" },
  { name: "Grok 4", specialty: "Real-time Data", status: "ready", color: "bg-cyan-500", source: "xAI" },
]

type GeneratorStatus = "ready" | "analyzing" | "collaborating" | "generating" | "complete"

export function UniversalAIMaker() {
  const [prompt, setPrompt] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [progress, setProgress] = useState(0)
  const [activeGenerators, setActiveGenerators] = useState<string[]>([])
  const [generatorStatuses, setGeneratorStatuses] = useState<Record<string, GeneratorStatus>>(
    Object.fromEntries(aiGenerators.map((gen) => [gen.name, "ready"])),
  )
  const [result, setResult] = useState("")
  const [collaborationPhase, setCollaborationPhase] = useState("")
  const [error, setError] = useState("")

  const [attachedFiles, setAttachedFiles] = useState<File[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [isRecording, setIsRecording] = useState(false)
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null)
  const [audioChunks, setAudioChunks] = useState<Blob[]>([])

  const handleFileAttachment = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    try {
      const validFiles: File[] = []
      const maxSize = 50 * 1024 * 1024 // 50MB
      const allowedTypes = [
        "text/plain",
        "application/pdf",
        "application/json",
        "text/html",
        "text/css",
        "text/javascript",
        "application/javascript",
        "text/markdown",
        "application/zip",
        "image/png",
        "image/jpeg",
        "image/jpg",
        "image/gif",
        "image/webp",
      ]

      for (let i = 0; i < files.length; i++) {
        const file = files[i]

        if (file.size > maxSize) {
          setError(`File "${file.name}" is too large. Maximum size is 50MB.`)
          continue
        }

        if (
          !allowedTypes.includes(file.type) &&
          !file.name.match(/\.(txt|pdf|json|html|css|js|jsx|ts|tsx|md|zip|png|jpg|jpeg|gif|webp)$/)
        ) {
          setError(`File "${file.name}" has an unsupported file type.`)
          continue
        }

        validFiles.push(file)
      }

      if (validFiles.length > 0) {
        setAttachedFiles((prev) => [...prev, ...validFiles])
        setError("")
      }
    } catch (err) {
      console.error("[v0] File attachment error:", err)
      setError("Failed to attach files. Please try again.")
    }

    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleRemoveFile = (index: number) => {
    setAttachedFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const recorder = new MediaRecorder(stream)
      const chunks: Blob[] = []

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunks.push(e.data)
        }
      }

      recorder.onstop = async () => {
        const audioBlob = new Blob(chunks, { type: "audio/webm" })

        try {
          // Simulate transcription (in production, send to speech-to-text API)
          const transcribedText = await simulateTranscription(audioBlob)
          setPrompt((prev) => (prev ? `${prev}\n\n${transcribedText}` : transcribedText))
          setError("")
        } catch (err) {
          console.error("[v0] Transcription error:", err)
          setError("Failed to transcribe audio. Please try again.")
        }

        // Stop all tracks
        stream.getTracks().forEach((track) => track.stop())
      }

      recorder.start()
      setMediaRecorder(recorder)
      setIsRecording(true)
      setAudioChunks(chunks)
      setError("")
    } catch (err) {
      console.error("[v0] Microphone access error:", err)
      setError("Unable to access microphone. Please check your browser permissions.")
    }
  }

  const stopRecording = () => {
    if (mediaRecorder && mediaRecorder.state !== "inactive") {
      mediaRecorder.stop()
      setIsRecording(false)
      setMediaRecorder(null)
    }
  }

  const simulateTranscription = async (audioBlob: Blob): Promise<string> => {
    // In production, send to speech-to-text API (e.g., Google Cloud Speech-to-Text, Whisper API)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    return "[Voice input transcribed]: " + "Create a modern website with authentication and database integration"
  }

  const handleGenerate = async () => {
    setError("")

    if (!prompt.trim() && attachedFiles.length === 0) {
      setError("Please enter a description or attach files to continue")
      return
    }

    if (prompt.trim().length < 10 && attachedFiles.length === 0) {
      setError("Please provide a more detailed description (at least 10 characters) or attach files")
      return
    }

    if (prompt.trim().length > 5000) {
      setError("Description is too long. Please keep it under 5000 characters")
      return
    }

    setIsGenerating(true)
    setProgress(0)
    setResult("")
    setActiveGenerators([])

    try {
      let fileContext = ""
      if (attachedFiles.length > 0) {
        fileContext = `\n\nAttached Files (${attachedFiles.length}):\n${attachedFiles.map((f) => `• ${f.name} (${(f.size / 1024).toFixed(1)}KB)`).join("\n")}`
      }

      // Phase 1: Analysis (0-20%)
      setCollaborationPhase("Analyzing with Gemini 2.5 Pro & GPT-5...")
      await simulateProgress(0, 20, 1000)
      const analyzers = ["GPT-5", "Gemini 2.5 Pro", "DeepSeek", "Claude Opus"]
      setActiveGenerators(analyzers)
      analyzers.forEach((gen) => setGeneratorStatuses((prev) => ({ ...prev, [gen]: "analyzing" })))
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Phase 2: Collaboration (20-40%)
      setCollaborationPhase("AI generators collaborating with Google AI Studio resources...")
      await simulateProgress(20, 40, 1500)
      const allGens = aiGenerators.map((g) => g.name)
      setActiveGenerators(allGens)
      allGens.forEach((gen) => setGeneratorStatuses((prev) => ({ ...prev, [gen]: "collaborating" })))
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Phase 3: Generation (40-90%)
      setCollaborationPhase("Generating with combined power: Imagen 3, Veo 2, Gemini TTS...")
      await simulateProgress(40, 90, 3000)
      allGens.forEach((gen) => setGeneratorStatuses((prev) => ({ ...prev, [gen]: "generating" })))
      await new Promise((resolve) => setTimeout(resolve, 2500))

      // Phase 4: Finalization (90-100%)
      setCollaborationPhase("Finalizing with Gemini 2.0 Flash for speed optimization...")
      await simulateProgress(90, 100, 1000)
      allGens.forEach((gen) => setGeneratorStatuses((prev) => ({ ...prev, [gen]: "complete" })))

      setResult(
        `✨ Successfully created your request with enhanced Google AI Studio integration!${fileContext}\n\nThe 14 elite AI generators collaborated to produce the highest quality output:\n\n🧠 Analysis & Reasoning:\n• Gemini 2.5 Pro provided advanced multimodal reasoning\n• GPT-5 & DeepSeek analyzed requirements${attachedFiles.length > 0 ? " and attached files" : ""}\n• Claude Opus optimized logic and structure\n\n🎨 Visual Creation:\n• Imagen 3 (Google) generated photorealistic images\n• Flux Pro created artistic visual elements\n• Veo 2 (Google) produced cinematic video content\n• Sora 2 & Runway Gen-4 added advanced video effects\n• Kling AI handled motion and animation\n\n🎙️ Audio & Voice:\n• Gemini TTS (Google) synthesized natural voice\n• ElevenLabs provided voice cloning capabilities\n\n⚡ Speed & Data:\n• Gemini 2.0 Flash optimized for maximum speed\n• Grok 4 integrated real-time data\n\nAll generators worked together, enriched with Google AI Studio's cutting-edge resources, to ensure maximum quality and speed!`,
      )

      setCollaborationPhase("Complete!")
    } catch (error) {
      console.error("[v0] Universal AI Maker error:", error)
      setError("An error occurred during generation. Please try again.")
      setCollaborationPhase("")
    } finally {
      setIsGenerating(false)
    }
  }

  const simulateProgress = (start: number, end: number, duration: number) => {
    return new Promise<void>((resolve) => {
      const steps = 20
      const increment = (end - start) / steps
      const stepDuration = duration / steps
      let current = start

      const interval = setInterval(() => {
        current += increment
        setProgress(Math.min(current, end))

        if (current >= end) {
          clearInterval(interval)
          resolve()
        }
      }, stepDuration)
    })
  }

  const getStatusIcon = (status: GeneratorStatus) => {
    switch (status) {
      case "ready":
        return <div className="h-2 w-2 rounded-full bg-muted" />
      case "analyzing":
      case "collaborating":
      case "generating":
        return <Loader2 className="h-3 w-3 animate-spin text-primary" />
      case "complete":
        return <CheckCircle2 className="h-3 w-3 text-green-500" />
    }
  }

  return (
    <section className="py-24 border-b border-border/40">
      <div className="container px-4">
        <div className="mx-auto max-w-5xl">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
              <Users className="h-4 w-4" />
              <span>14 AI Generators Collaborating • Enhanced with Google AI Studio</span>
            </div>
            <h2 className="text-4xl font-bold mb-4 text-balance md:text-5xl">Universal AI Maker</h2>
            <p className="text-lg text-muted-foreground text-balance leading-relaxed">
              The most powerful AI generators working together to create anything you imagine.
              <br />
              <span className="text-primary font-medium">Not competing, but collaborating</span> for the best possible
              result at maximum speed.
              <br />
              <span className="text-xs text-muted-foreground mt-1 inline-block">
                Enriched with Google AI Studio: Gemini 2.5 Pro, Gemini 2.0 Flash, Imagen 3, Veo 2, Gemini TTS
              </span>
            </p>
          </div>

          {/* AI Generators Grid */}
          <Card className="p-6 mb-6 bg-card/50 backdrop-blur">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="h-5 w-5 text-primary" />
              <h3 className="font-semibold">Collaborative AI Team</h3>
              <Badge variant="secondary" className="ml-auto text-xs">
                14 Generators
              </Badge>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-7 gap-3">
              {aiGenerators.map((generator) => (
                <div
                  key={generator.name}
                  className={`rounded-lg border p-3 transition-all ${
                    activeGenerators.includes(generator.name)
                      ? "border-primary bg-primary/5 shadow-lg shadow-primary/20"
                      : "border-border/40 bg-background"
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <div className={`h-2 w-2 rounded-full ${generator.color}`} />
                    {getStatusIcon(generatorStatuses[generator.name])}
                  </div>
                  <div className="text-xs font-medium mb-0.5">{generator.name}</div>
                  <div className="text-[10px] text-muted-foreground mb-1">{generator.specialty}</div>
                  {generator.source === "Google AI Studio" && (
                    <Badge variant="outline" className="text-[8px] px-1 py-0 h-4">
                      Google
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </Card>

          {/* Input Area */}
          <Card className="p-6 mb-6">
            <div className="mb-4">
              <label className="text-sm font-medium mb-2 block">What do you want to create?</label>
              <Textarea
                placeholder="Describe anything you want to create... The 14 AI generators will collaborate to make it happen at the highest quality and fastest speed possible."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="min-h-[120px] resize-none"
                disabled={isGenerating}
                maxLength={5000}
              />
              <div className="flex items-center justify-between mt-2">
                <span className="text-xs text-muted-foreground">{prompt.length} / 5000 characters</span>
              </div>
            </div>

            {attachedFiles.length > 0 && (
              <div className="mb-4">
                <label className="text-sm font-medium mb-2 block">Attached Files ({attachedFiles.length})</label>
                <div className="flex flex-wrap gap-2">
                  {attachedFiles.map((file, index) => (
                    <div key={index} className="flex items-center gap-2 bg-secondary/50 rounded-lg px-3 py-2 text-sm">
                      <File className="h-4 w-4 text-muted-foreground" />
                      <span className="max-w-[200px] truncate">{file.name}</span>
                      <span className="text-xs text-muted-foreground">({(file.size / 1024).toFixed(1)}KB)</span>
                      <button
                        onClick={() => handleRemoveFile(index)}
                        className="ml-1 hover:text-destructive transition-colors"
                        disabled={isGenerating}
                        aria-label="Remove file"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {error && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm mb-4">
                <AlertCircle className="h-4 w-4 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="grid gap-3 md:grid-cols-2">
              <Button
                onClick={handleGenerate}
                disabled={isGenerating || (!prompt.trim() && attachedFiles.length === 0)}
                className="gap-2"
                size="lg"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    {collaborationPhase}
                  </>
                ) : (
                  <>
                    <Zap className="h-4 w-4" />
                    Generate with 14 AI Collaborators
                  </>
                )}
              </Button>

              <Button
                variant="outline"
                className="gap-2 bg-transparent"
                size="lg"
                onClick={() => {
                  const pageMasterSection = document.getElementById("page-master-section")
                  pageMasterSection?.scrollIntoView({ behavior: "smooth" })
                }}
              >
                <Compass className="h-4 w-4" />
                Page Master
              </Button>
            </div>

            <div className="flex gap-2 mt-3">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileAttachment}
                multiple
                className="hidden"
                accept=".txt,.pdf,.json,.html,.css,.js,.jsx,.ts,.tsx,.md,.zip,.png,.jpg,.jpeg,.gif,.webp"
                disabled={isGenerating}
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                disabled={isGenerating}
                className="gap-2"
              >
                <Paperclip className="h-4 w-4" />
                Attach Files
              </Button>

              <Button
                variant={isRecording ? "destructive" : "outline"}
                size="sm"
                onClick={isRecording ? stopRecording : startRecording}
                disabled={isGenerating}
                className="gap-2"
              >
                <Mic className={`h-4 w-4 ${isRecording ? "animate-pulse" : ""}`} />
                {isRecording ? "Stop Recording" : "Voice Input"}
              </Button>
            </div>

            {isGenerating && (
              <div className="mt-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">Progress</span>
                  <span className="text-sm font-medium">{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            )}
          </Card>

          {/* Result Area */}
          {result && (
            <Card className="p-6 bg-gradient-to-br from-primary/5 to-transparent border-primary/20">
              <div className="flex items-center gap-2 mb-4">
                <CheckCircle2 className="h-5 w-5 text-green-500" />
                <h3 className="font-semibold">Result</h3>
                <Badge variant="secondary" className="ml-auto">
                  Collaborative Output
                </Badge>
              </div>
              <div className="prose prose-sm max-w-none">
                <pre className="whitespace-pre-wrap text-sm leading-relaxed">{result}</pre>
              </div>
            </Card>
          )}

          {/* Collaboration Benefits */}
          <div className="mt-12 grid gap-4 md:grid-cols-3">
            <Card className="p-6 text-center border-border/40">
              <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h4 className="font-semibold mb-2">Collaborative Power</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                14 AI generators combine their unique strengths instead of competing
              </p>
            </Card>
            <Card className="p-6 text-center border-border/40">
              <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <h4 className="font-semibold mb-2">Maximum Speed</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Parallel processing delivers results faster than any single AI
              </p>
            </Card>
            <Card className="p-6 text-center border-border/40">
              <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Sparkles className="h-6 w-6 text-primary" />
              </div>
              <h4 className="font-semibold mb-2">Best Quality</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Each AI contributes its specialty for unmatched output quality
              </p>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
