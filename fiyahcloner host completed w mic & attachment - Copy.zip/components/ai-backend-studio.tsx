"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Code,
  Zap,
  Upload,
  Download,
  CheckCircle,
  AlertCircle,
  FileCode,
  Database,
  Cpu,
  Rocket,
  HelpCircle,
  Send,
} from "lucide-react"
import { Textarea } from "@/components/ui/textarea"
import dynamic from "next/dynamic"

const Editor = dynamic(() => import("@monaco-editor/react"), { ssr: false })

interface GeneratedFile {
  path: string
  content: string
  language: string
}

interface AnalysisResult {
  components: string[]
  apiCalls: string[]
  stateManagement: string[]
  forms: string[]
  database: boolean
  auth: boolean
}

export function AIBackendStudio() {
  const [frontendCode, setFrontendCode] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [isGenerating, setIsGenerating] = useState(false)
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null)
  const [generatedFiles, setGeneratedFiles] = useState<GeneratedFile[]>([])
  const [selectedFile, setSelectedFile] = useState<GeneratedFile | null>(null)
  const [deploymentStatus, setDeploymentStatus] = useState<string>("")

  const [showAIAssistance, setShowAIAssistance] = useState(false)
  const [assistanceQuery, setAssistanceQuery] = useState("")
  const [assistanceResponse, setAssistanceResponse] = useState("")
  const [isAssistanceLoading, setIsAssistanceLoading] = useState(false)

  // Sample frontend code for demonstration
  useEffect(() => {
    setFrontendCode(`// Paste your frontend code here
// The AI will analyze it and generate the complete backend

export default function ContactForm() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    // TODO: Connect to backend
    const response = await fetch('/api/contact', {
      method: 'POST',
      body: JSON.stringify({ name, email, message })
    })
  }
  
  return (
    <form onSubmit={handleSubmit}>
      <input value={name} onChange={(e) => setName(e.target.value)} />
      <input value={email} onChange={(e) => setEmail(e.target.value)} />
      <textarea value={message} onChange={(e) => setMessage(e.target.value)} />
      <button type="submit">Send Message</button>
    </form>
  )
}`)
  }, [])

  const analyzeFrontendCode = async () => {
    setIsAnalyzing(true)
    try {
      const response = await fetch("/api/ai-backend/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: frontendCode }),
      })

      if (!response.ok) throw new Error("Analysis failed")

      const result = await response.json()
      setAnalysis(result.analysis)
    } catch (error) {
      console.error("[v0] Frontend analysis error:", error)
      alert("Error analyzing frontend code. Please try again.")
    } finally {
      setIsAnalyzing(false)
    }
  }

  const generateBackend = async () => {
    if (!analysis) return

    setIsGenerating(true)
    try {
      const response = await fetch("/api/ai-backend/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: frontendCode, analysis }),
      })

      if (!response.ok) throw new Error("Backend generation failed")

      const result = await response.json()
      setGeneratedFiles(result.files)
      if (result.files.length > 0) {
        setSelectedFile(result.files[0])
      }
    } catch (error) {
      console.error("[v0] Backend generation error:", error)
      alert("Error generating backend. Please try again.")
    } finally {
      setIsGenerating(false)
    }
  }

  const downloadProject = () => {
    // Create a downloadable zip file with all generated files
    const projectData = {
      files: generatedFiles,
      timestamp: new Date().toISOString(),
    }
    const dataStr = JSON.stringify(projectData, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = "fiyahcloner-backend-project.json"
    link.click()
    URL.revokeObjectURL(url)
  }

  const publishProject = async () => {
    setDeploymentStatus("Preparing deployment...")
    try {
      const response = await fetch("/api/ai-backend/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          frontendCode,
          backendFiles: generatedFiles,
        }),
      })

      if (!response.ok) throw new Error("Deployment failed")

      const result = await response.json()
      setDeploymentStatus(`✅ Published successfully! URL: ${result.url}`)
    } catch (error) {
      console.error("[v0] Deployment error:", error)
      setDeploymentStatus("❌ Deployment failed. Please check your configuration.")
    }
  }

  const handleAIAssistance = async () => {
    if (!assistanceQuery.trim()) return

    setIsAssistanceLoading(true)
    try {
      const response = await fetch("/api/ai-backend/assistance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: assistanceQuery,
          frontendCode: frontendCode,
          analysis: analysis,
        }),
      })

      if (!response.ok) throw new Error("AI Assistance failed")

      const result = await response.json()
      setAssistanceResponse(result.solution)
    } catch (error) {
      console.error("[v0] AI Assistance error:", error)
      setAssistanceResponse("Sorry, I encountered an error. Please try again.")
    } finally {
      setIsAssistanceLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900/20 via-background to-blue-900/20">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-400 via-pink-500 to-blue-500 bg-clip-text text-transparent">
            AI Backend Studio
          </h1>
          <p className="text-xl text-muted-foreground">
            Paste your frontend code, and AI will generate a complete, production-ready backend automatically
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-4 mb-8">
          <Button
            onClick={analyzeFrontendCode}
            disabled={isAnalyzing || !frontendCode}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <Cpu className="mr-2 h-5 w-5" />
            {isAnalyzing ? "Analyzing..." : "Analyze Frontend"}
          </Button>

          <Button
            onClick={generateBackend}
            disabled={isGenerating || !analysis}
            size="lg"
            className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
          >
            <Zap className="mr-2 h-5 w-5" />
            {isGenerating ? "Generating..." : "Generate Backend"}
          </Button>

          <Button onClick={downloadProject} disabled={generatedFiles.length === 0} size="lg" variant="outline">
            <Download className="mr-2 h-5 w-5" />
            Download Project
          </Button>

          <Button
            onClick={publishProject}
            disabled={generatedFiles.length === 0}
            size="lg"
            className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
          >
            <Rocket className="mr-2 h-5 w-5" />
            Publish Now
          </Button>

          <Button
            onClick={() => setShowAIAssistance(!showAIAssistance)}
            size="lg"
            variant="outline"
            className="bg-gradient-to-r from-cyan-600/10 to-blue-600/10 hover:from-cyan-600/20 hover:to-blue-600/20 border-cyan-500/50"
          >
            <HelpCircle className="mr-2 h-5 w-5" />
            AI Assistance
          </Button>
        </div>

        {/* AI Assistance Panel */}
        {showAIAssistance && (
          <Card className="p-6 mb-6 bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-2 border-cyan-500/50">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <HelpCircle className="h-6 w-6 text-cyan-500" />
              AI Backend Assistant (Level 5 Expert)
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              Paste your source code problem below, and I'll provide the correct backend code to make it fully
              functional.
            </p>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <label className="text-sm font-medium">Your Code Problem:</label>
                <Textarea
                  value={assistanceQuery}
                  onChange={(e) => setAssistanceQuery(e.target.value)}
                  placeholder="Paste your frontend code or describe the issue...&#10;&#10;Example: I have a login form but need the backend API route to handle authentication with JWT tokens."
                  className="min-h-[300px] font-mono text-sm"
                />
                <Button
                  onClick={handleAIAssistance}
                  disabled={isAssistanceLoading || !assistanceQuery.trim()}
                  className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700"
                >
                  {isAssistanceLoading ? (
                    <>
                      <Cpu className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Get Solution
                    </>
                  )}
                </Button>
              </div>

              <div className="space-y-3">
                <label className="text-sm font-medium">AI Solution:</label>
                <Textarea
                  value={assistanceResponse}
                  readOnly
                  placeholder="The AI will provide the complete backend code solution here..."
                  className="min-h-[300px] font-mono text-sm bg-background"
                />
                {assistanceResponse && (
                  <Button
                    onClick={() => {
                      navigator.clipboard.writeText(assistanceResponse)
                      alert("Solution copied to clipboard!")
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    <FileCode className="mr-2 h-4 w-4" />
                    Copy Solution
                  </Button>
                )}
              </div>
            </div>
          </Card>
        )}

        {/* Deployment Status */}
        {deploymentStatus && (
          <Card className="p-4 mb-6 bg-card/50 backdrop-blur border-2">
            <p className="text-sm font-medium">{deploymentStatus}</p>
          </Card>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Panel - Frontend Code Editor */}
          <Card className="lg:col-span-2 p-6 bg-card/50 backdrop-blur">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <FileCode className="h-6 w-6 text-purple-500" />
                Frontend Code
              </h2>
              <Button variant="outline" size="sm">
                <Upload className="mr-2 h-4 w-4" />
                Upload File
              </Button>
            </div>

            <div className="border-2 border-border rounded-lg overflow-hidden" style={{ height: "600px" }}>
              <Editor
                height="100%"
                defaultLanguage="typescript"
                value={frontendCode}
                onChange={(value) => setFrontendCode(value || "")}
                theme="vs-dark"
                options={{
                  minimap: { enabled: true },
                  fontSize: 14,
                  lineNumbers: "on",
                  roundedSelection: false,
                  scrollBeyondLastLine: false,
                  automaticLayout: true,
                }}
              />
            </div>
          </Card>

          {/* Right Panel - Analysis & Status */}
          <Card className="p-6 bg-card/50 backdrop-blur">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <Database className="h-6 w-6 text-blue-500" />
              Analysis
            </h2>

            {!analysis ? (
              <div className="text-center py-12 text-muted-foreground">
                <AlertCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Click "Analyze Frontend" to start</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    Detected Features
                  </h3>
                  <div className="space-y-2">
                    {analysis.components.length > 0 && (
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Components:</p>
                        <div className="flex flex-wrap gap-2">
                          {analysis.components.map((comp, idx) => (
                            <Badge key={idx} variant="secondary">
                              {comp}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {analysis.apiCalls.length > 0 && (
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">API Endpoints:</p>
                        <div className="flex flex-wrap gap-2">
                          {analysis.apiCalls.map((api, idx) => (
                            <Badge key={idx} variant="outline" className="border-blue-500">
                              {api}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {analysis.forms.length > 0 && (
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Forms:</p>
                        <div className="flex flex-wrap gap-2">
                          {analysis.forms.map((form, idx) => (
                            <Badge key={idx} variant="outline" className="border-purple-500">
                              {form}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Required Backend:</h3>
                  <div className="space-y-2">
                    {analysis.database && (
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Database Schema
                      </div>
                    )}
                    {analysis.auth && (
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Authentication
                      </div>
                    )}
                    {analysis.apiCalls.length > 0 && (
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        API Routes ({analysis.apiCalls.length})
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </Card>
        </div>

        {/* Generated Backend Files */}
        {generatedFiles.length > 0 && (
          <Card className="mt-6 p-6 bg-card/50 backdrop-blur">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <Code className="h-6 w-6 text-green-500" />
              Generated Backend ({generatedFiles.length} files)
            </h2>

            <Tabs defaultValue="files" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="files">Files</TabsTrigger>
                <TabsTrigger value="preview">Code Preview</TabsTrigger>
              </TabsList>

              <TabsContent value="files" className="space-y-2">
                {generatedFiles.map((file, idx) => (
                  <Button
                    key={idx}
                    variant={selectedFile?.path === file.path ? "default" : "outline"}
                    className="w-full justify-start"
                    onClick={() => setSelectedFile(file)}
                  >
                    <FileCode className="mr-2 h-4 w-4" />
                    {file.path}
                  </Button>
                ))}
              </TabsContent>

              <TabsContent value="preview">
                {selectedFile && (
                  <div>
                    <div className="mb-4">
                      <h3 className="font-semibold">{selectedFile.path}</h3>
                      <Badge variant="secondary">{selectedFile.language}</Badge>
                    </div>
                    <div className="border-2 border-border rounded-lg overflow-hidden" style={{ height: "400px" }}>
                      <Editor
                        height="100%"
                        language={selectedFile.language}
                        value={selectedFile.content}
                        theme="vs-dark"
                        options={{
                          readOnly: true,
                          minimap: { enabled: false },
                          fontSize: 14,
                        }}
                      />
                    </div>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </Card>
        )}
      </div>
    </div>
  )
}
