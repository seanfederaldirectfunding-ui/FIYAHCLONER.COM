"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useChat } from "@ai-sdk/react"
import { DefaultChatTransport } from "ai"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Mic, MicOff, Volume2, VolumeX, Sparkles, FileText, Send, Trash2 } from "lucide-react"

interface GeniusMessage {
  id: string
  role: "user" | "assistant"
  content: string
  emotion?: string
  timestamp: Date
}

export default function GeniusAssistant() {
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [voiceEnabled, setVoiceEnabled] = useState(true)
  const [notepadContent, setNotepadContent] = useState("")
  const [showNotepad, setShowNotepad] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [geniusMessages, setGeniusMessages] = useState<GeniusMessage[]>([])

  const recognitionRef = useRef<any>(null)
  const synthRef = useRef<SpeechSynthesis | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const { messages, sendMessage, status } = useChat({
    transport: new DefaultChatTransport({ api: "/api/genius/chat" }),
  })

  // Initialize speech recognition and synthesis
  useEffect(() => {
    if (typeof window !== "undefined") {
      synthRef.current = window.speechSynthesis

      // Initialize Web Speech API
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition()
        recognitionRef.current.continuous = true
        recognitionRef.current.interimResults = true
        recognitionRef.current.lang = "en-US"

        recognitionRef.current.onresult = (event: any) => {
          const current = event.resultIndex
          const transcriptText = event.results[current][0].transcript
          setTranscript(transcriptText)

          if (event.results[current].isFinal) {
            handleVoiceInput(transcriptText)
            setTranscript("")
          }
        }

        recognitionRef.current.onerror = (event: any) => {
          console.error("[v0] Speech recognition error:", event.error)
          setIsListening(false)
        }
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
      if (synthRef.current) {
        synthRef.current.cancel()
      }
    }
  }, [])

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [geniusMessages])

  // Convert messages to Genius format and speak responses
  useEffect(() => {
    if (messages.length > 0) {
      const lastMessage = messages[messages.length - 1]
      if (lastMessage.role === "assistant") {
        const textContent = lastMessage.parts
          .filter((part: any) => part.type === "text")
          .map((part: any) => part.text)
          .join(" ")

        if (textContent && voiceEnabled) {
          speakText(textContent)
        }

        // Check if Genius wants to write to notepad
        if (textContent.includes("[NOTEPAD]")) {
          const notepadMatch = textContent.match(/\[NOTEPAD\](.*?)\[\/NOTEPAD\]/s)
          if (notepadMatch) {
            setNotepadContent((prev) => prev + "\n" + notepadMatch[1].trim())
            setShowNotepad(true)
          }
        }

        setGeniusMessages((prev) => [
          ...prev,
          {
            id: lastMessage.id,
            role: "assistant",
            content: textContent.replace(/\[NOTEPAD\].*?\[\/NOTEPAD\]/gs, ""),
            timestamp: new Date(),
          },
        ])
      }
    }
  }, [messages, voiceEnabled])

  const handleVoiceInput = (text: string) => {
    if (text.trim()) {
      setGeniusMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          role: "user",
          content: text,
          timestamp: new Date(),
        },
      ])
      sendMessage({ text })
    }
  }

  const toggleListening = () => {
    if (!recognitionRef.current) {
      alert("Speech recognition is not supported in your browser. Please use Chrome or Edge.")
      return
    }

    if (isListening) {
      recognitionRef.current.stop()
      setIsListening(false)
    } else {
      recognitionRef.current.start()
      setIsListening(true)
    }
  }

  const speakText = (text: string) => {
    if (!synthRef.current || !voiceEnabled) return

    // Cancel any ongoing speech
    synthRef.current.cancel()

    // Parse emotional tags for enhanced delivery
    const emotionalText = text
      .replace(/\[excited\]/gi, "")
      .replace(/\[empathetic\]/gi, "")
      .replace(/\[calm\]/gi, "")
      .replace(/\[enthusiastic\]/gi, "")

    const utterance = new SpeechSynthesisUtterance(emotionalText)

    // Use a more natural female voice
    const voices = synthRef.current.getVoices()
    const femaleVoice =
      voices.find(
        (voice) =>
          voice.name.includes("Female") ||
          voice.name.includes("Samantha") ||
          voice.name.includes("Victoria") ||
          voice.name.includes("Google US English"),
      ) || voices[0]

    utterance.voice = femaleVoice
    utterance.rate = 0.95
    utterance.pitch = 1.1
    utterance.volume = 1.0

    utterance.onstart = () => setIsSpeaking(true)
    utterance.onend = () => setIsSpeaking(false)
    utterance.onerror = () => setIsSpeaking(false)

    synthRef.current.speak(utterance)
  }

  const handleTextSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const text = formData.get("message") as string

    if (text.trim()) {
      setGeniusMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          role: "user",
          content: text,
          timestamp: new Date(),
        },
      ])
      sendMessage({ text })
      e.currentTarget.reset()
    }
  }

  const clearNotepad = () => {
    setNotepadContent("")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 dark:from-gray-900 dark:via-purple-900/20 dark:to-blue-900/20">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="relative">
              <Sparkles className="w-12 h-12 text-purple-600 dark:text-purple-400" />
              {isSpeaking && (
                <div className="absolute inset-0 animate-ping">
                  <Sparkles className="w-12 h-12 text-purple-400 opacity-75" />
                </div>
              )}
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent">
              Genius
            </h1>
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-2">Your Empathetic AI Customer Service Assistant</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Powered by emotional intelligence & human-like conversation
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
          {/* Chat Interface */}
          <Card className="lg:col-span-2 p-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold text-gray-800 dark:text-white">Conversation</h2>
              <div className="flex gap-2">
                <Button
                  variant={voiceEnabled ? "default" : "outline"}
                  size="sm"
                  onClick={() => setVoiceEnabled(!voiceEnabled)}
                  className="gap-2"
                >
                  {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                  Voice
                </Button>
                <Button
                  variant={showNotepad ? "default" : "outline"}
                  size="sm"
                  onClick={() => setShowNotepad(!showNotepad)}
                  className="gap-2"
                >
                  <FileText className="w-4 h-4" />
                  Notepad
                </Button>
              </div>
            </div>

            {/* Messages */}
            <div className="h-[500px] overflow-y-auto mb-4 space-y-4 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
              {geniusMessages.length === 0 && (
                <div className="text-center text-gray-500 dark:text-gray-400 py-12">
                  <Sparkles className="w-16 h-16 mx-auto mb-4 text-purple-400" />
                  <p className="text-lg font-medium mb-2">Hi! I'm Genius 👋</p>
                  <p className="text-sm">
                    I'm here to help you with empathy and understanding.
                    <br />
                    Click the microphone to speak or type your message below.
                  </p>
                </div>
              )}

              {geniusMessages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                      msg.role === "user"
                        ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white"
                        : "bg-white dark:bg-gray-800 text-gray-800 dark:text-white border border-gray-200 dark:border-gray-700"
                    }`}
                  >
                    <p className="text-sm leading-relaxed">{msg.content}</p>
                    <p className="text-xs opacity-70 mt-1">{msg.timestamp.toLocaleTimeString()}</p>
                  </div>
                </div>
              ))}

              {transcript && (
                <div className="flex justify-end">
                  <div className="max-w-[80%] rounded-2xl px-4 py-3 bg-purple-100 dark:bg-purple-900/30 text-purple-900 dark:text-purple-100 border-2 border-purple-300 dark:border-purple-700 border-dashed">
                    <p className="text-sm italic">{transcript}</p>
                  </div>
                </div>
              )}

              {status === "in_progress" && (
                <div className="flex justify-start">
                  <div className="bg-white dark:bg-gray-800 rounded-2xl px-4 py-3 border border-gray-200 dark:border-gray-700">
                    <div className="flex gap-2">
                      <div
                        className="w-2 h-2 bg-purple-600 rounded-full animate-bounce"
                        style={{ animationDelay: "0ms" }}
                      />
                      <div
                        className="w-2 h-2 bg-pink-600 rounded-full animate-bounce"
                        style={{ animationDelay: "150ms" }}
                      />
                      <div
                        className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"
                        style={{ animationDelay: "300ms" }}
                      />
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Voice Control */}
            <div className="flex items-center gap-4 mb-4">
              <Button
                onClick={toggleListening}
                size="lg"
                className={`flex-1 gap-2 ${
                  isListening
                    ? "bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700"
                    : "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                }`}
              >
                {isListening ? (
                  <>
                    <MicOff className="w-5 h-5" />
                    Stop Listening
                  </>
                ) : (
                  <>
                    <Mic className="w-5 h-5" />
                    Start Voice Chat
                  </>
                )}
              </Button>
            </div>

            {/* Text Input */}
            <form onSubmit={handleTextSubmit} className="flex gap-2">
              <input
                name="message"
                type="text"
                placeholder="Type your message here..."
                className="flex-1 px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-600"
                disabled={status === "in_progress"}
              />
              <Button
                type="submit"
                size="lg"
                disabled={status === "in_progress"}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                <Send className="w-5 h-5" />
              </Button>
            </form>
          </Card>

          {/* Notepad */}
          <Card
            className={`p-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm transition-all ${showNotepad ? "opacity-100" : "opacity-50"}`}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold text-gray-800 dark:text-white flex items-center gap-2">
                <FileText className="w-6 h-6 text-purple-600" />
                Genius's Notepad
              </h2>
              <Button variant="ghost" size="sm" onClick={clearNotepad} className="text-red-600 hover:text-red-700">
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>

            <Textarea
              value={notepadContent}
              onChange={(e) => setNotepadContent(e.target.value)}
              placeholder="Genius will write important notes here for you..."
              className="min-h-[500px] font-mono text-sm bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800"
            />

            <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
              Genius can write notes here when you need to remember something important
            </p>
          </Card>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-6 max-w-7xl mx-auto mt-8">
          <Card className="p-6 bg-gradient-to-br from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 border-purple-200 dark:border-purple-800">
            <h3 className="text-lg font-semibold text-purple-900 dark:text-purple-100 mb-2">
              🎭 Emotional Intelligence
            </h3>
            <p className="text-sm text-purple-800 dark:text-purple-200">
              Genius understands emotions and responds with empathy, making conversations feel natural and caring.
            </p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-pink-100 to-blue-100 dark:from-pink-900/30 dark:to-blue-900/30 border-pink-200 dark:border-pink-800">
            <h3 className="text-lg font-semibold text-pink-900 dark:text-pink-100 mb-2">🎤 Voice Conversation</h3>
            <p className="text-sm text-pink-800 dark:text-pink-200">
              Speak naturally with Genius using your microphone and hear responses in a human-like voice.
            </p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-blue-100 to-purple-100 dark:from-blue-900/30 dark:to-purple-900/30 border-blue-200 dark:border-blue-800">
            <h3 className="text-lg font-semibold text-blue-900 dark:text-blue-100 mb-2">📝 Smart Notepad</h3>
            <p className="text-sm text-blue-800 dark:text-blue-200">
              Genius can write important information to the notepad so you never miss critical details.
            </p>
          </Card>
        </div>
      </div>
    </div>
  )
}
