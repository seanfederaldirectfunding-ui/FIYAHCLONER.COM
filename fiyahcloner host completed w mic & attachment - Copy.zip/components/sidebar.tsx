"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Sparkles,
  MessageSquare,
  ImageIcon,
  Video,
  Mic,
  Code,
  Briefcase,
  Wrench,
  Zap,
  Server,
  Shield,
  CreditCard,
  Home,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useState } from "react"

const navigation = [
  { name: "Home", href: "/", icon: Home },
  { name: "Universal AI Maker", href: "/chat", icon: MessageSquare },
  { name: "AI Backend Studio", href: "/ai-backend", icon: Zap, highlight: true },
  { name: "HOSTING", href: "/hosting", icon: Server, highlight: true, color: "text-green-500" },
  { name: "Image Generation", href: "/images", icon: ImageIcon },
  { name: "Video Generation", href: "/video", icon: Video },
  { name: "Voice & Music", href: "/voice", icon: Mic },
  { name: "Code Generation", href: "/code", icon: Code },
  { name: "Business Tools", href: "/business", icon: Briefcase },
  { name: "Digital Handyman", href: "/handyman", icon: Wrench },
  { name: "Genius AI Assistant", href: "/genius", icon: Sparkles, color: "text-purple-500" },
  { name: "Pricing", href: "/pricing", icon: CreditCard },
  { name: "Admin", href: "/admin", icon: Shield },
]

export function Sidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)

  return (
    <div
      className={cn(
        "fixed left-0 top-0 z-40 h-screen border-r border-border/40 bg-background/95 backdrop-blur transition-all duration-300",
        collapsed ? "w-16" : "w-64",
      )}
    >
      <div className="flex h-full flex-col">
        {/* Logo */}
        <div className="flex h-16 items-center justify-between border-b border-border/40 px-4">
          {!collapsed && (
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-purple-600 to-blue-600">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <div className="flex flex-col leading-none">
                <span className="text-lg font-bold tracking-tight">FIYAHCLONER</span>
                <span className="text-[9px] font-medium text-muted-foreground">AI NEXUS</span>
              </div>
            </Link>
          )}
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setCollapsed(!collapsed)}>
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>

        {/* Navigation */}
        <ScrollArea className="flex-1 px-3 py-4">
          <nav className="space-y-1">
            {navigation.map((item) => {
              const Icon = item.icon
              const isActive = pathname === item.href
              return (
                <Link key={item.href} href={item.href}>
                  <Button
                    variant={isActive ? "secondary" : "ghost"}
                    className={cn(
                      "w-full justify-start gap-3 transition-colors",
                      collapsed ? "px-2" : "px-3",
                      isActive && "bg-primary/10 text-primary",
                      item.highlight && !isActive && "text-cyan-600 dark:text-cyan-400",
                      item.color && !isActive,
                    )}
                    title={collapsed ? item.name : undefined}
                  >
                    <Icon className={cn("h-5 w-5 shrink-0", item.color)} />
                    {!collapsed && <span className="text-sm">{item.name}</span>}
                  </Button>
                </Link>
              )
            })}
          </nav>
        </ScrollArea>

        {/* Footer */}
        {!collapsed && (
          <div className="border-t border-border/40 p-4">
            <div className="rounded-lg bg-gradient-to-br from-purple-600/10 to-blue-600/10 p-3">
              <p className="text-xs font-medium text-muted-foreground mb-2">Need help?</p>
              <Button size="sm" variant="outline" className="w-full bg-transparent">
                Contact Support
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
