"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Sparkles, Zap, ImageIcon, Video, Mic, Code, Brain, Layers } from "lucide-react"

const googleAIFeatures = [
  {
    icon: Brain,
    name: "Gemini 2.5 Pro",
    description: "Advanced multimodal reasoning with 2M token context",
    color: "text-purple-500",
    bgColor: "bg-purple-500/10",
  },
  {
    icon: Zap,
    name: "Gemini 2.0 Flash",
    description: "Lightning-fast responses with thinking mode",
    color: "text-violet-500",
    bgColor: "bg-violet-500/10",
  },
  {
    icon: ImageIcon,
    name: "Imagen 3",
    description: "Photorealistic image generation up to 2048x2048",
    color: "text-pink-500",
    bgColor: "bg-pink-500/10",
  },
  {
    icon: Video,
    name: "Veo 2",
    description: "Cinematic 4K video generation up to 60 seconds",
    color: "text-red-500",
    bgColor: "bg-red-500/10",
  },
  {
    icon: Mic,
    name: "Gemini TTS",
    description: "Hyper-realistic voice synthesis and audio generation",
    color: "text-green-500",
    bgColor: "bg-green-500/10",
  },
  {
    icon: Code,
    name: "Code Generation",
    description: "Advanced coding assistance across all languages",
    color: "text-blue-500",
    bgColor: "bg-blue-500/10",
  },
  {
    icon: Layers,
    name: "Multimodal Processing",
    description: "Simultaneous text, image, video, and audio understanding",
    color: "text-cyan-500",
    bgColor: "bg-cyan-500/10",
  },
  {
    icon: Sparkles,
    name: "Native Audio",
    description: "Direct audio understanding without transcription",
    color: "text-amber-500",
    bgColor: "bg-amber-500/10",
  },
]

export function GoogleAIShowcase() {
  return (
    <section className="py-24 border-b border-border/40 bg-gradient-to-b from-background to-muted/20">
      <div className="container px-4">
        <div className="mx-auto max-w-6xl">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-purple-500/20 bg-purple-500/10 px-4 py-1.5 text-sm font-medium text-purple-500">
              <Sparkles className="h-4 w-4" />
              <span>Powered by Google AI Studio</span>
            </div>
            <h2 className="text-4xl font-bold mb-4 text-balance md:text-5xl">Enhanced with Google's Latest AI</h2>
            <p className="text-lg text-muted-foreground text-balance leading-relaxed max-w-3xl mx-auto">
              FIYAHCLONER integrates cutting-edge Google AI Studio resources to deliver unmatched performance across all
              generation tasks. Every feature is enriched with Google's most advanced models.
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-12">
            {googleAIFeatures.map((feature) => {
              const Icon = feature.icon
              return (
                <Card
                  key={feature.name}
                  className="p-6 border-border/40 hover:border-primary/40 transition-all hover:shadow-lg hover:shadow-primary/5"
                >
                  <div
                    className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg ${feature.bgColor}`}
                  >
                    <Icon className={`h-6 w-6 ${feature.color}`} />
                  </div>
                  <h3 className="font-semibold mb-2">{feature.name}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                </Card>
              )
            })}
          </div>

          {/* Integration Benefits */}
          <Card className="p-8 bg-gradient-to-br from-purple-500/5 via-violet-500/5 to-pink-500/5 border-purple-500/20">
            <div className="grid gap-8 md:grid-cols-3">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-500 mb-2">2M+</div>
                <div className="text-sm text-muted-foreground">Token Context Window</div>
                <div className="text-xs text-muted-foreground mt-1">Gemini 2.5 Pro</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-violet-500 mb-2">4K</div>
                <div className="text-sm text-muted-foreground">Video Resolution</div>
                <div className="text-xs text-muted-foreground mt-1">Veo 2 Generation</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-pink-500 mb-2">60s</div>
                <div className="text-sm text-muted-foreground">Video Duration</div>
                <div className="text-xs text-muted-foreground mt-1">Cinematic Quality</div>
              </div>
            </div>
          </Card>

          {/* Collaboration Note */}
          <div className="mt-8 text-center">
            <Badge variant="outline" className="text-xs px-3 py-1">
              Google AI Studio resources seamlessly integrated with all 14 AI generators
            </Badge>
          </div>
        </div>
      </div>
    </section>
  )
}
