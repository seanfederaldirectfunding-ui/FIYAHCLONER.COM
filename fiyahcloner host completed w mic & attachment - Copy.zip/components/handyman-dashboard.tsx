"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Wrench, Bug, Globe, Rocket, ArrowRightLeft, CheckCircle2, Code, Zap } from "lucide-react"
import { CodeAnalyzer } from "@/components/handyman/code-analyzer"
import { WebsiteHealthCheck } from "@/components/handyman/website-health-check"
import { DeploymentTool } from "@/components/handyman/deployment-tool"
import { MigrationTool } from "@/components/handyman/migration-tool"
import { ErrorFixer } from "@/components/handyman/error-fixer"

export function HandymanDashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-red-600">
            <Wrench className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Digital Handyman</h1>
            <p className="text-muted-foreground">Advanced tools to fix, deploy, and migrate any website or software</p>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="p-4 border-border/50 bg-card/50 backdrop-blur">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/10">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Issues Fixed</p>
              <p className="text-2xl font-bold">1,247</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 border-border/50 bg-card/50 backdrop-blur">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-500/10">
              <Rocket className="h-5 w-5 text-blue-500" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Deployments</p>
              <p className="text-2xl font-bold">892</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 border-border/50 bg-card/50 backdrop-blur">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-500/10">
              <ArrowRightLeft className="h-5 w-5 text-purple-500" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Migrations</p>
              <p className="text-2xl font-bold">456</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 border-border/50 bg-card/50 backdrop-blur">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-500/10">
              <Zap className="h-5 w-5 text-orange-500" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Uptime</p>
              <p className="text-2xl font-bold">99.9%</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Main Tools */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5 lg:w-auto">
          <TabsTrigger value="overview" className="gap-2">
            <Wrench className="h-4 w-4" />
            <span className="hidden sm:inline">Overview</span>
          </TabsTrigger>
          <TabsTrigger value="analyzer" className="gap-2">
            <Code className="h-4 w-4" />
            <span className="hidden sm:inline">Analyzer</span>
          </TabsTrigger>
          <TabsTrigger value="health" className="gap-2">
            <Globe className="h-4 w-4" />
            <span className="hidden sm:inline">Health</span>
          </TabsTrigger>
          <TabsTrigger value="deploy" className="gap-2">
            <Rocket className="h-4 w-4" />
            <span className="hidden sm:inline">Deploy</span>
          </TabsTrigger>
          <TabsTrigger value="migrate" className="gap-2">
            <ArrowRightLeft className="h-4 w-4" />
            <span className="hidden sm:inline">Migrate</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Tool Cards */}
            <Card
              className="p-6 border-border/50 bg-card/50 backdrop-blur hover:border-primary/50 transition-colors cursor-pointer"
              onClick={() => setActiveTab("analyzer")}
            >
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-500/10">
                    <Code className="h-6 w-6 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Code Analyzer</h3>
                    <p className="text-sm text-muted-foreground">Deep code analysis & bug detection</p>
                  </div>
                </div>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Syntax & logic error detection
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Performance optimization suggestions
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Security vulnerability scanning
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Best practices validation
                  </li>
                </ul>
              </div>
            </Card>

            <Card
              className="p-6 border-border/50 bg-card/50 backdrop-blur hover:border-primary/50 transition-colors cursor-pointer"
              onClick={() => setActiveTab("health")}
            >
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-green-500/10">
                    <Globe className="h-6 w-6 text-green-500" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Website Health Check</h3>
                    <p className="text-sm text-muted-foreground">Comprehensive site diagnostics</p>
                  </div>
                </div>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Performance & speed analysis
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    SEO optimization check
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Broken links detection
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Mobile responsiveness test
                  </li>
                </ul>
              </div>
            </Card>

            <Card
              className="p-6 border-border/50 bg-card/50 backdrop-blur hover:border-primary/50 transition-colors cursor-pointer"
              onClick={() => setActiveTab("deploy")}
            >
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-500/10">
                    <Rocket className="h-6 w-6 text-purple-500" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Deployment Expert</h3>
                    <p className="text-sm text-muted-foreground">One-click deployment to any platform</p>
                  </div>
                </div>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Vercel, Netlify, AWS, Azure support
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Automatic environment setup
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    CI/CD pipeline configuration
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    SSL & domain management
                  </li>
                </ul>
              </div>
            </Card>

            <Card
              className="p-6 border-border/50 bg-card/50 backdrop-blur hover:border-primary/50 transition-colors cursor-pointer"
              onClick={() => setActiveTab("migrate")}
            >
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-orange-500/10">
                    <ArrowRightLeft className="h-6 w-6 text-orange-500" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Migration Tool</h3>
                    <p className="text-sm text-muted-foreground">Seamless hosting migration</p>
                  </div>
                </div>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Automatic content transfer
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Database migration support
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Zero downtime migration
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    DNS & email preservation
                  </li>
                </ul>
              </div>
            </Card>
          </div>

          {/* Error Fixer Section */}
          <Card className="p-6 border-border/50 bg-gradient-to-br from-red-500/10 to-orange-500/10">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-red-500/20">
                  <Bug className="h-6 w-6 text-red-500" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">AI Error Fixer</h3>
                  <p className="text-sm text-muted-foreground">
                    Paste any error and get instant fixes with explanations
                  </p>
                </div>
              </div>
              <ErrorFixer />
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="analyzer">
          <CodeAnalyzer />
        </TabsContent>

        <TabsContent value="health">
          <WebsiteHealthCheck />
        </TabsContent>

        <TabsContent value="deploy">
          <DeploymentTool />
        </TabsContent>

        <TabsContent value="migrate">
          <MigrationTool />
        </TabsContent>
      </Tabs>
    </div>
  )
}
