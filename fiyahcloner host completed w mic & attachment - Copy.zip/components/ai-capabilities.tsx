import { Card } from "@/components/ui/card"
import {
  MessageSquare,
  ImageIcon,
  Video,
  Mic,
  Music,
  Code,
  Smartphone,
  Briefcase,
  Film,
  Wrench,
  Zap,
} from "lucide-react"

const capabilities = [
  {
    icon: MessageSquare,
    title: "AI Chat",
    description: "GPT-5, DeepSeek, Gemini, Claude - The most powerful language models",
    color: "text-blue-500",
  },
  {
    icon: ImageIcon,
    title: "Image Generation",
    description: "Flux, Midjourney, Stable Diffusion - Photorealistic images instantly",
    color: "text-purple-500",
  },
  {
    icon: Video,
    title: "Video Creation",
    description: "Sora, Runway, Kling - Professional videos from text prompts",
    color: "text-pink-500",
  },
  {
    icon: Mic,
    title: "Voice Synthesis",
    description: "Natural, human-like voice generation in any language",
    color: "text-green-500",
  },
  {
    icon: Music,
    title: "Music & Songs",
    description: "Create original music, songs, and soundtracks with AI",
    color: "text-yellow-500",
  },
  {
    icon: Film,
    title: "Movie Generator",
    description: "Full movie production with scenes, dialogue, and effects",
    color: "text-red-500",
  },
  {
    icon: Code,
    title: "Code Generation",
    description: "Write complete applications in any programming language",
    color: "text-cyan-500",
  },
  {
    icon: Zap,
    title: "AI Backend",
    description: "Automatically generates complete backend from frontend code - For idiots!",
    color: "text-cyan-400",
  },
  {
    icon: Smartphone,
    title: "App Builder",
    description: "Generate mobile apps and Chrome extensions instantly",
    color: "text-indigo-500",
  },
  {
    icon: Briefcase,
    title: "Business Generator",
    description: "Complete business plans, strategies, and execution roadmaps",
    color: "text-orange-500",
  },
  {
    icon: Wrench,
    title: "Digital Handyman",
    description: "Fix, deploy, and migrate any website with zero downtime",
    color: "text-amber-500",
  },
]

export function AICapabilities() {
  return (
    <section id="capabilities" className="py-24 border-b border-border/40">
      <div className="container px-4">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 text-balance">11 Specialized AI Generators Working Together</h2>
          <p className="text-lg text-muted-foreground text-balance">
            Each AI brings unique expertise. Together, they create the best possible output for any task.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {capabilities.map((capability) => (
            <Card
              key={capability.title}
              className="group relative overflow-hidden border-border/40 bg-card p-6 transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10"
            >
              <div className="mb-4 flex items-center gap-3">
                <div className={`rounded-lg bg-secondary p-2.5 ${capability.color}`}>
                  <capability.icon className="h-5 w-5" />
                </div>
                <h3 className="text-lg font-semibold">{capability.title}</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">{capability.description}</p>
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
