"use client"

import { useState } from "react"
import { Check, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { PRODUCTS } from "@/lib/products"
import Checkout from "@/components/checkout"

export default function PricingCards() {
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null)

  const formatPrice = (priceInCents: number) => {
    return `$${(priceInCents / 100).toFixed(0)}`
  }

  return (
    <>
      <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
        {PRODUCTS.map((product) => (
          <Card
            key={product.id}
            className={`relative bg-slate-900/50 border-slate-800 backdrop-blur-sm ${
              product.popular ? "ring-2 ring-purple-500 shadow-lg shadow-purple-500/20" : ""
            }`}
          >
            {product.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-1 rounded-full text-sm font-semibold flex items-center gap-1">
                  <Sparkles className="w-4 h-4" />
                  Most Popular
                </div>
              </div>
            )}

            <CardHeader className="text-center pb-8 pt-8">
              <CardTitle className="text-2xl font-bold text-white mb-2">{product.name}</CardTitle>
              <CardDescription className="text-slate-400">{product.description}</CardDescription>
              <div className="mt-4">
                <span className="text-5xl font-bold text-white">{formatPrice(product.priceInCents)}</span>
                <span className="text-slate-400 ml-2">/month</span>
              </div>
            </CardHeader>

            <CardContent>
              <ul className="space-y-3">
                {product.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-300 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>

            <CardFooter>
              <Button
                onClick={() => setSelectedProductId(product.id)}
                className={`w-full ${
                  product.popular
                    ? "bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                    : "bg-slate-800 hover:bg-slate-700"
                } text-white font-semibold py-6`}
              >
                Get Started
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <Dialog open={selectedProductId !== null} onOpenChange={(open) => !open && setSelectedProductId(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-slate-900 border-slate-800">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-white">Complete Your Purchase</DialogTitle>
            <DialogDescription className="text-slate-400">Secure checkout powered by Stripe</DialogDescription>
          </DialogHeader>
          {selectedProductId && <Checkout productId={selectedProductId} />}
        </DialogContent>
      </Dialog>
    </>
  )
}
