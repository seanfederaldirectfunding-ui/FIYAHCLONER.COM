"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Compass,
  Globe,
  Search,
  MousePointer,
  CheckCircle2,
  Loader2,
  Eye,
  Navigation,
  BookOpen,
  ArrowRight,
  ExternalLink,
  AlertCircle,
} from "lucide-react"

interface Step {
  number: number
  action: string
  element: string
  description: string
  screenshot?: string
}

interface PageAnalysis {
  title: string
  url: string
  structure: string[]
  navigation: string[]
  keyElements: string[]
  accessibility: string
}

export function PageMaster() {
  const [url, setUrl] = useState("")
  const [userGoal, setUserGoal] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisProgress, setAnalysisProgress] = useState(0)
  const [currentPhase, setCurrentPhase] = useState("")
  const [pageAnalysis, setPageAnalysis] = useState<PageAnalysis | null>(null)
  const [steps, setSteps] = useState<Step[]>([])
  const [activeTab, setActiveTab] = useState("input")
  const [error, setError] = useState("")

  const validateUrl = (url: string): boolean => {
    try {
      const urlObj = new URL(url)
      return urlObj.protocol === "http:" || urlObj.protocol === "https:"
    } catch {
      return false
    }
  }

  const handleAnalyze = async () => {
    setError("")

    if (!url.trim()) {
      setError("Please enter a website URL")
      return
    }

    if (!validateUrl(url.trim())) {
      setError("Please enter a valid URL (must start with http:// or https://)")
      return
    }

    if (!userGoal.trim()) {
      setError("Please describe what you want to do on this page")
      return
    }

    if (userGoal.trim().length < 5) {
      setError("Please provide a more detailed description of your goal")
      return
    }

    setIsAnalyzing(true)
    setAnalysisProgress(0)
    setPageAnalysis(null)
    setSteps([])

    try {
      // Phase 1: Fetching page (0-25%)
      setCurrentPhase("Navigating to website...")
      await simulateProgress(0, 25, 1000)

      // Phase 2: Analyzing structure (25-50%)
      setCurrentPhase("Learning page structure and elements...")
      await simulateProgress(25, 50, 1500)

      // Phase 3: Understanding navigation (50-75%)
      setCurrentPhase("Mapping navigation paths...")
      await simulateProgress(50, 75, 1500)

      // Phase 4: Creating tutorial (75-100%)
      setCurrentPhase("Generating step-by-step guide...")
      await simulateProgress(75, 100, 1000)

      // Simulate page analysis
      const analysis: PageAnalysis = {
        title: "Example Website",
        url: url.trim(),
        structure: [
          "Header with navigation menu",
          "Main content area with 3 sections",
          "Sidebar with filters and search",
          "Footer with links and contact info",
        ],
        navigation: ["Home", "Products", "Services", "About", "Contact", "Login", "Sign Up"],
        keyElements: [
          "Search bar (top right)",
          "Main CTA button (center)",
          "Product grid (main area)",
          "Filter dropdown (left sidebar)",
          "User account menu (top right)",
        ],
        accessibility: "WCAG 2.1 AA compliant with keyboard navigation support",
      }

      setPageAnalysis(analysis)

      // Generate steps based on user goal
      const generatedSteps: Step[] = [
        {
          number: 1,
          action: "Navigate to homepage",
          element: "URL bar",
          description: `Go to ${url.trim()} in your browser. The page will load with the main navigation visible at the top.`,
        },
        {
          number: 2,
          action: "Locate the search feature",
          element: "Search bar (top right corner)",
          description:
            "Look for the search icon or search box in the top right corner of the page. It's usually marked with a magnifying glass icon.",
        },
        {
          number: 3,
          action: "Enter your search query",
          element: "Search input field",
          description: `Click on the search box and type your query related to: "${userGoal.trim()}". The search will show suggestions as you type.`,
        },
        {
          number: 4,
          action: "Review search results",
          element: "Results page",
          description:
            "After pressing Enter or clicking the search button, you'll see a list of results. Each result shows a title, description, and link.",
        },
        {
          number: 5,
          action: "Select the relevant item",
          element: "Result card or link",
          description:
            "Click on the result that best matches your goal. This will take you to the detailed page where you can complete your task.",
        },
        {
          number: 6,
          action: "Complete your goal",
          element: "Action button or form",
          description: `Follow the on-page instructions to complete: "${userGoal.trim()}". Look for prominent buttons or forms that guide you through the process.`,
        },
      ]

      setSteps(generatedSteps)
      setActiveTab("analysis")
      setCurrentPhase("Analysis complete!")
    } catch (error) {
      console.error("[v0] Page Master analysis error:", error)
      setError("Error analyzing page. Please check the URL and try again.")
      setCurrentPhase("")
    } finally {
      setIsAnalyzing(false)
    }
  }

  const simulateProgress = (start: number, end: number, duration: number) => {
    return new Promise<void>((resolve) => {
      const steps = 20
      const increment = (end - start) / steps
      const stepDuration = duration / steps
      let current = start

      const interval = setInterval(() => {
        current += increment
        setAnalysisProgress(Math.min(current, end))

        if (current >= end) {
          clearInterval(interval)
          resolve()
        }
      }, stepDuration)
    })
  }

  return (
    <section className="py-24 border-b border-border/40" id="page-master-section">
      <div className="container px-4">
        <div className="mx-auto max-w-6xl">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
              <Compass className="h-4 w-4" />
              <span>AI-Powered Web Navigation</span>
            </div>
            <h2 className="text-4xl font-bold mb-4 text-balance md:text-5xl">Page Master</h2>
            <p className="text-lg text-muted-foreground text-balance leading-relaxed">
              Visit any website, learn its structure, and get step-by-step guidance to accomplish any task.
              <br />
              <span className="text-primary font-medium">Your AI guide to mastering any web page.</span>
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="input" className="gap-2">
                <Globe className="h-4 w-4" />
                Input
              </TabsTrigger>
              <TabsTrigger value="analysis" disabled={!pageAnalysis} className="gap-2">
                <Eye className="h-4 w-4" />
                Analysis
              </TabsTrigger>
              <TabsTrigger value="guide" disabled={steps.length === 0} className="gap-2">
                <BookOpen className="h-4 w-4" />
                Step-by-Step Guide
              </TabsTrigger>
            </TabsList>

            <TabsContent value="input" className="mt-6">
              <Card className="p-6">
                <div className="space-y-6">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Website URL</label>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <Globe className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          placeholder="https://example.com"
                          value={url}
                          onChange={(e) => setUrl(e.target.value)}
                          className="pl-10"
                          disabled={isAnalyzing}
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">What do you want to do on this page?</label>
                    <Input
                      placeholder="e.g., Find and purchase a product, Sign up for an account, Contact support..."
                      value={userGoal}
                      onChange={(e) => setUserGoal(e.target.value)}
                      disabled={isAnalyzing}
                    />
                  </div>

                  {error && (
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
                      <AlertCircle className="h-4 w-4 flex-shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  <Button
                    onClick={handleAnalyze}
                    disabled={isAnalyzing || !url.trim() || !userGoal.trim()}
                    className="w-full gap-2"
                    size="lg"
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        {currentPhase}
                      </>
                    ) : (
                      <>
                        <Search className="h-4 w-4" />
                        Analyze Page & Create Guide
                      </>
                    )}
                  </Button>

                  {isAnalyzing && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Progress</span>
                        <span className="font-medium">{Math.round(analysisProgress)}%</span>
                      </div>
                      <div className="h-2 rounded-full bg-muted overflow-hidden">
                        <div
                          className="h-full bg-primary transition-all duration-300"
                          style={{ width: `${analysisProgress}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </Card>

              {/* Features */}
              <div className="mt-8 grid gap-4 md:grid-cols-4">
                <Card className="p-4 border-border/40">
                  <div className="mb-2 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Eye className="h-5 w-5 text-primary" />
                  </div>
                  <h4 className="font-semibold mb-1 text-sm">Page Learning</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    AI analyzes page structure and elements
                  </p>
                </Card>
                <Card className="p-4 border-border/40">
                  <div className="mb-2 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Navigation className="h-5 w-5 text-primary" />
                  </div>
                  <h4 className="font-semibold mb-1 text-sm">Smart Navigation</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">Finds the best path to your goal</p>
                </Card>
                <Card className="p-4 border-border/40">
                  <div className="mb-2 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <BookOpen className="h-5 w-5 text-primary" />
                  </div>
                  <h4 className="font-semibold mb-1 text-sm">Step-by-Step</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">Clear instructions for every action</p>
                </Card>
                <Card className="p-4 border-border/40">
                  <div className="mb-2 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <MousePointer className="h-5 w-5 text-primary" />
                  </div>
                  <h4 className="font-semibold mb-1 text-sm">Visual Guidance</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">Shows exactly where to click</p>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="analysis" className="mt-6">
              {pageAnalysis && (
                <div className="space-y-6">
                  <Card className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-semibold mb-1">{pageAnalysis.title}</h3>
                        <a
                          href={pageAnalysis.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm text-primary hover:underline inline-flex items-center gap-1"
                        >
                          {pageAnalysis.url}
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      </div>
                      <Badge variant="secondary" className="gap-1">
                        <CheckCircle2 className="h-3 w-3" />
                        Analyzed
                      </Badge>
                    </div>

                    <div className="grid gap-6 md:grid-cols-2">
                      <div>
                        <h4 className="font-semibold mb-3 flex items-center gap-2">
                          <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                            <Globe className="h-4 w-4 text-primary" />
                          </div>
                          Page Structure
                        </h4>
                        <ul className="space-y-2">
                          {pageAnalysis.structure.map((item, index) => (
                            <li key={index} className="text-sm flex items-start gap-2">
                              <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3 flex items-center gap-2">
                          <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                            <Navigation className="h-4 w-4 text-primary" />
                          </div>
                          Navigation Options
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {pageAnalysis.navigation.map((item, index) => (
                            <Badge key={index} variant="outline">
                              {item}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3 flex items-center gap-2">
                          <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                            <MousePointer className="h-4 w-4 text-primary" />
                          </div>
                          Key Elements
                        </h4>
                        <ul className="space-y-2">
                          {pageAnalysis.keyElements.map((item, index) => (
                            <li key={index} className="text-sm flex items-start gap-2">
                              <ArrowRight className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3 flex items-center gap-2">
                          <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                            <Eye className="h-4 w-4 text-primary" />
                          </div>
                          Accessibility
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">{pageAnalysis.accessibility}</p>
                      </div>
                    </div>
                  </Card>

                  <div className="flex justify-end">
                    <Button onClick={() => setActiveTab("guide")} className="gap-2">
                      View Step-by-Step Guide
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="guide" className="mt-6">
              <Card className="p-6">
                <div className="mb-6">
                  <h3 className="text-xl font-semibold mb-2">How to: {userGoal}</h3>
                  <p className="text-sm text-muted-foreground">
                    Follow these {steps.length} steps to accomplish your goal on {url}
                  </p>
                </div>

                <ScrollArea className="h-[600px] pr-4">
                  <div className="space-y-6">
                    {steps.map((step, index) => (
                      <div key={step.number} className="relative">
                        {index < steps.length - 1 && (
                          <div className="absolute left-6 top-14 bottom-0 w-0.5 bg-border" />
                        )}
                        <div className="flex gap-4">
                          <div className="flex-shrink-0">
                            <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg">
                              {step.number}
                            </div>
                          </div>
                          <div className="flex-1 pt-1">
                            <h4 className="font-semibold mb-1">{step.action}</h4>
                            <Badge variant="outline" className="mb-3">
                              {step.element}
                            </Badge>
                            <p className="text-sm text-muted-foreground leading-relaxed mb-4">{step.description}</p>
                            {step.screenshot && (
                              <div className="rounded-lg border border-border overflow-hidden">
                                <img
                                  src={step.screenshot || "/placeholder.svg"}
                                  alt={`Step ${step.number}`}
                                  className="w-full"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                <div className="mt-6 pt-6 border-t border-border">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className="h-4 w-4 text-green-500" />
                      <span>Guide generated successfully</span>
                    </div>
                    <Button variant="outline" onClick={() => setActiveTab("input")} className="gap-2">
                      Analyze Another Page
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </section>
  )
}
