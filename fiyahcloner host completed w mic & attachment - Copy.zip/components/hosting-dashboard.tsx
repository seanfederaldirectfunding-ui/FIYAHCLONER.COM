"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Server,
  Globe,
  Phone,
  Key,
  Rocket,
  TestTube,
  Upload,
  CheckCircle2,
  Loader2,
  Play,
  Settings,
  Code,
  Database,
  Shield,
  Zap,
  ExternalLink,
  RefreshCw,
  Monitor,
  ShoppingCart,
  Lock,
} from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"

export function HostingDashboard() {
  const [activeTab, setActiveTab] = useState("domain")
  const [domainSearchQuery, setDomainSearchQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [domainResults, setDomainResults] = useState<any[]>([])
  const [deploymentStatus, setDeploymentStatus] = useState<"idle" | "deploying" | "testing" | "live">("idle")
  const [deploymentProgress, setDeploymentProgress] = useState(0)

  const handleDomainSearch = async () => {
    if (!domainSearchQuery) return
    setIsSearching(true)

    // Simulate domain search
    setTimeout(() => {
      setDomainResults([
        { domain: `${domainSearchQuery}.com`, available: true, price: "$12.99/year" },
        { domain: `${domainSearchQuery}.io`, available: true, price: "$39.99/year" },
        { domain: `${domainSearchQuery}.app`, available: false, price: "Taken" },
        { domain: `${domainSearchQuery}.dev`, available: true, price: "$15.99/year" },
        { domain: `${domainSearchQuery}.ai`, available: true, price: "$89.99/year" },
      ])
      setIsSearching(false)
    }, 1500)
  }

  const handleOneClickDeploy = async () => {
    setDeploymentStatus("deploying")
    setDeploymentProgress(0)

    // Simulate deployment process
    const steps = [
      { progress: 20, status: "Building project..." },
      { progress: 40, status: "Optimizing assets..." },
      { progress: 60, status: "Deploying to servers..." },
      { progress: 80, status: "Configuring DNS..." },
      { progress: 100, status: "Deployment complete!" },
    ]

    for (const step of steps) {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setDeploymentProgress(step.progress)
    }

    setDeploymentStatus("testing")
  }

  const handleBetaLaunch = () => {
    setDeploymentStatus("testing")
  }

  const handleGoLive = () => {
    setDeploymentStatus("live")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-purple-950/20">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-green-600 to-emerald-600">
              <Server className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                HOSTING
              </h1>
              <p className="text-sm text-muted-foreground">
                One-click deployment platform with domain, hosting, VoIP & API management
              </p>
            </div>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 lg:w-auto lg:inline-grid">
            <TabsTrigger value="domain" className="gap-2">
              <Globe className="h-4 w-4" />
              Domain
            </TabsTrigger>
            <TabsTrigger value="hosting" className="gap-2">
              <Server className="h-4 w-4" />
              Hosting
            </TabsTrigger>
            <TabsTrigger value="accessories" className="gap-2">
              <ShoppingCart className="h-4 w-4" />
              Accessory Store
            </TabsTrigger>
            <TabsTrigger value="voip" className="gap-2">
              <Phone className="h-4 w-4" />
              VoIP
            </TabsTrigger>
            <TabsTrigger value="deploy" className="gap-2">
              <Rocket className="h-4 w-4" />
              Deploy
            </TabsTrigger>
            <TabsTrigger value="manage" className="gap-2">
              <Settings className="h-4 w-4" />
              Manage
            </TabsTrigger>
          </TabsList>

          {/* Domain Tab */}
          <TabsContent value="domain" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-green-500" />
                  Domain Search & Purchase
                </CardTitle>
                <CardDescription>Find and register your perfect domain name</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <div className="flex-1">
                    <Input
                      placeholder="Enter domain name..."
                      value={domainSearchQuery}
                      onChange={(e) => setDomainSearchQuery(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleDomainSearch()}
                    />
                  </div>
                  <Button onClick={handleDomainSearch} disabled={isSearching}>
                    {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : "Search"}
                  </Button>
                </div>

                {domainResults.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Available Domains</h3>
                    {domainResults.map((result, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between rounded-lg border border-border/50 p-3 hover:bg-accent/50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <Globe className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{result.domain}</span>
                          {result.available ? (
                            <Badge variant="outline" className="text-green-500 border-green-500/50">
                              Available
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-red-500 border-red-500/50">
                              Taken
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-sm font-medium">{result.price}</span>
                          {result.available && (
                            <Button size="sm">
                              <CheckCircle2 className="h-4 w-4 mr-1" />
                              Purchase
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <Separator />

                <div className="space-y-3">
                  <h3 className="text-sm font-medium">Your Domains</h3>
                  <Card className="bg-accent/50">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Globe className="h-5 w-5 text-green-500" />
                          <div>
                            <p className="font-medium">fiyahcloner.app</p>
                            <p className="text-xs text-muted-foreground">Expires: Dec 31, 2025</p>
                          </div>
                        </div>
                        <Badge>Active</Badge>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Hosting Tab */}
          <TabsContent value="hosting" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Server className="h-5 w-5 text-blue-500" />
                    Hosting Plans
                  </CardTitle>
                  <CardDescription>Choose your hosting package</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    {
                      name: "Starter",
                      price: "$9.99/mo",
                      features: ["1 GB Storage", "10 GB Bandwidth", "1 Domain", "SSL Certificate"],
                    },
                    {
                      name: "Professional",
                      price: "$29.99/mo",
                      features: ["10 GB Storage", "100 GB Bandwidth", "5 Domains", "SSL Certificate", "Auto Backups"],
                    },
                    {
                      name: "Enterprise",
                      price: "$99.99/mo",
                      features: [
                        "Unlimited Storage",
                        "Unlimited Bandwidth",
                        "Unlimited Domains",
                        "SSL Certificate",
                        "Auto Backups",
                        "Priority Support",
                      ],
                    },
                  ].map((plan, index) => (
                    <Card key={index} className="bg-accent/30">
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold">{plan.name}</h4>
                          <span className="text-lg font-bold text-green-500">{plan.price}</span>
                        </div>
                        <ul className="space-y-1 text-sm text-muted-foreground">
                          {plan.features.map((feature, i) => (
                            <li key={i} className="flex items-center gap-2">
                              <CheckCircle2 className="h-3 w-3 text-green-500" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                        <Button className="w-full" variant={index === 1 ? "default" : "outline"}>
                          {index === 1 ? "Current Plan" : "Upgrade"}
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Monitor className="h-5 w-5 text-purple-500" />
                    Server Status
                  </CardTitle>
                  <CardDescription>Real-time server metrics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">CPU Usage</span>
                        <span className="text-sm text-muted-foreground">23%</span>
                      </div>
                      <Progress value={23} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Memory</span>
                        <span className="text-sm text-muted-foreground">1.2 GB / 4 GB</span>
                      </div>
                      <Progress value={30} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Storage</span>
                        <span className="text-sm text-muted-foreground">450 MB / 10 GB</span>
                      </div>
                      <Progress value={4.5} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Bandwidth</span>
                        <span className="text-sm text-muted-foreground">12 GB / 100 GB</span>
                      </div>
                      <Progress value={12} className="h-2" />
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Quick Actions</h4>
                    <div className="grid grid-cols-2 gap-2">
                      <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                        <Database className="h-4 w-4" />
                        Database
                      </Button>
                      <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                        <Shield className="h-4 w-4" />
                        Security
                      </Button>
                      <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                        <Code className="h-4 w-4" />
                        FTP Access
                      </Button>
                      <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                        <RefreshCw className="h-4 w-4" />
                        Backups
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* VoIP & API Tab */}
          <TabsContent value="voip" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Phone className="h-5 w-5 text-cyan-500" />
                    VoIP Services
                  </CardTitle>
                  <CardDescription>Voice over IP configuration</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <Label>Phone Number</Label>
                      <Input placeholder="+1 (555) 123-4567" />
                    </div>
                    <div>
                      <Label>SIP Provider</Label>
                      <Input placeholder="sip.fiyahcloner.com" />
                    </div>
                    <div>
                      <Label>Extension</Label>
                      <Input placeholder="1001" />
                    </div>
                    <Button className="w-full gap-2">
                      <Phone className="h-4 w-4" />
                      Configure VoIP
                    </Button>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Active Numbers</h4>
                    <Card className="bg-accent/50">
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Phone className="h-4 w-4 text-cyan-500" />
                            <span className="text-sm font-medium">+1 (555) 987-6543</span>
                          </div>
                          <Badge variant="outline" className="text-green-500 border-green-500/50">
                            Active
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Key className="h-5 w-5 text-orange-500" />
                    API Management
                  </CardTitle>
                  <CardDescription>Configure API keys and endpoints</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <Label>API Endpoint</Label>
                      <div className="flex gap-2">
                        <Input value="https://api.fiyahcloner.app" readOnly />
                        <Button variant="outline" size="icon">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div>
                      <Label>API Key</Label>
                      <div className="flex gap-2">
                        <Input type="password" value="sk_live_xxxxxxxxxxxxxxxxxxx" readOnly />
                        <Button variant="outline" size="icon">
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <Button className="w-full gap-2">
                      <Key className="h-4 w-4" />
                      Generate New Key
                    </Button>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">API Usage</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Requests Today</span>
                        <span className="font-medium">1,247 / 10,000</span>
                      </div>
                      <Progress value={12.47} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Deploy Tab */}
          <TabsContent value="deploy" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Rocket className="h-5 w-5 text-purple-500" />
                  One-Click Deployment
                </CardTitle>
                <CardDescription>Deploy your application with a single click</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Deployment Status */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">Deployment Status</h3>
                    {deploymentStatus === "idle" && <Badge variant="outline">Ready to Deploy</Badge>}
                    {deploymentStatus === "deploying" && (
                      <Badge variant="outline" className="text-blue-500 border-blue-500/50">
                        <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                        Deploying
                      </Badge>
                    )}
                    {deploymentStatus === "testing" && (
                      <Badge variant="outline" className="text-yellow-500 border-yellow-500/50">
                        <TestTube className="h-3 w-3 mr-1" />
                        Beta Testing
                      </Badge>
                    )}
                    {deploymentStatus === "live" && (
                      <Badge variant="outline" className="text-green-500 border-green-500/50">
                        <CheckCircle2 className="h-3 w-3 mr-1" />
                        Live
                      </Badge>
                    )}
                  </div>

                  {deploymentStatus !== "idle" && (
                    <div>
                      <Progress value={deploymentProgress} className="h-3 mb-2" />
                      <p className="text-sm text-muted-foreground text-center">
                        {deploymentProgress < 100 ? "Deploying..." : "Deployment Complete!"}
                      </p>
                    </div>
                  )}
                </div>

                <Separator />

                {/* Deployment Actions */}
                <div className="space-y-3">
                  {deploymentStatus === "idle" && (
                    <Button className="w-full gap-2" size="lg" onClick={handleOneClickDeploy}>
                      <Rocket className="h-5 w-5" />
                      One-Click Deploy
                    </Button>
                  )}

                  {deploymentStatus === "testing" && (
                    <>
                      <div className="rounded-lg bg-yellow-500/10 border border-yellow-500/50 p-4">
                        <div className="flex items-start gap-3">
                          <TestTube className="h-5 w-5 text-yellow-500 mt-0.5" />
                          <div className="space-y-2 flex-1">
                            <h4 className="font-medium text-yellow-500">Beta Testing Environment</h4>
                            <p className="text-sm text-muted-foreground">
                              Your application is now in beta testing mode. You can test all functionality before going
                              live.
                            </p>
                            <div className="flex gap-2 mt-3">
                              <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                                <ExternalLink className="h-4 w-4" />
                                Visit Beta Site
                              </Button>
                              <Button
                                size="sm"
                                className="gap-2 bg-green-600 hover:bg-green-700"
                                onClick={handleGoLive}
                              >
                                <Play className="h-4 w-4" />
                                Go Live
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  {deploymentStatus === "live" && (
                    <div className="rounded-lg bg-green-500/10 border border-green-500/50 p-4">
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5" />
                        <div className="space-y-2 flex-1">
                          <h4 className="font-medium text-green-500">Your Site is Live!</h4>
                          <p className="text-sm text-muted-foreground">
                            Your application is now live and accessible to the public.
                          </p>
                          <div className="flex gap-2 mt-3">
                            <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                              <ExternalLink className="h-4 w-4" />
                              Visit Live Site
                            </Button>
                            <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                              <Upload className="h-4 w-4" />
                              Deploy Update
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <Separator />

                {/* Deployment History */}
                <div className="space-y-3">
                  <h3 className="text-sm font-medium">Deployment History</h3>
                  <ScrollArea className="h-48">
                    <div className="space-y-2">
                      {[
                        { date: "2025-01-08 14:30", status: "success", version: "v1.2.3" },
                        { date: "2025-01-07 09:15", status: "success", version: "v1.2.2" },
                        { date: "2025-01-06 16:45", status: "success", version: "v1.2.1" },
                        { date: "2025-01-05 11:20", status: "success", version: "v1.2.0" },
                      ].map((deployment, index) => (
                        <Card key={index} className="bg-accent/30">
                          <CardContent className="p-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <CheckCircle2 className="h-4 w-4 text-green-500" />
                                <div>
                                  <p className="text-sm font-medium">{deployment.version}</p>
                                  <p className="text-xs text-muted-foreground">{deployment.date}</p>
                                </div>
                              </div>
                              <Button variant="ghost" size="sm">
                                View
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Manage Tab */}
          <TabsContent value="manage" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5 text-purple-500" />
                    Site Management
                  </CardTitle>
                  <CardDescription>Manage and upgrade your deployed site</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <Button className="w-full justify-start gap-2 bg-transparent" variant="outline">
                      <Code className="h-4 w-4" />
                      Edit Code (AI Backend Studio)
                    </Button>
                    <Button className="w-full justify-start gap-2 bg-transparent" variant="outline">
                      <Database className="h-4 w-4" />
                      Database Management
                    </Button>
                    <Button className="w-full justify-start gap-2 bg-transparent" variant="outline">
                      <Shield className="h-4 w-4" />
                      SSL Certificate
                    </Button>
                    <Button className="w-full justify-start gap-2 bg-transparent" variant="outline">
                      <Zap className="h-4 w-4" />
                      Performance Optimization
                    </Button>
                    <Button className="w-full justify-start gap-2 bg-transparent" variant="outline">
                      <RefreshCw className="h-4 w-4" />
                      Auto-Updates
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-yellow-500" />
                    AI Backend Integration
                  </CardTitle>
                  <CardDescription>Continuous improvement with AI</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="rounded-lg bg-gradient-to-br from-purple-500/10 to-blue-500/10 border border-purple-500/30 p-4">
                    <div className="flex items-start gap-3">
                      <Zap className="h-5 w-5 text-purple-500 mt-0.5" />
                      <div className="space-y-2">
                        <h4 className="font-medium">AI-Powered Updates</h4>
                        <p className="text-sm text-muted-foreground">
                          Your hosting platform is integrated with the AI Backend Studio, allowing you to make instant
                          updates and improvements to your site using AI.
                        </p>
                        <ul className="text-sm text-muted-foreground space-y-1 mt-2">
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Real-time code editing
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Automatic backend generation
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Instant deployment
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Zero downtime updates
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full gap-2">
                    <Code className="h-4 w-4" />
                    Open in AI Backend Studio
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Accessory Store Tab */}
          <TabsContent value="accessories" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5 text-orange-500" />
                  Accessory Store
                </CardTitle>
                <CardDescription>Purchase APIs, VoIP, SSL, and other website essentials</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* API Keys Section */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Key className="h-5 w-5 text-blue-500" />
                    <h3 className="text-lg font-semibold">API Keys</h3>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <Card className="bg-accent/30">
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold">Starter API Package</h4>
                          <Badge variant="outline" className="text-blue-500 border-blue-500/50">
                            100 Credits
                          </Badge>
                        </div>
                        <ul className="space-y-1 text-sm text-muted-foreground">
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            10,000 API calls/month
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Basic rate limiting
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Email support
                          </li>
                        </ul>
                        <Button className="w-full">Purchase (100 Credits)</Button>
                      </CardContent>
                    </Card>

                    <Card className="bg-accent/30">
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold">Professional API Package</h4>
                          <Badge variant="outline" className="text-purple-500 border-purple-500/50">
                            250 Credits
                          </Badge>
                        </div>
                        <ul className="space-y-1 text-sm text-muted-foreground">
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            100,000 API calls/month
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Advanced rate limiting
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Priority support
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Multiple API keys
                          </li>
                        </ul>
                        <Button className="w-full">Purchase (250 Credits)</Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <Separator />

                {/* VoIP Services Section */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Phone className="h-5 w-5 text-cyan-500" />
                    <h3 className="text-lg font-semibold">VoIP Services</h3>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <Card className="bg-accent/30">
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold">Basic VoIP Plan</h4>
                          <Badge variant="outline" className="text-cyan-500 border-cyan-500/50">
                            150 Credits/mo
                          </Badge>
                        </div>
                        <ul className="space-y-1 text-sm text-muted-foreground">
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />1 phone number
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            1,000 minutes/month
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Voicemail & call forwarding
                          </li>
                        </ul>
                        <Button className="w-full">Activate (150 Credits/mo)</Button>
                      </CardContent>
                    </Card>

                    <Card className="bg-accent/30">
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold">Business VoIP Plan</h4>
                          <Badge variant="outline" className="text-purple-500 border-purple-500/50">
                            400 Credits/mo
                          </Badge>
                        </div>
                        <ul className="space-y-1 text-sm text-muted-foreground">
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />5 phone numbers
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Unlimited minutes
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Advanced features & IVR
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Call analytics
                          </li>
                        </ul>
                        <Button className="w-full">Activate (400 Credits/mo)</Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <Separator />

                {/* SSL Certificates Section */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Lock className="h-5 w-5 text-green-500" />
                    <h3 className="text-lg font-semibold">SSL Certificates</h3>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    <Card className="bg-accent/30">
                      <CardContent className="p-4 space-y-3">
                        <h4 className="font-semibold">Standard SSL</h4>
                        <Badge variant="outline" className="text-green-500 border-green-500/50">
                          50 Credits/year
                        </Badge>
                        <ul className="space-y-1 text-sm text-muted-foreground">
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Domain validation
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            256-bit encryption
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Auto-renewal
                          </li>
                        </ul>
                        <Button className="w-full">Purchase (50 Credits)</Button>
                      </CardContent>
                    </Card>

                    <Card className="bg-accent/30">
                      <CardContent className="p-4 space-y-3">
                        <h4 className="font-semibold">Wildcard SSL</h4>
                        <Badge variant="outline" className="text-blue-500 border-blue-500/50">
                          200 Credits/year
                        </Badge>
                        <ul className="space-y-1 text-sm text-muted-foreground">
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Unlimited subdomains
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            256-bit encryption
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Priority support
                          </li>
                        </ul>
                        <Button className="w-full">Purchase (200 Credits)</Button>
                      </CardContent>
                    </Card>

                    <Card className="bg-accent/30">
                      <CardContent className="p-4 space-y-3">
                        <h4 className="font-semibold">EV SSL</h4>
                        <Badge variant="outline" className="text-purple-500 border-purple-500/50">
                          500 Credits/year
                        </Badge>
                        <ul className="space-y-1 text-sm text-muted-foreground">
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Extended validation
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            Green address bar
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            $1M warranty
                          </li>
                        </ul>
                        <Button className="w-full">Purchase (500 Credits)</Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <Separator />

                {/* Credit Balance Display */}
                <Card className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 border-2 border-purple-500/50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-lg">Your Credit Balance</h4>
                        <p className="text-sm text-muted-foreground">All purchases auto-deduct from balance</p>
                      </div>
                      <div className="text-right">
                        <p className="text-3xl font-bold text-purple-500">1,250</p>
                        <p className="text-sm text-muted-foreground">Credits Available</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
