# FIYAHCLONER AI NEXUS - API Documentation

## Overview

This document describes all API routes available in the FIYAHCLONER AI NEXUS platform.

## Authentication

### Admin Login
**Endpoint:** `POST /api/admin/login`

**Request Body:**
\`\`\`json
{
  "email": "string",
  "password": "string"
}
\`\`\`

**Response:**
\`\`\`json
{
  "success": true,
  "token": "string",
  "message": "Login successful"
}
\`\`\`

**Error Response:**
\`\`\`json
{
  "success": false,
  "message": "Invalid credentials"
}
\`\`\`

### Verify Admin Token
**Endpoint:** `POST /api/admin/verify`

**Request Body:**
\`\`\`json
{
  "token": "string"
}
\`\`\`

**Response:**
\`\`\`json
{
  "valid": true
}
\`\`\`

## AI Generation

### Universal AI Generation
**Endpoint:** `POST /api/generate`

**Request Body:**
\`\`\`json
{
  "prompt": "string",
  "type": "text" | "image" | "video" | "voice" | "code"
}
\`\`\`

**Response:**
\`\`\`json
{
  "success": true,
  "result": "string | object",
  "model": "string",
  "processingTime": "number"
}
\`\`\`

### Google AI - Image Generation
**Endpoint:** `POST /api/google-ai/image`

**Request Body:**
\`\`\`json
{
  "prompt": "string",
  "model": "imagen-3" | "imagen-2",
  "size": "1024x1024" | "512x512"
}
\`\`\`

**Response:**
\`\`\`json
{
  "success": true,
  "imageUrl": "string",
  "model": "string"
}
\`\`\`

### Google AI - Video Generation
**Endpoint:** `POST /api/google-ai/video`

**Request Body:**
\`\`\`json
{
  "prompt": "string",
  "duration": "number",
  "resolution": "1080p" | "720p"
}
\`\`\`

**Response:**
\`\`\`json
{
  "success": true,
  "videoUrl": "string",
  "duration": "number"
}
\`\`\`

### Google AI - Voice Generation
**Endpoint:** `POST /api/google-ai/voice`

**Request Body:**
\`\`\`json
{
  "text": "string",
  "voice": "string",
  "language": "string"
}
\`\`\`

**Response:**
\`\`\`json
{
  "success": true,
  "audioUrl": "string",
  "duration": "number"
}
\`\`\`

## Error Handling

All API routes follow consistent error handling:

**Error Response Format:**
\`\`\`json
{
  "success": false,
  "error": "Error message",
  "code": "ERROR_CODE"
}
\`\`\`

**Common Error Codes:**
- `INVALID_INPUT` - Request validation failed
- `UNAUTHORIZED` - Authentication required
- `FORBIDDEN` - Insufficient permissions
- `NOT_FOUND` - Resource not found
- `RATE_LIMIT` - Too many requests
- `SERVER_ERROR` - Internal server error

## Rate Limiting

API routes are subject to rate limiting:
- **Admin routes:** 10 requests per minute
- **AI generation:** 5 requests per minute
- **Other routes:** 30 requests per minute

## Request Headers

All requests should include:
\`\`\`
Content-Type: application/json
\`\`\`

For authenticated routes:
\`\`\`
Authorization: Bearer <token>
\`\`\`

## Response Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `429` - Too Many Requests
- `500` - Internal Server Error

## Examples

### Example: Admin Login
\`\`\`javascript
const response = await fetch('/api/admin/login', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    email: 'sean.federaldirectfunding@gmail.com',
    password: 'Rasta4iva'
  })
});

const data = await response.json();
if (data.success) {
  localStorage.setItem('adminToken', data.token);
}
\`\`\`

### Example: Generate Image
\`\`\`javascript
const response = await fetch('/api/google-ai/image', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    prompt: 'A futuristic AI interface',
    model: 'imagen-3',
    size: '1024x1024'
  })
});

const data = await response.json();
if (data.success) {
  console.log('Image URL:', data.imageUrl);
}
\`\`\`

---

**Version:** 1.0.0  
**Last Updated:** January 2025
