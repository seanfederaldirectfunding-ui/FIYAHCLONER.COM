# Genius AI Assistant - Complete Guide

## Overview

**Genius** is your empathetic, voice-enabled AI customer service assistant built into FIYAHCLONER AI NEXUS. She combines the conversational abilities of ChatGPT with the emotional intelligence of Persado to create engaging, caring interactions.

## Features

### 🎤 Voice Conversation
- **Microphone Input:** Speak naturally to Genius
- **Voice Output:** Hear responses in a human-like female voice
- **Continuous Listening:** Genius listens and responds in real-time
- **Natural Speech:** Uses Web Speech API for recognition and synthesis

### 💝 Emotional Intelligence
- **Empathetic Responses:** Understands and acknowledges your feelings
- **Caring Tone:** Responds with warmth and understanding
- **Emotional Language:** Uses Persado-inspired marketing language
- **Context Awareness:** Remembers conversation history

### 📝 Smart Notepad
- **Automatic Notes:** Genius writes important information for you
- **Editable:** You can add your own notes too
- **Persistent:** Notes stay throughout your session
- **Clear Function:** Easy to clear when done

### 💬 Text Chat
- **Type Messages:** When voice isn't convenient
- **Instant Responses:** Fast AI-powered replies
- **Message History:** See full conversation
- **Timestamps:** Track when messages were sent

## How to Use

### Starting a Voice Conversation

1. **Navigate to Genius**
   - Click "Genius" in the navigation menu
   - Or go to `/genius`

2. **Enable Microphone**
   - Click "Start Voice Chat" button
   - Allow microphone access when prompted
   - The button turns red when listening

3. **Speak Naturally**
   - Talk to Genius like a real person
   - She'll transcribe your speech in real-time
   - Wait for her response

4. **Listen to Response**
   - Genius speaks back to you
   - Voice output is automatic (if enabled)
   - See animated sparkles when she's speaking

### Using Text Chat

1. **Type Your Message**
   - Use the text input at the bottom
   - Press Enter or click Send

2. **Read Response**
   - Genius responds in the chat window
   - Responses appear with smooth animations

### Using the Notepad

1. **Automatic Notes**
   - Genius writes important info automatically
   - Look for the notepad icon to light up

2. **Manual Notes**
   - Click "Notepad" button to show/hide
   - Type your own notes
   - Edit Genius's notes as needed

3. **Clear Notes**
   - Click trash icon to clear all notes
   - Confirm before clearing

## Genius's Personality

### Communication Style
- **Warm & Friendly:** Greets you with enthusiasm
- **Patient:** Takes time to understand your needs
- **Encouraging:** Uses positive reinforcement
- **Professional:** Maintains customer service excellence

### Emotional Language Examples

**Instead of:** "Your order will arrive in 3-5 days."
**Genius says:** "[excited] Great news! Your order is on its way and should arrive within 3-5 days. I know you're eager to receive it!"

**Instead of:** "I can help with that."
**Genius says:** "[empathetic] I completely understand your concern, and I'm here to help you resolve this right away. Let's work through this together."

### When Genius Uses the Notepad

Genius automatically writes to the notepad for:
- ✅ Key action items you need to complete
- ✅ Important dates, times, or numbers
- ✅ Summary of solutions provided
- ✅ Follow-up reminders
- ✅ Contact information
- ✅ Order numbers or tracking codes

## Technical Details

### Voice Technology
- **Speech Recognition:** Web Speech API (Chrome/Edge recommended)
- **Speech Synthesis:** Browser's built-in TTS
- **Voice Selection:** Automatically chooses best female voice
- **Voice Settings:**
  - Rate: 0.95 (slightly slower for clarity)
  - Pitch: 1.1 (slightly higher for warmth)
  - Volume: 1.0 (full volume)

### AI Model
- **Model:** GPT-5 via Vercel AI Gateway
- **Temperature:** 0.8 (creative but consistent)
- **Max Tokens:** 2000 (detailed responses)
- **System Prompt:** Custom emotional intelligence training

### Browser Compatibility

| Feature | Chrome | Edge | Firefox | Safari |
|---------|--------|------|---------|--------|
| Voice Input | ✅ | ✅ | ⚠️ Limited | ⚠️ Limited |
| Voice Output | ✅ | ✅ | ✅ | ✅ |
| Text Chat | ✅ | ✅ | ✅ | ✅ |
| Notepad | ✅ | ✅ | ✅ | ✅ |

**Recommendation:** Use Chrome or Edge for the best voice experience.

## Tips for Best Results

### Voice Conversation
1. **Speak Clearly:** Enunciate words for better recognition
2. **Quiet Environment:** Reduce background noise
3. **Natural Pace:** Don't speak too fast or slow
4. **Complete Thoughts:** Finish sentences before pausing

### Getting Help
1. **Be Specific:** Tell Genius exactly what you need
2. **Provide Context:** Share relevant details
3. **Ask Questions:** Genius loves to clarify
4. **Give Feedback:** Let her know if something isn't clear

### Using Notepad
1. **Review Notes:** Check what Genius writes
2. **Add Details:** Supplement with your own notes
3. **Copy Important Info:** Save notes elsewhere if needed
4. **Clear Regularly:** Start fresh for new topics

## Privacy & Security

### Data Handling
- **Conversations:** Not stored permanently
- **Voice Data:** Processed in browser, not recorded
- **Notepad:** Stored in browser session only
- **No Tracking:** Your conversations are private

### Microphone Access
- **Permission Required:** You control microphone access
- **Revocable:** Disable anytime in browser settings
- **Local Processing:** Speech recognition happens in browser
- **No Recording:** Audio is not saved or transmitted

## Troubleshooting

### Microphone Not Working
1. Check browser permissions
2. Ensure microphone is connected
3. Try refreshing the page
4. Use Chrome or Edge browser

### Voice Output Not Working
1. Check system volume
2. Click the Volume icon to enable
3. Check browser audio permissions
4. Try a different browser

### Genius Not Responding
1. Check internet connection
2. Refresh the page
3. Clear browser cache
4. Try again in a few moments

### Poor Voice Recognition
1. Reduce background noise
2. Speak more clearly
3. Move closer to microphone
4. Try typing instead

## Future Enhancements

### Planned Features
- [ ] ElevenLabs integration for ultra-realistic voice
- [ ] Multiple voice options (male/female, accents)
- [ ] Emotion detection from voice tone
- [ ] Multi-language support
- [ ] Voice commands for actions
- [ ] Conversation history saving
- [ ] Export notepad to file
- [ ] Custom personality settings

### Advanced Capabilities
- [ ] Screen sharing for visual assistance
- [ ] Video call support
- [ ] Real-time translation
- [ ] Sentiment analysis
- [ ] Proactive suggestions
- [ ] Integration with other FIYAHCLONER tools

## API Integration

### Endpoint
\`\`\`typescript
POST /api/genius/chat
\`\`\`

### Request Format
\`\`\`typescript
{
  messages: UIMessage[]
}
\`\`\`

### Response Format
\`\`\`typescript
// Streaming response with:
- Text content
- Emotional tags ([excited], [empathetic], etc.)
- Notepad instructions ([NOTEPAD]...[/NOTEPAD])
\`\`\`

### Example Usage
\`\`\`typescript
import { useChat } from '@ai-sdk/react'
import { DefaultChatTransport } from 'ai'

const { messages, sendMessage } = useChat({
  transport: new DefaultChatTransport({ 
    api: '/api/genius/chat' 
  })
})
\`\`\`

## Support

### Getting Help
- **In-App:** Ask Genius directly
- **Email:** sean.federaldirectfunding@gmail.com
- **Admin Panel:** `/admin` for system status

### Feedback
We'd love to hear your thoughts on Genius:
- What features do you love?
- What could be improved?
- What new capabilities would you like?

---

**Genius is here to help! 💜**

Experience the future of empathetic AI customer service with FIYAHCLONER AI NEXUS.
