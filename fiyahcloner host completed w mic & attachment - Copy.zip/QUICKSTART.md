# FIYAHCLONER AI NEXUS - Quick Start Guide

Get up and running in 5 minutes!

## Step 1: Install Dependencies (1 minute)

\`\`\`bash
npm install
\`\`\`

## Step 2: Set Up Environment Variables (2 minutes)

1. Copy the example file:
   \`\`\`bash
   cp .env.example .env.local
   \`\`\`

2. Get your Stripe keys from: https://dashboard.stripe.com/test/apikeys

3. Add them to `.env.local`:
   \`\`\`env
   STRIPE_SECRET_KEY=sk_test_...
   STRIPE_PUBLISHABLE_KEY=pk_test_...
   NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
   \`\`\`

## Step 3: Run the App (1 minute)

\`\`\`bash
npm run dev
\`\`\`

Open http://localhost:3000

## Step 4: Test Features (1 minute)

### Test Admin Panel
1. Go to http://localhost:3000/admin
2. Login with:
   - Email: `sean.federaldirectfunding@gmail.com`
   - Password: `Rasta4iva`

### Test Stripe Checkout
1. Go to http://localhost:3000/pricing
2. Click "Get Started" on any plan
3. Use test card: `4242 4242 4242 4242`
4. Any future date, any CVC

### Test AI Features
1. Go to homepage
2. Try the Universal AI Maker
3. Enter a prompt and click "Generate"
4. Watch 10 AI models collaborate!

### Test Page Master
1. Scroll to Page Master section
2. Enter a URL (e.g., `https://example.com`)
3. Describe what you want to do
4. Get step-by-step instructions

### Test Digital Handyman
1. Go to http://localhost:3000/handyman
2. Try any tool:
   - Code Analyzer
   - Website Health Check
   - Deployment Tool
   - Migration Tool
   - Error Fixer

## That's It!

You're now running FIYAHCLONER AI NEXUS locally.

## Next Steps

- Read [README.md](./README.md) for full documentation
- Read [DEPLOYMENT.md](./DEPLOYMENT.md) to deploy to Netlify
- Customize the AI models in `components/universal-ai-maker.tsx`
- Add your own pricing in `lib/products.ts`

## Need Help?

Contact: sean.federaldirectfunding@gmail.com
