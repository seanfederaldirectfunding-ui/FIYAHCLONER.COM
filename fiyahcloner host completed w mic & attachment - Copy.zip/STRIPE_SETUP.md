# Stripe Configuration Guide for FIYAHCLONER

## Your Stripe Account Details

- **Account ID**: `acct_1032D82eZvKYlo2C`
- **Test Charge ID**: `ch_3LmjFA2eZvKYlo2C09TLIsrw`
- **Secret Key Format**: `sk_test_51SLAHTAUgbM676qQ...`

## Setup Instructions

### 1. Environment Variables

Add these to your `.env.local` file:

\`\`\`env
# Your actual Stripe secret key (starts with sk_test_)
STRIPE_SECRET_KEY=sk_test_51SLAHTAUgbM676qQ4PKmAzF5CkiWTXIn7Af5QraDELMbLyUDeSyREklNEYvm0YosBoHkofyuiQzllukiICkMCeXC00T0IQT4Ne

# Your Stripe publishable key (starts with pk_test_)
STRIPE_PUBLISHABLE_KEY=pk_test_your_key_here
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_your_key_here
\`\`\`

### 2. Get Your Publishable Key

1. Go to [Stripe Dashboard](https://dashboard.stripe.com/test/apikeys)
2. Copy your **Publishable key** (starts with `pk_test_`)
3. Add it to both `STRIPE_PUBLISHABLE_KEY` and `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`

### 3. Test the Integration

\`\`\`bash
# Test charge retrieval with your credentials
curl https://api.stripe.com/v1/charges/ch_3LmjFA2eZvKYlo2C09TLIsrw \
  -u sk_test_51SLAHTAUgbM676qQ4PKmAzF5CkiWTXIn7Af5QraDELMbLyUDeSyREklNEYvm0YosBoHkofyuiQzllukiICkMCeXC00T0IQT4Ne: \
  -H "Stripe-Account: acct_1032D82eZvKYlo2C" \
  -G
\`\`\`

### 4. Connected Account Configuration

The system is configured to use your connected Stripe account (`acct_1032D82eZvKYlo2C`). This means:

- All checkout sessions are created with your account ID
- Payments are processed through your connected account
- You can manage everything from your Stripe dashboard

### 5. Verify Setup

1. Start your development server: `npm run dev`
2. Navigate to `/pricing`
3. Click "Get Started" on any plan
4. The Stripe checkout should open with your account details

### 6. Production Deployment

When ready for production:

1. Get your **live** keys from [Stripe Dashboard](https://dashboard.stripe.com/apikeys)
2. Replace `sk_test_` with `sk_live_`
3. Replace `pk_test_` with `pk_live_`
4. Update environment variables in Netlify:
   - Go to Site settings → Environment variables
   - Add the live keys
   - Redeploy

### 7. Webhook Configuration (Optional)

For payment confirmations and updates:

1. Go to [Stripe Webhooks](https://dashboard.stripe.com/webhooks)
2. Add endpoint: `https://your-domain.com/api/webhooks/stripe`
3. Select events: `checkout.session.completed`, `payment_intent.succeeded`
4. Copy webhook signing secret
5. Add to `.env.local`: `STRIPE_WEBHOOK_SECRET=whsec_...`

## Testing Payment Flow

### Test Card Numbers

Use these in the Stripe checkout:

- **Success**: `4242 4242 4242 4242`
- **Decline**: `4000 0000 0000 0002`
- **3D Secure**: `4000 0025 0000 3155`

Use any future expiry date and any 3-digit CVC.

## Troubleshooting

### "No such charge" error
- Verify the charge ID: `ch_3LmjFA2eZvKYlo2C09TLIsrw`
- Ensure you're using test mode keys

### "Invalid API key" error
- Check that your secret key starts with `sk_test_`
- Verify no extra spaces in `.env.local`

### Checkout not loading
- Verify `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` is set
- Check browser console for errors
- Ensure publishable key starts with `pk_test_`

## Support

- [Stripe Documentation](https://stripe.com/docs)
- [Stripe Support](https://support.stripe.com/)
- [Test Mode Guide](https://stripe.com/docs/testing)
