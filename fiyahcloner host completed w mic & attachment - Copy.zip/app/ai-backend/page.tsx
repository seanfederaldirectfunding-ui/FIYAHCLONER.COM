import { AIBackendStudio } from "@/components/ai-backend-studio"

export default function AIBackendPage() {
  return (
    <div className="min-h-screen bg-background">
      <AIBackendStudio />
    </div>
  )
}
