export default function CodePage() {
  return (
    <div className="container mx-auto p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">
            AI Code Generation
          </h1>
          <p className="text-lg text-muted-foreground">Generate production-ready code for any platform or language</p>
        </div>

        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <div className="bg-card border border-border rounded-lg p-4">
            <h4 className="font-semibold mb-2">Web Apps</h4>
            <p className="text-xs text-muted-foreground">React, Next.js, Vue, Angular</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4">
            <h4 className="font-semibold mb-2">Mobile Apps</h4>
            <p className="text-xs text-muted-foreground">React Native, Flutter, Swift</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4">
            <h4 className="font-semibold mb-2">Backend</h4>
            <p className="text-xs text-muted-foreground">Node.js, Python, Go, Java</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4">
            <h4 className="font-semibold mb-2">Extensions</h4>
            <p className="text-xs text-muted-foreground">Chrome, VS Code, Browser</p>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4">Generate Code</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">What do you want to build?</label>
                <textarea
                  className="w-full bg-background border border-border rounded-lg p-3 text-sm resize-none"
                  rows={6}
                  placeholder="Describe your project... Example: A task management app with user authentication, real-time updates, and drag-and-drop functionality"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Platform</label>
                <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                  <option>Web App (React/Next.js)</option>
                  <option>Mobile App (React Native)</option>
                  <option>Backend API (Node.js)</option>
                  <option>Chrome Extension</option>
                  <option>VS Code Extension</option>
                  <option>Desktop App (Electron)</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Language</label>
                  <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                    <option>TypeScript</option>
                    <option>JavaScript</option>
                    <option>Python</option>
                    <option>Go</option>
                    <option>Java</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Framework</label>
                  <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                    <option>Next.js</option>
                    <option>React</option>
                    <option>Vue</option>
                    <option>Svelte</option>
                    <option>Express</option>
                  </select>
                </div>
              </div>
              <button className="w-full py-3 bg-gradient-to-r from-yellow-600 to-orange-600 text-white rounded-lg font-semibold hover:opacity-90 transition-opacity">
                Generate Code
              </button>
            </div>

            <div className="bg-background border border-border rounded-lg p-4 font-mono text-xs">
              <div className="text-muted-foreground">
                // Your generated code will appear here
                <br />
                // Ready to copy and use immediately
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
