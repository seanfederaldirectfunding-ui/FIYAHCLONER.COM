export default function VoicePage() {
  return (
    <div className="container mx-auto p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
            AI Voice & Music Generation
          </h1>
          <p className="text-lg text-muted-foreground">Create realistic voices and original music with advanced AI</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-2xl font-semibold mb-4">Voice Synthesis</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Text to Speak</label>
                <textarea
                  className="w-full bg-background border border-border rounded-lg p-3 text-sm resize-none"
                  rows={5}
                  placeholder="Enter the text you want to convert to speech..."
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Voice Model</label>
                <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                  <option>ElevenLabs - Natural (Emotional)</option>
                  <option>Google Gemini TTS (Multilingual)</option>
                  <option>OpenAI TTS (Clear & Professional)</option>
                  <option>Azure Neural Voices (Enterprise)</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Language</label>
                  <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                    <option>English (US)</option>
                    <option>English (UK)</option>
                    <option>Spanish</option>
                    <option>French</option>
                    <option>German</option>
                    <option>Japanese</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Emotion</label>
                  <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                    <option>Neutral</option>
                    <option>Happy</option>
                    <option>Sad</option>
                    <option>Excited</option>
                    <option>Calm</option>
                  </select>
                </div>
              </div>
              <button className="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg font-semibold hover:opacity-90 transition-opacity">
                Generate Voice
              </button>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-2xl font-semibold mb-4">Music Generation</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Music Description</label>
                <textarea
                  className="w-full bg-background border border-border rounded-lg p-3 text-sm resize-none"
                  rows={5}
                  placeholder="Describe the music you want... Example: Upbeat electronic music with piano melodies, perfect for a tech product launch video"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Genre</label>
                <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                  <option>Electronic</option>
                  <option>Ambient</option>
                  <option>Pop</option>
                  <option>Rock</option>
                  <option>Classical</option>
                  <option>Jazz</option>
                  <option>Hip Hop</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Duration</label>
                  <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                    <option>30 seconds</option>
                    <option>1 minute</option>
                    <option>2 minutes</option>
                    <option>3 minutes</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Mood</label>
                  <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                    <option>Energetic</option>
                    <option>Calm</option>
                    <option>Dark</option>
                    <option>Happy</option>
                    <option>Dramatic</option>
                  </select>
                </div>
              </div>
              <button className="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg font-semibold hover:opacity-90 transition-opacity">
                Generate Music
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
