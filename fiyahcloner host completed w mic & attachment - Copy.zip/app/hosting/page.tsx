import { HostingDashboard } from "@/components/hosting-dashboard"

export default function HostingPage() {
  return <HostingDashboard />
}
