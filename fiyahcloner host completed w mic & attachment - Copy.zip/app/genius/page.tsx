import type { Metadata } from "next"
import GeniusAssistant from "@/components/genius-assistant"

export const metadata: Metadata = {
  title: "Genius AI Assistant | FIYAHCLONER",
  description: "Voice-enabled AI customer service with emotional intelligence",
}

export default function GeniusPage() {
  return <GeniusAssistant />
}
