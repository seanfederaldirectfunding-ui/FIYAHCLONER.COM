export default function BusinessPage() {
  return (
    <div className="container mx-auto p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            AI Business Tools
          </h1>
          <p className="text-lg text-muted-foreground">
            Generate business plans, marketing strategies, and more with AI
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-3">Business Plans</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Generate comprehensive business plans with financial projections and market analysis.
            </p>
            <button className="text-sm text-primary hover:underline">Generate →</button>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-3">Marketing Copy</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Create compelling marketing content with emotional language powered by Persado AI.
            </p>
            <button className="text-sm text-primary hover:underline">Generate →</button>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-3">Pitch Decks</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Build investor-ready pitch decks with data visualizations and compelling narratives.
            </p>
            <button className="text-sm text-primary hover:underline">Generate →</button>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4">Generate Business Content</h3>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Content Type</label>
              <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                <option>Business Plan</option>
                <option>Marketing Campaign</option>
                <option>Pitch Deck</option>
                <option>Product Description</option>
                <option>Email Campaign</option>
                <option>Social Media Strategy</option>
                <option>Brand Identity</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Business Details</label>
              <textarea
                className="w-full bg-background border border-border rounded-lg p-3 text-sm resize-none"
                rows={6}
                placeholder="Describe your business, target audience, goals, and any specific requirements..."
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Industry</label>
                <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                  <option>Technology</option>
                  <option>E-commerce</option>
                  <option>Healthcare</option>
                  <option>Finance</option>
                  <option>Education</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Tone</label>
                <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                  <option>Professional</option>
                  <option>Casual</option>
                  <option>Technical</option>
                  <option>Emotional</option>
                  <option>Persuasive</option>
                </select>
              </div>
            </div>
            <button className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:opacity-90 transition-opacity">
              Generate Business Content
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
