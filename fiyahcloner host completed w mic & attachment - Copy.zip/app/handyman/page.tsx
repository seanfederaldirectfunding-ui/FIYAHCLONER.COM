"use client"

import { Header } from "@/components/header"
import { HandymanDashboard } from "@/components/handyman-dashboard"

export default function HandymanPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container px-4 py-8">
        <HandymanDashboard />
      </main>
    </div>
  )
}
