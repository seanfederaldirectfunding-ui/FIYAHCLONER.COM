import { Hero } from "@/components/hero"
import { UniversalAIMaker } from "@/components/universal-ai-maker"
import { PageMaster } from "@/components/page-master"
import { GoogleAIShowcase } from "@/components/google-ai-showcase"
import { AICapabilities } from "@/components/ai-capabilities"
import { ModelShowcase } from "@/components/model-showcase"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <main>
        <Hero />
        <UniversalAIMaker />
        <div id="page-master-section">
          <PageMaster />
        </div>
        <GoogleAIShowcase />
        <AICapabilities />
        <ModelShowcase />
      </main>
    </div>
  )
}
