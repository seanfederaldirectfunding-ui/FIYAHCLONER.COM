import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"

export const runtime = "edge"
export const maxDuration = 60

export async function POST(req: NextRequest) {
  try {
    const { query, frontendCode, analysis } = await req.json()

    if (!query) {
      return NextResponse.json({ error: "Query is required" }, { status: 400 })
    }

    // Use AI to generate backend solution
    const { text } = await generateText({
      model: "openai/gpt-4o",
      system: `You are a Level 5 Backend Developer and Software Engineering Expert. You have mastery in:
- Node.js, Express, Next.js API Routes, and serverless functions
- Database design (SQL, NoSQL, ORMs like Prisma, Drizzle)
- Authentication & Authorization (JWT, OAuth, sessions)
- API design (REST, GraphQL, tRPC)
- Error handling and validation
- Security best practices
- Performance optimization

When given a frontend code problem, you provide:
1. Complete, production-ready backend code
2. Proper error handling and validation
3. Type-safe implementations
4. Security considerations
5. Database schemas if needed
6. Step-by-step integration instructions

Always provide working, copy-paste-ready code.`,
      prompt: `Frontend Code Problem:
${query}

${frontendCode ? `\nFull Frontend Context:\n${frontendCode}` : ""}

${analysis ? `\nAnalysis:\n${JSON.stringify(analysis, null, 2)}` : ""}

Provide the complete backend solution with all necessary code files.`,
    })

    return NextResponse.json({ solution: text })
  } catch (error) {
    console.error("[v0] AI Assistance error:", error)
    return NextResponse.json(
      { error: "Failed to generate solution", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}
