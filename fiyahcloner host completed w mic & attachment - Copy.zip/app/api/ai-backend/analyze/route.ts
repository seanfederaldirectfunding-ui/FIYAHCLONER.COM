import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { code } = await request.json()

    if (!code || typeof code !== "string") {
      return NextResponse.json({ error: "Invalid code provided" }, { status: 400 })
    }

    const analysis = {
      components: extractComponents(code),
      apiCalls: extractAPICalls(code),
      stateManagement: extractStateManagement(code),
      forms: extractForms(code),
      database: needsDatabase(code),
      auth: needsAuth(code),
    }

    return NextResponse.json({
      success: true,
      analysis,
    })
  } catch (error) {
    console.error("[v0] Frontend analysis error:", error)
    return NextResponse.json(
      { error: "Analysis failed", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}

function extractComponents(code: string): string[] {
  const components: string[] = []
  const componentRegex = /(?:function|const|class)\s+([A-Z][a-zA-Z0-9]*)/g
  let match
  while ((match = componentRegex.exec(code)) !== null) {
    components.push(match[1])
  }
  return [...new Set(components)]
}

function extractAPICalls(code: string): string[] {
  const apis: string[] = []
  const fetchRegex = /fetch\(['"`]([^'"`]+)['"`]/g
  let match
  while ((match = fetchRegex.exec(code)) !== null) {
    apis.push(match[1])
  }
  return [...new Set(apis)]
}

function extractStateManagement(code: string): string[] {
  const states: string[] = []
  const stateRegex = /useState$$$$/g
  const matches = code.match(stateRegex)
  if (matches) {
    states.push("React useState")
  }
  if (code.includes("useReducer")) states.push("React useReducer")
  if (code.includes("Redux")) states.push("Redux")
  if (code.includes("Zustand")) states.push("Zustand")
  return states
}

function extractForms(code: string): string[] {
  const forms: string[] = []
  if (code.includes("<form")) forms.push("HTML Form")
  if (code.includes("useForm")) forms.push("React Hook Form")
  if (code.includes("Formik")) forms.push("Formik")
  return forms
}

function needsDatabase(code: string): boolean {
  return (
    code.includes("fetch") &&
    (code.includes("POST") || code.includes("GET") || code.includes("PUT") || code.includes("DELETE"))
  )
}

function needsAuth(code: string): boolean {
  return code.includes("login") || code.includes("auth") || code.includes("token") || code.includes("session")
}
