import { type NextRequest, NextResponse } from "next/server"
import crypto from "crypto"

const MASTER_ADMIN_EMAIL = "sean.federaldirectfunding@gmail.com"
// Password: Rasta4iva (hashed with SHA-256)
const MASTER_ADMIN_PASSWORD_HASH = "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918"

function hashPassword(password: string): string {
  try {
    return crypto.createHash("sha256").update(password).digest("hex")
  } catch (error) {
    console.error("[v0] Password hashing error:", error)
    throw new Error("Failed to hash password")
  }
}

function generateToken(): string {
  try {
    return crypto.randomBytes(32).toString("hex")
  } catch (error) {
    console.error("[v0] Token generation error:", error)
    throw new Error("Failed to generate token")
  }
}

export async function POST(request: NextRequest) {
  try {
    // Parse request body with error handling
    let body
    try {
      body = await request.json()
    } catch (parseError) {
      console.error("[v0] JSON parse error:", parseError)
      return NextResponse.json({ success: false, message: "Invalid request format" }, { status: 400 })
    }

    const { email, password } = body

    // Validate input presence
    if (!email || !password) {
      return NextResponse.json({ success: false, message: "Email and password are required" }, { status: 400 })
    }

    // Validate input types
    if (typeof email !== "string" || typeof password !== "string") {
      return NextResponse.json({ success: false, message: "Invalid input types" }, { status: 400 })
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json({ success: false, message: "Invalid email format" }, { status: 400 })
    }

    // Validate password length
    if (password.length < 6 || password.length > 100) {
      return NextResponse.json({ success: false, message: "Invalid password length" }, { status: 400 })
    }

    // Hash password with error handling
    let passwordHash
    try {
      passwordHash = hashPassword(password)
    } catch (hashError) {
      console.error("[v0] Password hashing failed:", hashError)
      return NextResponse.json({ success: false, message: "Authentication error" }, { status: 500 })
    }

    // Check credentials
    if (email === MASTER_ADMIN_EMAIL && passwordHash === MASTER_ADMIN_PASSWORD_HASH) {
      // Generate secure session token with error handling
      let token
      try {
        token = generateToken()
      } catch (tokenError) {
        console.error("[v0] Token generation failed:", tokenError)
        return NextResponse.json({ success: false, message: "Session creation error" }, { status: 500 })
      }

      return NextResponse.json(
        {
          success: true,
          message: "Login successful",
          token,
          user: {
            email: MASTER_ADMIN_EMAIL,
            role: "master_admin",
          },
        },
        { status: 200 },
      )
    } else {
      // Invalid credentials - use same message for security
      return NextResponse.json({ success: false, message: "Invalid email or password" }, { status: 401 })
    }
  } catch (error) {
    console.error("[v0] Admin login error:", error)
    return NextResponse.json({ success: false, message: "Internal server error" }, { status: 500 })
  }
}
