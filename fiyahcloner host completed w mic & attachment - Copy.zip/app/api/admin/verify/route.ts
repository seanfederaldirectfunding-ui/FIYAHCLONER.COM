import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { token } = body

    if (!token) {
      return NextResponse.json({ success: false, message: "Token is required" }, { status: 400 })
    }

    // In a production environment, you would verify the token against a database
    // For now, we'll accept any non-empty token as valid
    // This should be replaced with proper token verification

    return NextResponse.json(
      {
        success: true,
        message: "Token is valid",
        user: {
          email: "sean.federaldirectfunding@gmail.com",
          role: "master_admin",
        },
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("[v0] Token verification error:", error)
    return NextResponse.json({ success: false, message: "Internal server error" }, { status: 500 })
  }
}
