export default function VideoPage() {
  return (
    <div className="container mx-auto p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
            AI Video Generation
          </h1>
          <p className="text-lg text-muted-foreground">Create professional videos with cutting-edge AI technology</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-3">Generator 1</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Cinematic quality with superior physics realism using advanced diffusion models. Up to 60 seconds, 4K
              resolution.
            </p>
            <div className="flex items-center gap-2 text-sm text-green-500">
              <div className="h-2 w-2 rounded-full bg-green-500"></div>
              Online
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-3">Generator 2</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Best for creative professionals using advanced temporal consistency. Multi-scene consistency and character
              preservation.
            </p>
            <div className="flex items-center gap-2 text-sm text-green-500">
              <div className="h-2 w-2 rounded-full bg-green-500"></div>
              Online
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-3">Generator 3</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Realistic human motion and photorealistic scenes using neural video synthesis. Perfect for brand content.
            </p>
            <div className="flex items-center gap-2 text-sm text-green-500">
              <div className="h-2 w-2 rounded-full bg-green-500"></div>
              Online
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4">Generate Video</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Video Description</label>
                <textarea
                  className="w-full bg-background border border-border rounded-lg p-3 text-sm resize-none"
                  rows={6}
                  placeholder="Describe your video scene... Example: A cinematic shot of a drone flying over a mountain range at sunset, with dramatic clouds and golden lighting"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Model</label>
                <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                  <option>Generator 1 (Cinematic & Physics)</option>
                  <option>Generator 2 (Creative)</option>
                  <option>Generator 3 (Realistic Motion)</option>
                  <option>Kling AI (Photorealistic)</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Duration</label>
                  <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                    <option>5 seconds</option>
                    <option>10 seconds</option>
                    <option>15 seconds</option>
                    <option>30 seconds</option>
                    <option>60 seconds</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Resolution</label>
                  <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                    <option>1080p (HD)</option>
                    <option>1440p (2K)</option>
                    <option>2160p (4K)</option>
                  </select>
                </div>
              </div>
              <button className="w-full py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg font-semibold hover:opacity-90 transition-opacity">
                Generate Video
              </button>
            </div>

            <div className="bg-background border border-border rounded-lg flex items-center justify-center min-h-[400px]">
              <p className="text-muted-foreground text-sm">Your generated video will appear here</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
