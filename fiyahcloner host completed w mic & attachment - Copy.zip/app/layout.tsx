import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import "./globals.css"
import { Sidebar } from "@/components/sidebar"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "FIYAHCLONER - AI NEXUS | The Ultimate AI Platform",
  description: "Combine the power of top AI models for text, images, video, voice, music, and code generation",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`font-sans antialiased`}>
        <Sidebar />
        <main className="ml-64 min-h-screen transition-all">{children}</main>
      </body>
    </html>
  )
}
