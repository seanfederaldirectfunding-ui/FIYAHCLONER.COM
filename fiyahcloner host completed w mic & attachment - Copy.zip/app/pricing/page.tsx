import type { Metadata } from "next"
import PricingCards from "@/components/pricing-cards"

export const metadata: Metadata = {
  title: "Pricing - FIYAHCLONER",
  description: "Choose the perfect plan for your AI needs",
}

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      <div className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
            Choose Your Power Level
          </h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Unlock the full potential of 10 collaborative AI models working together to create anything you imagine
          </p>
        </div>

        <PricingCards />
      </div>
    </div>
  )
}
