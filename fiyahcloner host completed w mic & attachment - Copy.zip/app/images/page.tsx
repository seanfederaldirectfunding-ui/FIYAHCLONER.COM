export default function ImagesPage() {
  return (
    <div className="container mx-auto p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
            AI Image Generation
          </h1>
          <p className="text-lg text-muted-foreground">
            Create stunning, photorealistic images with the world's best AI models
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-3">Generator 1</h3>
            <p className="text-sm text-muted-foreground mb-4">
              High-quality, cinematic images with rich textures and vibrant colors. Best for architectural and
              structured designs. Powered by advanced diffusion technology.
            </p>
            <div className="flex items-center gap-2 text-sm text-green-500">
              <div className="h-2 w-2 rounded-full bg-green-500"></div>
              Online
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-3">Generator 2</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Enterprise-grade photorealism and detail using advanced neural rendering. Perfect for product shots and
              portraits.
            </p>
            <div className="flex items-center gap-2 text-sm text-green-500">
              <div className="h-2 w-2 rounded-full bg-green-500"></div>
              Online
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-3">Generator 3</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Gold standard for artistic quality using advanced latent diffusion. Unmatched aesthetic and cinematic
              shots.
            </p>
            <div className="flex items-center gap-2 text-sm text-green-500">
              <div className="h-2 w-2 rounded-full bg-green-500"></div>
              Online
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4">Generate Image</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Prompt</label>
                <textarea
                  className="w-full bg-background border border-border rounded-lg p-3 text-sm resize-none"
                  rows={6}
                  placeholder="Describe your image in detail... Example: A photorealistic portrait of a woman with curly hair, wearing a red dress, standing in a field of sunflowers at golden hour"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Model</label>
                <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                  <option>Generator 1 (Fast & High Quality)</option>
                  <option>Generator 2 (Photorealistic)</option>
                  <option>Generator 3 (Artistic)</option>
                  <option>Stable Diffusion XL (Customizable)</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Size</label>
                  <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                    <option>1024x1024 (Square)</option>
                    <option>1024x768 (Landscape)</option>
                    <option>768x1024 (Portrait)</option>
                    <option>1920x1080 (HD)</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Quality</label>
                  <select className="w-full bg-background border border-border rounded-lg p-3 text-sm">
                    <option>Standard</option>
                    <option>High</option>
                    <option>Ultra</option>
                  </select>
                </div>
              </div>
              <button className="w-full py-3 bg-gradient-to-r from-pink-600 to-purple-600 text-white rounded-lg font-semibold hover:opacity-90 transition-opacity">
                Generate Image
              </button>
            </div>

            <div className="bg-background border border-border rounded-lg flex items-center justify-center min-h-[400px]">
              <p className="text-muted-foreground text-sm">Your generated image will appear here</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
