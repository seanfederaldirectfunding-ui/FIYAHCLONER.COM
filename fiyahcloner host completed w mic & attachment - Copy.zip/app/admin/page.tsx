"use client"

import { useState, useEffect } from "react"
import { AdminLogin } from "@/components/admin-login"
import { AdminDashboard } from "@/components/admin-dashboard"

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is already logged in
    const checkAuth = async () => {
      const token = localStorage.getItem("admin_token")

      if (token) {
        try {
          const response = await fetch("/api/admin/verify", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ token }),
          })

          const data = await response.json()

          if (response.ok && data.success) {
            setIsAuthenticated(true)
          } else {
            // Invalid token, clear storage
            localStorage.removeItem("admin_token")
            localStorage.removeItem("admin_email")
            localStorage.removeItem("admin_login_time")
          }
        } catch (error) {
          console.error("[v0] Auth check error:", error)
        }
      }

      setIsLoading(false)
    }

    checkAuth()
  }, [])

  const handleLoginSuccess = () => {
    setIsAuthenticated(true)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return isAuthenticated ? <AdminDashboard /> : <AdminLogin onLoginSuccess={handleLoginSuccess} />
}
