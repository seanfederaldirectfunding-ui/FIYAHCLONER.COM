'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export function AutomatedDeployment() {
  const [gitConfig, setGitConfig] = useState({
    repository: '',
    branch: '',
    token: '',
  });
  const [hosting, setHosting] = useState('');
  const [deploymentPipeline, setDeploymentPipeline] = useState<string[]>([]);
  const [deploying, setDeploying] = useState(false);
  const [deployLogs, setDeployLogs] = useState('');

  const hostingProviders = [
    { id: 'netlify', name: 'Netlify', icon: '🌐' },
    { id: 'vercel', name: 'Vercel', icon: '▲' },
    { id: 'aws', name: 'AWS', icon: '☁️' },
    { id: 'heroku', name: 'Heroku', icon: '🟣' },
    { id: 'digitalocean', name: 'DigitalOcean', icon: '🌊' },
    { id: 'cloudflare', name: 'Cloudflare Pages', icon: '🔶' },
    { id: 'github', name: 'GitHub Pages', icon: '🐙' },
    { id: 'firebase', name: 'Firebase', icon: '🔥' },
  ];

  const handleAutomatedDeploy = async () => {
    setDeploying(true);
    setDeployLogs('Starting automated deployment...\n\n');

    const steps = [
      { stage: 'Git Clone', action: `Cloning repository: ${gitConfig.repository}` },
      { stage: 'Git Clone', action: `Checking out branch: ${gitConfig.branch || 'main'}` },
      { stage: 'Dependencies', action: 'Installing npm dependencies...' },
      { stage: 'Dependencies', action: 'Resolving package versions...' },
      { stage: 'Build', action: 'Running build command...' },
      { stage: 'Build', action: 'Compiling TypeScript/JavaScript...' },
      { stage: 'Build', action: 'Bundling assets...' },
      { stage: 'Build', action: 'Optimizing for production...' },
      { stage: 'Tests', action: 'Running unit tests...' },
      { stage: 'Tests', action: 'All tests passed ✓' },
      { stage: 'Pre-Deploy', action: 'Minifying CSS/JS...' },
      { stage: 'Pre-Deploy', action: 'Optimizing images...' },
      { stage: 'Pre-Deploy', action: 'Generating sitemap...' },
      { stage: 'Deploy', action: `Deploying to ${hosting || 'selected hosting'}...` },
      { stage: 'Deploy', action: 'Uploading build artifacts...' },
      { stage: 'Deploy', action: 'Configuring server...' },
      { stage: 'Post-Deploy', action: 'Purging CDN cache...' },
      { stage: 'Post-Deploy', action: 'Updating DNS records...' },
      { stage: 'Post-Deploy', action: 'Installing SSL certificate...' },
      { stage: 'Verification', action: 'Running health checks...' },
      { stage: 'Verification', action: 'Testing endpoints...' },
      { stage: 'Complete', action: '✅ Deployment successful!' },
      { stage: 'Complete', action: `Site is live at: https://your-site.${hosting || 'hosting'}.app` },
    ];

    for (const step of steps) {
      await new Promise(resolve => setTimeout(resolve, 500));
      setDeployLogs(prev => prev + `[${step.stage}] ${step.action}\n`);
      setDeploymentPipeline(prev => [...prev, step.stage]);
    }

    setDeploying(false);
  };

  const deploymentStages = [
    { name: 'Source', icon: '📦', steps: ['Git Clone', 'Code Checkout'] },
    { name: 'Build', icon: '🔨', steps: ['Install Deps', 'Compile', 'Bundle'] },
    { name: 'Test', icon: '✅', steps: ['Unit Tests', 'Integration Tests'] },
    { name: 'Deploy', icon: '🚀', steps: ['Upload', 'Configure', 'Activate'] },
    { name: 'Verify', icon: '🔍', steps: ['Health Check', 'Smoke Tests'] },
  ];

  return (
    <div className="border-t border-white/10 bg-[#1c1c1c] py-8">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
          <span className="text-green-400">🚀</span> CI/CD Automated Deployment Pipeline
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Git Configuration */}
          <div className="bg-[#2a2a2a] border border-white/10 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <span>🐙</span> Git Repository
            </h3>
            <div className="space-y-3">
              <div>
                <label className="text-sm text-gray-400 block mb-1">Repository URL</label>
                <Input
                  placeholder="https://github.com/username/repo.git"
                  value={gitConfig.repository}
                  onChange={(e) => setGitConfig({...gitConfig, repository: e.target.value})}
                  className="bg-[#1c1c1c] border-white/20 text-white"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400 block mb-1">Branch</label>
                <Input
                  placeholder="main or master"
                  value={gitConfig.branch}
                  onChange={(e) => setGitConfig({...gitConfig, branch: e.target.value})}
                  className="bg-[#1c1c1c] border-white/20 text-white"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400 block mb-1">Access Token (Optional)</label>
                <Input
                  type="password"
                  placeholder="ghp_xxxxxxxxxxxx"
                  value={gitConfig.token}
                  onChange={(e) => setGitConfig({...gitConfig, token: e.target.value})}
                  className="bg-[#1c1c1c] border-white/20 text-white"
                />
              </div>
            </div>
          </div>

          {/* Hosting Selection */}
          <div className="bg-[#2a2a2a] border border-white/10 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Select Hosting Provider</h3>
            <div className="grid grid-cols-2 gap-3">
              {hostingProviders.map(provider => (
                <button
                  key={provider.id}
                  onClick={() => setHosting(provider.id)}
                  className={`p-3 rounded-lg border text-left transition-all ${
                    hosting === provider.id
                      ? 'border-blue-500 bg-blue-500/10'
                      : 'border-white/10 hover:border-white/30'
                  }`}
                >
                  <div className="text-2xl mb-1">{provider.icon}</div>
                  <div className="text-sm text-white font-medium">{provider.name}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Deployment Pipeline Visualization */}
        <div className="bg-[#2a2a2a] border border-white/10 rounded-lg p-6 mb-6">
          <h3 className="text-lg font-semibold text-white mb-4">Deployment Pipeline</h3>
          <div className="flex items-center justify-between gap-4 overflow-x-auto pb-4">
            {deploymentStages.map((stage, index) => (
              <div key={stage.name} className="flex items-center gap-4">
                <div className="text-center min-w-[120px]">
                  <div className={`text-4xl mb-2 ${deploymentPipeline.includes(stage.name) ? 'opacity-100' : 'opacity-30'}`}>
                    {stage.icon}
                  </div>
                  <div className="text-white font-semibold text-sm">{stage.name}</div>
                  <div className="text-xs text-gray-400 mt-1">
                    {stage.steps.map((step, i) => (
                      <div key={i}>{step}</div>
                    ))}
                  </div>
                </div>
                {index < deploymentStages.length - 1 && (
                  <div className="text-2xl text-gray-600">→</div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Deploy Button */}
        <div className="bg-[#2a2a2a] border border-white/10 rounded-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-sm text-gray-400">
              {deploying ? 'Deployment in progress...' : 'Ready to deploy your application'}
            </div>
            <Button
              onClick={handleAutomatedDeploy}
              disabled={deploying || !gitConfig.repository || !hosting}
              className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-semibold px-8 py-6 text-lg"
            >
              {deploying ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Deploying...
                </span>
              ) : (
                '🚀 Deploy to Production'
              )}
            </Button>
          </div>
        </div>

        {/* Deployment Logs */}
        {deployLogs && (
          <div className="bg-[#2a2a2a] border border-white/10 rounded-lg p-6">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <span>📋</span> Deployment Logs
            </h3>
            <pre className="text-sm text-green-400 font-mono whitespace-pre-wrap bg-black/50 p-4 rounded max-h-96 overflow-y-auto">
              {deployLogs}
            </pre>
          </div>
        )}

        {/* Quick Deploy Options */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-[#2a2a2a] border border-blue-500/30 rounded-lg p-4">
            <h4 className="text-white font-semibold mb-2">⚡ Instant Deploy</h4>
            <p className="text-xs text-gray-400">Deploy directly from GitHub with zero configuration</p>
          </div>
          <div className="bg-[#2a2a2a] border border-green-500/30 rounded-lg p-4">
            <h4 className="text-white font-semibold mb-2">🔄 Auto Updates</h4>
            <p className="text-xs text-gray-400">Automatically deploy on every git push</p>
          </div>
          <div className="bg-[#2a2a2a] border border-purple-500/30 rounded-lg p-4">
            <h4 className="text-white font-semibold mb-2">🌍 Global CDN</h4>
            <p className="text-xs text-gray-400">Deploy to edge servers worldwide for fast loading</p>
          </div>
        </div>
      </div>
    </div>
  );
}
