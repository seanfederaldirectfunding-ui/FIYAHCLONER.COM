'use client';

export function ProjectShowcase() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-16">
      <h2 className="text-center text-gray-400 text-lg mb-12">Build with Fiyah Cloner</h2>

      <div className="text-center py-12">
        <p className="text-gray-500">Your projects will appear here</p>
      </div>
    </div>
  );
}
