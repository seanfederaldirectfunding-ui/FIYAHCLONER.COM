'use client';

import { useState, useRef, useEffect } from 'react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: "👋 Hi! I'm your Fiyah Cloner AI assistant. I can help you with:\n\n• Digital Handyman service\n• Automated deployments\n• CI/CD pipelines\n• Website migrations\n• Expert tools (22+ tools)\n• Pricing information\n• General support\n\nWhat would you like to know?"
    }
  ]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();

    // Pricing questions
    if (lowerMessage.includes('price') || lowerMessage.includes('cost') || lowerMessage.includes('pricing')) {
      return "💰 **Fiyah Cloner Pricing - Flat Fees:**\n\n• **Simple Website:** $25/site\n• **Functioning Application:** $100/site\n• **Mobile App:** $100/app\n• **Website Deployer:** $25/site\n• **Handyman Subscription:** $25/month\n\n*Flat rate is better than spinning your wheels!*\n\nClick 'Pricing' in the navigation to see full details.";
    }

    // Digital Handyman
    if (lowerMessage.includes('handyman') || lowerMessage.includes('repair') || lowerMessage.includes('fix')) {
      return "🛠️ **Digital Handyman Service:**\n\n1. Enter your website URL in the input field\n2. Click the orange 'DIGITAL HANDYMAN' button\n3. Wait 4 seconds for analysis\n4. Get comprehensive report with:\n   ✓ Code quality assessment\n   ✓ Security audit\n   ✓ Performance optimization\n   ✓ UX/UI enhancements\n   ✓ And 5 more analysis points!\n\nOur elite team (L5-L1 Engineers, T5-T1 Support) is ready to help!";
    }

    // Deployment
    if (lowerMessage.includes('deploy') || lowerMessage.includes('host') || lowerMessage.includes('launch')) {
      return "🚀 **Deployment Options:**\n\n**Automated Deployment:**\n1. Fill in 4 provider links (Domain, Hosting, API, VoIP)\n2. See green checkmarks appear\n3. Click 'Deploy Website'\n\n**CI/CD Pipeline:**\n1. Enter Git repository URL\n2. Choose from 8 hosting providers\n3. Click 'Deploy to Production'\n4. Watch real-time logs\n\nSupported platforms: Netlify, Vercel, AWS, Heroku, DigitalOcean, Cloudflare Pages, GitHub Pages, Firebase";
    }

    // Migration
    if (lowerMessage.includes('migrat') || lowerMessage.includes('move') || lowerMessage.includes('transfer')) {
      return "🔄 **Website Migration Tools:**\n\n**20-Step Automated Process:**\n1. Configure source server (FTP/SSH)\n2. Configure target server\n3. Click 'Start Complete Migration'\n\nWe handle:\n✓ File transfer\n✓ Database migration\n✓ DNS configuration\n✓ SSL setup\n✓ URL replacement\n✓ Zero downtime\n\nProfessional-grade migration from any host to any host!";
    }

    // Expert Tools
    if (lowerMessage.includes('tools') || lowerMessage.includes('expert') || lowerMessage.includes('optimization')) {
      return "🧰 **22+ Expert Tools Available:**\n\n**Performance (3):** PageSpeed Optimizer, Image Optimizer, Cache Manager\n\n**Security (3):** Security Scanner, SSL Manager, Web Firewall\n\n**Database (3):** DB Optimizer, DB Backup, DB Migration\n\n**Code Quality (3):** Code Analyzer, Dependency Updater, Linter\n\n**SEO (3):** SEO Auditor, Sitemap Generator, Schema Markup\n\n**Plus:** Debugging, Backup, and Monitoring tools!\n\nAll tools include real-time results and professional-grade analysis.";
    }

    // Project Actions
    if (lowerMessage.includes('download') || lowerMessage.includes('ios') || lowerMessage.includes('android') || lowerMessage.includes('app')) {
      return "📱 **Project Actions:**\n\n1. **Download Files:** Get your project as .zip file\n2. **Connect Integrations:** Link external services\n3. **Create iOS App:** Build .ipa file (3 seconds)\n4. **Create Android App:** Build .apk file (3 seconds)\n\nAll actions are one-click and instant!";
    }

    // Getting started
    if (lowerMessage.includes('start') || lowerMessage.includes('begin') || lowerMessage.includes('how to') || lowerMessage.includes('tutorial')) {
      return "🎯 **Getting Started:**\n\n**No login required!** All features are immediately accessible.\n\n**Quick Start:**\n1. Try Digital Handyman - Enter a URL and analyze\n2. Explore Expert Tools - 22+ professional tools\n3. Check Pricing - Transparent flat fees\n4. Contact Support - Phone or email anytime\n\n**Popular Features:**\n• Website analysis & repair\n• Automated deployments\n• Website migrations\n• Mobile app creation\n\nEverything works right now - no setup needed!";
    }

    // Support/Contact
    if (lowerMessage.includes('support') || lowerMessage.includes('help') || lowerMessage.includes('contact') || lowerMessage.includes('phone')) {
      return "📞 **Contact Support:**\n\n**Phone:** 201-640-4635\n**Email:** sean.federaldirectfunding@gmail.com\n\n**Support Hours:** Available to assist you\n\nClick the blue 'Support' button (bottom right) to send us a message directly!\n\nWe're here to help with any questions or issues.";
    }

    // Features overview
    if (lowerMessage.includes('feature') || lowerMessage.includes('what can') || lowerMessage.includes('capabilities')) {
      return "✨ **Fiyah Cloner Features:**\n\n🔥 **Digital Handyman** - Website analysis & repair\n🚀 **CI/CD Pipeline** - Automated deployments\n🔄 **Migration Tools** - Server-to-server transfers\n🧰 **22+ Expert Tools** - Performance, security, SEO\n📱 **App Creation** - iOS & Android builds\n💬 **AI Assistant** - That's me!\n📞 **24/7 Support** - Phone & email\n💰 **Flat Pricing** - No surprises\n\nAll features work without login - try them now!";
    }

    // Default helpful response
    return "I can help you with:\n\n• **Pricing** - View our flat-rate fees\n• **Digital Handyman** - Website analysis\n• **Deployment** - Launch your site\n• **Migration** - Move between hosts\n• **Expert Tools** - 22+ professional tools\n• **Support** - Contact information\n\nJust ask me about any feature! For example:\n- 'How much does it cost?'\n- 'How do I deploy?'\n- 'Tell me about expert tools'\n- 'How do I contact support?'";
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = input.trim();
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setInput('');
    setTyping(true);

    setTimeout(() => {
      const response = getResponse(userMessage);
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
      setTyping(false);
    }, 1000);
  };

  return (
    <>
      {/* Floating Chatbot Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 left-6 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-full p-4 shadow-lg hover:shadow-xl transition-all z-50 flex items-center gap-2"
        aria-label="AI Assistant"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="currentColor"/>
          <circle cx="8.5" cy="10.5" r="1.5" fill="currentColor"/>
          <circle cx="15.5" cy="10.5" r="1.5" fill="currentColor"/>
          <path d="M12 17c2.21 0 4-1.79 4-4h-8c0 2.21 1.79 4 4 4z" fill="currentColor"/>
        </svg>
        <span className="font-semibold">AI Help</span>
      </button>

      {/* Chatbot Window */}
      {isOpen && (
        <div className="fixed bottom-24 left-6 w-96 max-w-[calc(100vw-3rem)] bg-[#2a2a2a] border border-white/10 rounded-2xl shadow-2xl z-50 flex flex-col max-h-[600px]">
          {/* Header */}
          <div className="bg-gradient-to-r from-green-600 to-blue-600 p-4 rounded-t-2xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
              <h3 className="font-bold text-white">AI Assistant</h3>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white hover:bg-white/20 rounded-lg p-1"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl p-3 ${
                    msg.role === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-[#1c1c1c] text-white border border-white/10'
                  }`}
                >
                  <p className="text-sm whitespace-pre-line">{msg.content}</p>
                </div>
              </div>
            ))}
            {typing && (
              <div className="flex justify-start">
                <div className="bg-[#1c1c1c] border border-white/10 rounded-2xl p-3">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <form onSubmit={handleSubmit} className="p-4 border-t border-white/10">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask me anything..."
                className="flex-1 bg-[#1c1c1c] border border-white/20 rounded-lg px-4 py-2 text-white placeholder:text-gray-500 text-sm"
              />
              <button
                type="submit"
                className="bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-lg px-4 py-2 hover:opacity-90 transition-opacity"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            </div>
          </form>
        </div>
      )}
    </>
  );
}
