'use client';

import { useState } from 'react';
import { authSystem, type User } from '@/lib/auth-system';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (user: User) => void;
}

export function AuthModal({ isOpen, onClose, onLogin }: AuthModalProps) {
  const [mode, setMode] = useState<'login' | 'signup' | 'biometric'>('login');
  const [email, setEmail] = useState('');
  const [pin, setPin] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handlePinLogin = async () => {
    setError('');
    setLoading(true);

    try {
      const user = await authSystem.loginWithPin(email, pin);
      if (user) {
        onLogin(user);
        onClose();
      } else {
        setError('Invalid email or PIN');
      }
    } catch (err) {
      setError('Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleBiometricLogin = async () => {
    setError('');
    setLoading(true);

    try {
      const thumbprint = await authSystem.requestBiometric();
      const user = await authSystem.loginWithThumbprint(email, thumbprint);

      if (user) {
        onLogin(user);
        onClose();
      } else {
        setError('Thumbprint not recognized. Please register your thumbprint first.');
      }
    } catch (err) {
      setError('Biometric authentication failed');
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterThumbprint = async () => {
    setError('');
    setLoading(true);

    try {
      const thumbprint = await authSystem.requestBiometric();
      const success = await authSystem.registerThumbprint(email, pin, thumbprint);

      if (success) {
        alert('Thumbprint registered successfully! You can now login with your thumbprint.');
        setMode('login');
      } else {
        setError('Failed to register thumbprint. Please verify your email and PIN.');
      }
    } catch (err) {
      setError('Thumbprint registration failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async () => {
    setError('');
    setLoading(true);

    try {
      const user = await authSystem.registerTenant(email, name, pin);
      if (user) {
        alert('Account created successfully! You can now login.');
        setMode('login');
        setName('');
      }
    } catch (err: any) {
      setError(err.message || 'Signup failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
      <div className="bg-[#2a2a2a] rounded-2xl max-w-md w-full p-8 border border-white/10">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">
            {mode === 'login' && 'Login'}
            {mode === 'signup' && 'Sign Up'}
            {mode === 'biometric' && 'Register Thumbprint'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </div>

        {/* Login Mode */}
        {mode === 'login' && (
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-400 block mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your.email@example.com"
                className="w-full bg-[#1c1c1c] border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-gray-500 focus:outline-none focus:border-orange-500/50"
              />
            </div>

            <div>
              <label className="text-sm text-gray-400 block mb-2">PIN (4 digits)</label>
              <input
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="••••"
                maxLength={4}
                className="w-full bg-[#1c1c1c] border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-gray-500 focus:outline-none focus:border-orange-500/50"
              />
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-3 text-red-400 text-sm">
                {error}
              </div>
            )}

            <button
              onClick={handlePinLogin}
              disabled={loading || !email || !pin}
              className="w-full bg-orange-500 text-white font-semibold py-3 rounded-lg hover:bg-orange-600 transition-colors disabled:opacity-50"
            >
              {loading ? 'Logging in...' : 'Login with PIN'}
            </button>

            <button
              onClick={handleBiometricLogin}
              disabled={loading || !email}
              className="w-full bg-blue-500 text-white font-semibold py-3 rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="currentColor"/>
                <path d="M12 6c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6z" fill="currentColor"/>
              </svg>
              Login with Thumbprint
            </button>

            <div className="border-t border-white/10 pt-4 space-y-2">
              <button
                onClick={() => setMode('signup')}
                className="w-full text-gray-400 hover:text-white text-sm"
              >
                Don't have an account? Sign up
              </button>
              <button
                onClick={() => setMode('biometric')}
                className="w-full text-gray-400 hover:text-white text-sm"
              >
                Register thumbprint
              </button>
            </div>

            <div className="mt-4 p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
              <p className="text-xs text-green-400 font-semibold">Admin Access:</p>
              <p className="text-xs text-gray-400 mt-1">Email: sean.federaldirectfunding@gmail.com</p>
              <p className="text-xs text-gray-400">PIN: 6347</p>
            </div>
          </div>
        )}

        {/* Signup Mode */}
        {mode === 'signup' && (
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-400 block mb-2">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="John Doe"
                className="w-full bg-[#1c1c1c] border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-gray-500 focus:outline-none focus:border-orange-500/50"
              />
            </div>

            <div>
              <label className="text-sm text-gray-400 block mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your.email@example.com"
                className="w-full bg-[#1c1c1c] border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-gray-500 focus:outline-none focus:border-orange-500/50"
              />
            </div>

            <div>
              <label className="text-sm text-gray-400 block mb-2">PIN (4 digits)</label>
              <input
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                placeholder="••••"
                maxLength={4}
                className="w-full bg-[#1c1c1c] border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-gray-500 focus:outline-none focus:border-orange-500/50"
              />
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-3 text-red-400 text-sm">
                {error}
              </div>
            )}

            <button
              onClick={handleSignup}
              disabled={loading || !email || !name || pin.length !== 4}
              className="w-full bg-orange-500 text-white font-semibold py-3 rounded-lg hover:bg-orange-600 transition-colors disabled:opacity-50"
            >
              {loading ? 'Creating account...' : 'Create Account'}
            </button>

            <button
              onClick={() => setMode('login')}
              className="w-full text-gray-400 hover:text-white text-sm"
            >
              Already have an account? Login
            </button>

            <div className="text-xs text-gray-500 text-center">
              Tenant capacity: {authSystem.getTenantCount()}/10,000
            </div>
          </div>
        )}

        {/* Biometric Registration Mode */}
        {mode === 'biometric' && (
          <div className="space-y-4">
            <div className="text-center mb-4">
              <div className="text-6xl mb-4">👆</div>
              <p className="text-gray-400 text-sm">
                Register your thumbprint for quick and secure login
              </p>
            </div>

            <div>
              <label className="text-sm text-gray-400 block mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your.email@example.com"
                className="w-full bg-[#1c1c1c] border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-gray-500 focus:outline-none focus:border-orange-500/50"
              />
            </div>

            <div>
              <label className="text-sm text-gray-400 block mb-2">PIN (for verification)</label>
              <input
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="••••"
                maxLength={4}
                className="w-full bg-[#1c1c1c] border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-gray-500 focus:outline-none focus:border-orange-500/50"
              />
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-3 text-red-400 text-sm">
                {error}
              </div>
            )}

            <button
              onClick={handleRegisterThumbprint}
              disabled={loading || !email || !pin}
              className="w-full bg-blue-500 text-white font-semibold py-3 rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50"
            >
              {loading ? 'Scanning thumbprint...' : 'Scan & Register Thumbprint'}
            </button>

            <button
              onClick={() => setMode('login')}
              className="w-full text-gray-400 hover:text-white text-sm"
            >
              Back to login
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
