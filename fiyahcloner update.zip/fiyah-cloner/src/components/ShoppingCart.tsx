'use client';

import { useCart } from '@/lib/cart-context';
import { useState } from 'react';
import { loadStripe, type Stripe } from '@stripe/stripe-js';

const stripePromise = loadStripe('pk_test_51SLAHrPLTUnnpuk4jdDZuszGTRyMap1cVPzlMZtkPSux8msR8UEkHknfOGnhylZg0tPyQtM6WZD8tyWwH9DW6NkR00DBHnbkkG');

export function ShoppingCart() {
  const { items, removeItem, clearCart, totalPrice, itemCount } = useCart();
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleCheckout = async () => {
    if (items.length === 0) return;
    setIsLoading(true);
    try {
      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items }),
      });

      if (!response.ok) {
        throw new Error('Checkout failed');
      }

      const { sessionId, error } = await response.json();

      if (error) {
        alert(error);
        return;
      }

      const stripe = await stripePromise;
      if (stripe && sessionId) {
        // @ts-expect-error - Stripe types issue in iframe environment
        const result = await stripe.redirectToCheckout({ sessionId });
        if (result.error) {
          console.error('Stripe error:', result.error);
          alert('Payment failed. Please try again.');
        }
      }
    } catch (error) {
      console.error('Checkout error:', error);
      alert('Checkout failed. Please make sure your Stripe secret key is configured.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-24 right-6 bg-orange-500 text-white rounded-full p-4 shadow-lg hover:bg-orange-600 transition-all z-40"
      >
        Cart {itemCount > 0 && `(${itemCount})`}
      </button>
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex justify-end">
          <div className="w-full md:w-96 bg-[#2a2a2a] h-full flex flex-col">
            <div className="p-6 border-b border-white/10">
              <button onClick={() => setIsOpen(false)} className="text-white">Close</button>
            </div>
            <div className="flex-1 p-6 overflow-y-auto">
              {items.map((item, i) => (
                <div key={i} className="mb-4 p-4 bg-[#1c1c1c] rounded text-white">
                  <p>{item.name} - ${item.price}</p>
                  <button onClick={() => removeItem(item.id)} className="text-red-400">Remove</button>
                </div>
              ))}
            </div>
            <div className="p-6 border-t border-white/10">
              <p className="text-white mb-4">Total: ${totalPrice}</p>
              <button
                onClick={handleCheckout}
                disabled={isLoading}
                className="w-full bg-orange-500 text-white py-3 rounded"
              >
                {isLoading ? 'Processing...' : 'Checkout'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
