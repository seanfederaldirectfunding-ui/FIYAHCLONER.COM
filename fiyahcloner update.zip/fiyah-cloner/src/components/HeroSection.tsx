'use client';

import { useState } from 'react';

export function HeroSection() {
  const [prompt, setPrompt] = useState('');

  return (
    <div className="max-w-4xl mx-auto px-6 py-20">
      <div className="text-center space-y-4 mb-12">
        <h1 className="text-6xl md:text-7xl font-bold text-white">
          Make anything
        </h1>
        <p className="text-xl text-gray-400">
          Build websites by chatting with AI
        </p>
      </div>

      <div className="relative">
        <div className="bg-[#2a2a2a] border border-white/10 rounded-2xl overflow-hidden">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Build an AI-powered personal finance tracker"
            className="w-full bg-transparent text-white placeholder:text-gray-500 px-6 py-4 min-h-[120px] resize-none focus:outline-none"
          />

          <div className="border-t border-white/10 px-6 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button className="p-1 hover:bg-white/10 rounded transition-colors">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M10 5v10M5 10h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </button>

              <div className="flex items-center gap-2 px-3 py-1 bg-white/5 rounded-md text-sm text-gray-300">
                <span>claude-4.5-sonnet</span>
              </div>
            </div>

            <button className="p-2 bg-white text-black rounded-full hover:bg-gray-200 transition-colors">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M5 10l5 5 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" transform="rotate(-90 10 10)"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
