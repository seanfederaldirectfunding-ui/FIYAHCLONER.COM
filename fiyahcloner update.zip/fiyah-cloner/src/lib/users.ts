// User Management System
// Supports 1 Master Account + 10,000 Tenant Accounts

export interface User {
  id: string;
  username: string;
  password: string;
  email: string;
  role: 'master' | 'tenant';
  createdAt: string;
  lastLogin?: string;
}

// In-memory user storage (for production, use a database)
const users: User[] = [];

// Master Account - Sean A Thompson
export const MASTER_USERNAME = 'Sthompson72';
export const MASTER_PASSWORD = 'Rasta4iva!';
export const MASTER_EMAIL = 'sean.federaldirectfunding@gmail.com';

// Initialize master account
export function initializeMasterAccount() {
  const masterExists = users.find(u => u.username === MASTER_USERNAME);

  if (!masterExists) {
    users.push({
      id: 'master-001',
      username: MASTER_USERNAME,
      password: MASTER_PASSWORD,
      email: MASTER_EMAIL,
      role: 'master',
      createdAt: new Date().toISOString(),
    });
  }
}

// Initialize system
initializeMasterAccount();

// Authenticate user
export function authenticateUser(username: string, password: string): User | null {
  const user = users.find(u => u.username === username && u.password === password);

  if (user) {
    // Update last login
    user.lastLogin = new Date().toISOString();
    return user;
  }

  return null;
}

// Get user by username
export function getUserByUsername(username: string): User | null {
  return users.find(u => u.username === username) || null;
}

// Get user by ID
export function getUserById(id: string): User | null {
  return users.find(u => u.id === id) || null;
}

// Create new tenant account
export function createTenantAccount(username: string, password: string, email: string): User | null {
  // Check if username already exists
  if (users.find(u => u.username === username)) {
    return null;
  }

  // Check if we've reached the 10,000 tenant limit
  const tenantCount = users.filter(u => u.role === 'tenant').length;
  if (tenantCount >= 10000) {
    throw new Error('Maximum tenant limit (10,000) reached');
  }

  const newUser: User = {
    id: `tenant-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    username,
    password,
    email,
    role: 'tenant',
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);
  return newUser;
}

// Get all users (master only)
export function getAllUsers(): User[] {
  return users;
}

// Get user count
export function getUserCount(): { total: number; master: number; tenants: number } {
  return {
    total: users.length,
    master: users.filter(u => u.role === 'master').length,
    tenants: users.filter(u => u.role === 'tenant').length,
  };
}

// Delete tenant account (master only)
export function deleteTenantAccount(userId: string): boolean {
  const userIndex = users.findIndex(u => u.id === userId && u.role === 'tenant');

  if (userIndex !== -1) {
    users.splice(userIndex, 1);
    return true;
  }

  return false;
}
