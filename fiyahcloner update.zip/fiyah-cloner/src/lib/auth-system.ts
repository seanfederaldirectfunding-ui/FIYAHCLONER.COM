'use client';

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'tenant';
  pin?: string;
  thumbprint?: string;
  createdAt: Date;
  tenantId?: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
}

// Admin credentials
const ADMIN_USER: User = {
  id: 'admin-001',
  email: 'sean.federaldirectfunding@gmail.com',
  name: 'Sean Thompson',
  role: 'admin',
  pin: '6347',
  createdAt: new Date('2024-01-01'),
};

// In-memory tenant storage (in production, this would be a database)
const tenants: User[] = [];

export class AuthSystem {
  private static instance: AuthSystem;

  private constructor() {}

  static getInstance(): AuthSystem {
    if (!AuthSystem.instance) {
      AuthSystem.instance = new AuthSystem();
    }
    return AuthSystem.instance;
  }

  async loginWithPin(email: string, pin: string): Promise<User | null> {
    // Check admin login
    if (email === ADMIN_USER.email && pin === ADMIN_USER.pin) {
      return ADMIN_USER;
    }

    // Check tenant login
    const tenant = tenants.find(t => t.email === email && t.pin === pin);
    return tenant || null;
  }

  async loginWithThumbprint(email: string, thumbprint: string): Promise<User | null> {
    // Check admin thumbprint
    if (email === ADMIN_USER.email && ADMIN_USER.thumbprint === thumbprint) {
      return ADMIN_USER;
    }

    // Check tenant thumbprint
    const tenant = tenants.find(t => t.email === email && t.thumbprint === thumbprint);
    return tenant || null;
  }

  async registerThumbprint(email: string, pin: string, thumbprint: string): Promise<boolean> {
    // Register admin thumbprint
    if (email === ADMIN_USER.email && pin === ADMIN_USER.pin) {
      ADMIN_USER.thumbprint = thumbprint;
      return true;
    }

    // Register tenant thumbprint
    const tenant = tenants.find(t => t.email === email && t.pin === pin);
    if (tenant) {
      tenant.thumbprint = thumbprint;
      return true;
    }

    return false;
  }

  async registerTenant(email: string, name: string, pin: string): Promise<User | null> {
    // Check if tenant limit reached
    if (tenants.length >= 10000) {
      throw new Error('Maximum tenant limit (10,000) reached');
    }

    // Check if email already exists
    if (tenants.some(t => t.email === email)) {
      throw new Error('Email already registered');
    }

    const newTenant: User = {
      id: `tenant-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      email,
      name,
      role: 'tenant',
      pin,
      createdAt: new Date(),
      tenantId: `tenant-${tenants.length + 1}`,
    };

    tenants.push(newTenant);
    return newTenant;
  }

  getTenantCount(): number {
    return tenants.length;
  }

  getAllTenants(): User[] {
    return tenants.map(t => ({ ...t, pin: undefined, thumbprint: undefined }));
  }

  async requestBiometric(): Promise<string> {
    // Simulate biometric capture
    return new Promise((resolve) => {
      // In a real app, this would use WebAuthn or browser biometric APIs
      const thumbprint = `thumb_${Date.now()}_${Math.random().toString(36).substr(2, 16)}`;
      resolve(thumbprint);
    });
  }
}

export const authSystem = AuthSystem.getInstance();
