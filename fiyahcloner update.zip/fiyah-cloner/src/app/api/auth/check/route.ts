import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export async function GET() {
  try {
    const cookieStore = await cookies();
    const sessionCookie = cookieStore.get('session');

    if (sessionCookie) {
      const session = JSON.parse(sessionCookie.value);
      return NextResponse.json({
        loggedIn: true,
        user: session
      });
    }

    return NextResponse.json({
      loggedIn: false
    });
  } catch (error) {
    return NextResponse.json({
      loggedIn: false
    });
  }
}
