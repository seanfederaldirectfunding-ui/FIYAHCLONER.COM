import { NextResponse } from 'next/server';
import { authenticateUser } from '@/lib/users';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { username, password } = body;

    console.log('=== LOGIN ATTEMPT ===');
    console.log('Username:', username);

    // Authenticate user
    const user = authenticateUser(username, password);

    if (user) {
      console.log('✅ LOGIN SUCCESS - User authenticated:', user.username, 'Role:', user.role);

      // Create session data (exclude password)
      const sessionData = {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        loggedIn: true,
        loginTime: new Date().toISOString(),
      };

      // Create response
      const response = NextResponse.json({
        success: true,
        user: sessionData,
      });

      // Set session cookie
      response.cookies.set('session', JSON.stringify(sessionData), {
        httpOnly: false,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 60 * 60 * 24 * 7, // 7 days
        path: '/',
      });

      console.log('✅ Session cookie set');
      return response;
    } else {
      console.log('❌ LOGIN FAILED - Invalid credentials');

      return NextResponse.json(
        {
          success: false,
          error: 'Invalid username or password'
        },
        { status: 401 }
      );
    }
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { success: false, error: 'An error occurred during login' },
      { status: 500 }
    );
  }
}
