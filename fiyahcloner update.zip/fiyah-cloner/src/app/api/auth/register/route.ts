import { NextResponse } from 'next/server';
import { createTenantAccount, getUserCount } from '@/lib/users';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { username, password, email } = body;

    console.log('=== REGISTRATION ATTEMPT ===');
    console.log('Username:', username);
    console.log('Email:', email);

    // Validate input
    if (!username || !password || !email) {
      return NextResponse.json(
        { success: false, error: 'All fields are required' },
        { status: 400 }
      );
    }

    // Check current user count
    const userCount = getUserCount();
    console.log('Current tenant count:', userCount.tenants, '/ 10,000');

    // Create tenant account
    try {
      const newUser = createTenantAccount(username, password, email);

      if (!newUser) {
        return NextResponse.json(
          { success: false, error: 'Username already exists' },
          { status: 409 }
        );
      }

      console.log('✅ REGISTRATION SUCCESS - New tenant created:', newUser.username);

      // Return user data (exclude password)
      return NextResponse.json({
        success: true,
        user: {
          id: newUser.id,
          username: newUser.username,
          email: newUser.email,
          role: newUser.role,
        },
      });
    } catch (error: any) {
      if (error instanceof Error && error.message.includes('Maximum tenant limit')) {
        return NextResponse.json(
          { success: false, error: 'Maximum tenant limit (10,000) reached' },
          { status: 503 }
        );
      }
      throw error;
    }
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { success: false, error: 'An error occurred during registration' },
      { status: 500 }
    );
  }
}
