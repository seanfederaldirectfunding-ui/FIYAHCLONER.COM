import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { getAllUsers, getUserCount, deleteTenantAccount } from '@/lib/users';

export async function GET() {
  try {
    const cookieStore = await cookies();
    const sessionCookie = cookieStore.get('session');

    if (!sessionCookie) {
      return NextResponse.json(
        { success: false, error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = JSON.parse(sessionCookie.value);

    // Check if user is master
    if (session.role !== 'master') {
      return NextResponse.json(
        { success: false, error: 'Access denied. Master account required.' },
        { status: 403 }
      );
    }

    // Get all users
    const users = getAllUsers();
    const userCount = getUserCount();

    // Return users without passwords
    const safeUsers = users.map(u => ({
      id: u.id,
      username: u.username,
      email: u.email,
      role: u.role,
      createdAt: u.createdAt,
      lastLogin: u.lastLogin,
    }));

    return NextResponse.json({
      success: true,
      users: safeUsers,
      count: userCount,
    });
  } catch (error) {
    console.error('Get users error:', error);
    return NextResponse.json(
      { success: false, error: 'An error occurred' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const cookieStore = await cookies();
    const sessionCookie = cookieStore.get('session');

    if (!sessionCookie) {
      return NextResponse.json(
        { success: false, error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = JSON.parse(sessionCookie.value);

    // Check if user is master
    if (session.role !== 'master') {
      return NextResponse.json(
        { success: false, error: 'Access denied. Master account required.' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { userId } = body;

    const deleted = deleteTenantAccount(userId);

    if (deleted) {
      return NextResponse.json({
        success: true,
        message: 'User deleted successfully',
      });
    } else {
      return NextResponse.json(
        { success: false, error: 'User not found or cannot be deleted' },
        { status: 404 }
      );
    }
  } catch (error) {
    console.error('Delete user error:', error);
    return NextResponse.json(
      { success: false, error: 'An error occurred' },
      { status: 500 }
    );
  }
}
