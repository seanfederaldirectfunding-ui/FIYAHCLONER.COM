import { NextResponse } from 'next/server';
import type { CartItem } from '@/lib/cart-context';

export async function POST(request: Request) {
  try {
    // Check if Stripe secret key is configured
    if (!process.env.STRIPE_SECRET_KEY || process.env.STRIPE_SECRET_KEY === 'sk_test_your_secret_key_here') {
      return NextResponse.json(
        { error: 'Stripe secret key not configured. Please add your Stripe secret key to .env.local' },
        { status: 500 }
      );
    }

    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
    const { items }: { items: CartItem[] } = await request.json();

    if (!items || items.length === 0) {
      return NextResponse.json(
        { error: 'No items in cart' },
        { status: 400 }
      );
    }

    const lineItems = items.map((item) => ({
      price_data: {
        currency: 'usd',
        product_data: {
          name: item.name,
          description: item.description,
        },
        unit_amount: item.price * 100,
      },
      quantity: 1,
    }));

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: lineItems,
      mode: 'payment',
      success_url: `${request.headers.get('origin')}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${request.headers.get('origin')}/pricing`,
    });

    return NextResponse.json({ sessionId: session.id });
  } catch (error) {
    console.error('Stripe error:', error);
    return NextResponse.json(
      { error: 'Error creating checkout session. Please check your Stripe configuration.' },
      { status: 500 }
    );
  }
}
