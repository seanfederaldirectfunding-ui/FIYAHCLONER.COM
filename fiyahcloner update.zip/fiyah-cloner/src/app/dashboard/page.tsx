'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { DeploymentSlots } from '@/components/DeploymentSlots';
import { HeroSection } from '@/components/HeroSection';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { MigrationTools } from '@/components/MigrationTools';
import { ExpertTools } from '@/components/ExpertTools';
import { AutomatedDeployment } from '@/components/AutomatedDeployment';

interface User {
  id: string;
  username: string;
  email: string;
  role: string;
  createdAt?: string;
  lastLogin?: string;
}

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<User[]>([]);
  const [userCount, setUserCount] = useState({ total: 0, master: 0, tenants: 0 });
  const [showAdmin, setShowAdmin] = useState(false);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Check localStorage first
        const storedSession = localStorage.getItem('user_session');
        if (storedSession) {
          const session = JSON.parse(storedSession);
          setUser(session);
          setLoading(false);

          // If master, fetch user data
          if (session.role === 'master') {
            fetchUsers();
          }
          return;
        }

        // Check server
        const response = await fetch('/api/auth/check');
        const data = await response.json();

        if (data.loggedIn) {
          setUser(data.user);
          localStorage.setItem('user_session', JSON.stringify(data.user));
          setLoading(false);

          // If master, fetch user data
          if (data.user.role === 'master') {
            fetchUsers();
          }
        } else {
          localStorage.removeItem('user_session');
          router.push('/login');
        }
      } catch (error) {
        console.error('Auth check failed:', error);
        localStorage.removeItem('user_session');
        router.push('/login');
      }
    };

    checkAuth();
  }, [router]);

  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/admin/users');
      const data = await response.json();

      if (data.success) {
        setUsers(data.users);
        setUserCount(data.count);
      }
    } catch (error) {
      console.error('Failed to fetch users:', error);
    }
  };

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    localStorage.removeItem('user_session');
    router.push('/login');
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user?')) return;

    try {
      const response = await fetch('/api/admin/users', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });

      if (response.ok) {
        fetchUsers(); // Refresh user list
      }
    } catch (error) {
      console.error('Failed to delete user:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#1c1c1c] text-white flex items-center justify-center">
        <div className="text-gray-400">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#1c1c1c] text-white">
      {/* Header */}
      <header className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="3" y="3" width="8" height="8" fill="white"/>
              <rect x="13" y="3" width="8" height="8" fill="white"/>
              <rect x="3" y="13" width="8" height="8" fill="white"/>
              <rect x="13" y="13" width="8" height="8" fill="white"/>
            </svg>
            <span className="text-xl font-bold">Fiyah Cloner</span>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <a href="#" className="text-sm text-gray-300 hover:text-white transition-colors">
              Docs
            </a>
            <a href="#" className="text-sm text-gray-300 hover:text-white transition-colors">
              Careers
            </a>
            <div className="flex items-center gap-3 ml-4 pl-4 border-l border-white/10">
              <span className="text-sm text-gray-400">
                {user?.username} {user?.role === 'master' && <span className="text-yellow-400">(Master)</span>}
              </span>
              {user?.role === 'master' && (
                <Button
                  onClick={() => setShowAdmin(!showAdmin)}
                  className="text-sm px-3 py-1 bg-blue-600 hover:bg-blue-700"
                >
                  {showAdmin ? 'Hide' : 'Show'} Admin
                </Button>
              )}
              <Button
                onClick={handleLogout}
                className="text-sm px-3 py-1 bg-red-600 hover:bg-red-700"
              >
                Logout
              </Button>
            </div>
          </nav>
        </div>
      </header>

      {/* Admin Panel (Master Only) */}
      {user?.role === 'master' && showAdmin && (
        <div className="border-b border-white/10 bg-[#2a2a2a]">
          <div className="max-w-7xl mx-auto px-6 py-6">
            <h2 className="text-2xl font-bold mb-4">Admin Panel</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-[#1c1c1c] border border-white/10 rounded-lg p-4">
                <div className="text-gray-400 text-sm">Total Users</div>
                <div className="text-3xl font-bold text-white">{userCount.total}</div>
              </div>
              <div className="bg-[#1c1c1c] border border-white/10 rounded-lg p-4">
                <div className="text-gray-400 text-sm">Master Accounts</div>
                <div className="text-3xl font-bold text-yellow-400">{userCount.master}</div>
              </div>
              <div className="bg-[#1c1c1c] border border-white/10 rounded-lg p-4">
                <div className="text-gray-400 text-sm">Tenant Accounts</div>
                <div className="text-3xl font-bold text-green-400">{userCount.tenants} / 10,000</div>
              </div>
            </div>

            <div className="bg-[#1c1c1c] border border-white/10 rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#2a2a2a] border-b border-white/10">
                    <tr>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Username</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Email</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Role</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Created</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((u) => (
                      <tr key={u.id} className="border-b border-white/10">
                        <td className="px-4 py-3 text-sm text-white">{u.username}</td>
                        <td className="px-4 py-3 text-sm text-gray-300">{u.email}</td>
                        <td className="px-4 py-3 text-sm">
                          <span className={u.role === 'master' ? 'text-yellow-400' : 'text-green-400'}>
                            {u.role}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-400">
                          {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : 'N/A'}
                        </td>
                        <td className="px-4 py-3 text-sm">
                          {u.role === 'tenant' && (
                            <Button
                              onClick={() => handleDeleteUser(u.id)}
                              className="px-2 py-1 bg-red-600 hover:bg-red-700 text-xs"
                            >
                              Delete
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      <DeploymentSlots />
      <AutomatedDeployment />
      <MigrationTools />
      <ExpertTools />
      <HeroSection />
      <Footer />
    </div>
  );
}
