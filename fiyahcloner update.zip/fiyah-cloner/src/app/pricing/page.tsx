'use client';

import Link from 'next/link';
import { SupportButton } from '@/components/SupportButton';
import { Chatbot } from '@/components/Chatbot';
import { useCart } from '@/lib/cart-context';

export default function PricingPage() {
  const { addItem } = useCart();
  return (
    <div className="min-h-screen bg-[#1c1c1c] text-white">
      {/* Header */}
      <header className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="3" y="3" width="8" height="8" fill="white"/>
              <rect x="13" y="3" width="8" height="8" fill="white"/>
              <rect x="3" y="13" width="8" height="8" fill="white"/>
              <rect x="13" y="13" width="8" height="8" fill="white"/>
            </svg>
            <div className="flex flex-col">
              <span className="text-xl font-bold leading-none">Fiyah Cloner</span>
              <span className="text-xs text-gray-400 leading-none mt-0.5">a division of Fiyah Production llc</span>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm text-gray-300 hover:text-white transition-colors">
              Home
            </Link>
            <Link href="/pricing" className="text-sm text-white font-semibold">
              Pricing
            </Link>
            <a href="#" className="text-sm text-gray-300 hover:text-white transition-colors">
              Docs
            </a>
            <a href="#" className="text-sm text-gray-300 hover:text-white transition-colors">
              Careers
            </a>
          </nav>
        </div>
      </header>

      {/* Pricing Content */}
      <div className="max-w-6xl mx-auto px-6 py-16">
        {/* Title Section */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-4">FLAT FEES</h1>
          <p className="text-xl text-gray-400 mb-2">Simple, transparent pricing</p>
          <p className="text-lg text-orange-400 font-semibold">Flat rate is better than spinning your wheels</p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {/* Simple Website */}
          <div className="bg-[#2a2a2a] border border-white/10 rounded-2xl p-8 hover:border-blue-500/50 transition-all">
            <div className="text-center">
              <div className="text-4xl mb-4">🌐</div>
              <h3 className="text-2xl font-bold mb-2">Simple Display Website</h3>
              <div className="text-5xl font-bold text-blue-400 mb-2">$25</div>
              <p className="text-gray-400 mb-6">per site</p>
              <div className="border-t border-white/10 pt-6 text-left space-y-3">
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Professional design</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Responsive layout</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Fast delivery</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">SEO optimized</span>
                </div>
              </div>
              <button
                onClick={() => addItem({
                  id: 'simple-website',
                  name: 'Simple Display Website',
                  price: 25,
                  description: 'Professional responsive website',
                  emoji: '🌐'
                })}
                className="w-full mt-6 bg-blue-500 text-white font-semibold py-3 rounded-lg hover:bg-blue-600 transition-colors"
              >
                Add to Cart
              </button>
            </div>
          </div>

          {/* Functioning Application */}
          <div className="bg-[#2a2a2a] border border-orange-500/50 rounded-2xl p-8 hover:border-orange-500 transition-all relative">
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
              <span className="bg-orange-500 text-white text-xs font-bold px-3 py-1 rounded-full">POPULAR</span>
            </div>
            <div className="text-center">
              <div className="text-4xl mb-4">⚙️</div>
              <h3 className="text-2xl font-bold mb-2">Functioning Application Site</h3>
              <div className="text-5xl font-bold text-orange-400 mb-2">$100</div>
              <p className="text-gray-400 mb-6">per site</p>
              <div className="border-t border-white/10 pt-6 text-left space-y-3">
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Full functionality</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Database integration</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">User authentication</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">API integration</span>
                </div>
              </div>
              <button
                onClick={() => addItem({
                  id: 'functioning-app',
                  name: 'Functioning Application Site',
                  price: 100,
                  description: 'Full-featured web application',
                  emoji: '⚙️'
                })}
                className="w-full mt-6 bg-orange-500 text-white font-semibold py-3 rounded-lg hover:bg-orange-600 transition-colors"
              >
                Add to Cart
              </button>
            </div>
          </div>

          {/* Mobile App */}
          <div className="bg-[#2a2a2a] border border-white/10 rounded-2xl p-8 hover:border-purple-500/50 transition-all">
            <div className="text-center">
              <div className="text-4xl mb-4">📱</div>
              <h3 className="text-2xl font-bold mb-2">Mobile App</h3>
              <div className="text-5xl font-bold text-purple-400 mb-2">$100</div>
              <p className="text-gray-400 mb-6">per app</p>
              <div className="border-t border-white/10 pt-6 text-left space-y-3">
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">iOS & Android</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Native performance</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">App store ready</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Push notifications</span>
                </div>
              </div>
              <button
                onClick={() => addItem({
                  id: 'mobile-app',
                  name: 'Mobile App',
                  price: 100,
                  description: 'iOS & Android app',
                  emoji: '📱'
                })}
                className="w-full mt-6 bg-purple-500 text-white font-semibold py-3 rounded-lg hover:bg-purple-600 transition-colors"
              >
                Add to Cart
              </button>
            </div>
          </div>

          {/* Website Deployer */}
          <div className="bg-[#2a2a2a] border border-white/10 rounded-2xl p-8 hover:border-green-500/50 transition-all">
            <div className="text-center">
              <div className="text-4xl mb-4">🚀</div>
              <h3 className="text-2xl font-bold mb-2">Website Deployer</h3>
              <div className="text-5xl font-bold text-green-400 mb-2">$25</div>
              <p className="text-gray-400 mb-6">per site</p>
              <div className="border-t border-white/10 pt-6 text-left space-y-3">
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Automated deployment</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">SSL certificate</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Domain connection</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">24/7 uptime</span>
                </div>
              </div>
              <button
                onClick={() => addItem({
                  id: 'website-deployer',
                  name: 'Website Deployer',
                  price: 25,
                  description: 'Automated deployment service',
                  emoji: '🚀'
                })}
                className="w-full mt-6 bg-green-500 text-white font-semibold py-3 rounded-lg hover:bg-green-600 transition-colors"
              >
                Add to Cart
              </button>
            </div>
          </div>

          {/* Handyman Subscription */}
          <div className="bg-[#2a2a2a] border border-yellow-500/50 rounded-2xl p-8 hover:border-yellow-500 transition-all md:col-span-2 lg:col-span-1">
            <div className="text-center">
              <div className="text-4xl mb-4">🛠️</div>
              <h3 className="text-2xl font-bold mb-2">Handyman Monthly Subscription</h3>
              <div className="text-5xl font-bold text-yellow-400 mb-2">$25</div>
              <p className="text-gray-400 mb-6">per month</p>
              <div className="border-t border-white/10 pt-6 text-left space-y-3">
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Unlimited support</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Monthly maintenance</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Bug fixes</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-xl">✓</span>
                  <span className="text-sm text-gray-300">Priority service</span>
                </div>
              </div>
              <button
                onClick={() => addItem({
                  id: 'handyman-subscription',
                  name: 'Handyman Monthly Subscription',
                  price: 25,
                  description: 'Monthly maintenance & support',
                  emoji: '🛠️'
                })}
                className="w-full mt-6 bg-yellow-500 text-white font-semibold py-3 rounded-lg hover:bg-yellow-600 transition-colors"
              >
                Add to Cart
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Banner */}
        <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl p-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Why Flat Fees?</h2>
          <p className="text-xl mb-6">No hourly rates. No surprises. No spinning your wheels.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="bg-white/10 rounded-lg p-6">
              <div className="text-3xl mb-2">💰</div>
              <h3 className="font-bold mb-2">Transparent</h3>
              <p className="text-sm">You know exactly what you'll pay upfront</p>
            </div>
            <div className="bg-white/10 rounded-lg p-6">
              <div className="text-3xl mb-2">⚡</div>
              <h3 className="font-bold mb-2">Fast</h3>
              <p className="text-sm">No time wasted on hourly billing</p>
            </div>
            <div className="bg-white/10 rounded-lg p-6">
              <div className="text-3xl mb-2">✅</div>
              <h3 className="font-bold mb-2">Simple</h3>
              <p className="text-sm">Choose what you need and get started</p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <h3 className="text-2xl font-bold mb-4">Ready to Get Started?</h3>
          <p className="text-gray-400 mb-8">Go back to the home page and start building</p>
          <Link
            href="/"
            className="inline-block bg-white text-black font-semibold px-8 py-4 rounded-lg hover:bg-gray-200 transition-colors"
          >
            Start Building Now →
          </Link>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-white/10 mt-20">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-2 text-green-400">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <a href="tel:201-640-4635" className="font-semibold hover:text-green-300 transition-colors">
                Customer Service: 201-640-4635
              </a>
            </div>
            <div className="flex items-center justify-center gap-6 text-sm text-gray-400">
              <a href="#" className="hover:text-white transition-colors">
                Terms of Service
              </a>
              <span>•</span>
              <a href="#" className="hover:text-white transition-colors">
                Privacy Policy
              </a>
              <span>•</span>
              <a href="mailto:sean.federaldirectfunding@gmail.com" className="hover:text-white transition-colors">
                Contact Support
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating Support & Chat */}
      <SupportButton />
      <Chatbot />
    </div>
  );
}
