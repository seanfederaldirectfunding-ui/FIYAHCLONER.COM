'use client';

import { useState } from 'react';
import { DeploymentSlots } from '@/components/DeploymentSlots';
import { HeroSection } from '@/components/HeroSection';
import { Footer } from '@/components/Footer';
import { MigrationTools } from '@/components/MigrationTools';
import { ExpertTools } from '@/components/ExpertTools';
import { AutomatedDeployment } from '@/components/AutomatedDeployment';
import { SupportButton } from '@/components/SupportButton';
import { Chatbot } from '@/components/Chatbot';
import { AuthModal } from '@/components/AuthModal';
import type { User } from '@/lib/auth-system';

export default function Home() {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };
  return (
    <div className="min-h-screen bg-[#1c1c1c] text-white">
      {/* Header */}
      <header className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="3" y="3" width="8" height="8" fill="white"/>
              <rect x="13" y="3" width="8" height="8" fill="white"/>
              <rect x="3" y="13" width="8" height="8" fill="white"/>
              <rect x="13" y="13" width="8" height="8" fill="white"/>
            </svg>
            <div className="flex flex-col">
              <span className="text-xl font-bold leading-none">Fiyah Cloner</span>
              <span className="text-xs text-gray-400 leading-none mt-0.5">a division of Fiyah Production llc</span>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <a href="tel:201-640-4635" className="text-sm text-green-400 hover:text-green-300 transition-colors flex items-center gap-1">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              201-640-4635
            </a>
            <a href="/pricing" className="text-sm text-gray-300 hover:text-white transition-colors">
              Pricing
            </a>
            <a href="#" className="text-sm text-gray-300 hover:text-white transition-colors">
              Docs
            </a>
            <a href="#" className="text-sm text-gray-300 hover:text-white transition-colors">
              Careers
            </a>
            {currentUser ? (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-orange-500/10 border border-orange-500/30 rounded-lg">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-sm text-white font-medium">{currentUser.name}</span>
                  {currentUser.role === 'admin' && (
                    <span className="text-xs bg-orange-500 px-2 py-0.5 rounded text-white">Admin</span>
                  )}
                </div>
                <button
                  onClick={handleLogout}
                  className="text-sm text-gray-300 hover:text-white transition-colors"
                >
                  Logout
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowAuthModal(true)}
                className="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors text-sm font-semibold"
              >
                Login
              </button>
            )}
          </nav>
        </div>
      </header>

      {/* Main Content - All Features */}
      <DeploymentSlots />
      <HeroSection />
      <AutomatedDeployment />
      <MigrationTools />
      <ExpertTools />
      <Footer />

      {/* Floating Support & Chat */}
      <SupportButton />
      <Chatbot />

      {/* Auth Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onLogin={handleLogin}
      />
    </div>
  );
}
