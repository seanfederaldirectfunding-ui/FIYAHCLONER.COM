# Stripe Shopping Cart Setup

## Overview
Your Fiyah Cloner application now has a complete shopping cart and checkout system integrated with Stripe.

## What's Been Implemented

### 1. Shopping Cart Features
- **Cart Button**: Orange floating button in the top right corner
- **Item Count Badge**: Shows number of items in cart
- **Add to Cart**: All pricing cards have "Add to Cart" buttons
- **Cart Management**: View, remove items, and clear cart
- **Total Calculation**: Automatic price calculation

### 2. Stripe Integration
- **Publishable Key**: Already configured in the code
  - `pk_test_51SLAHrPLTUnnpuk4jdDZuszGTRyMap1cVPzlMZtkPSux8msR8UEkHknfOGnhylZg0tPyQtM6WZD8tyWwH9DW6NkR00DBHnbkkG`
- **Checkout API**: Server-side route at `/api/checkout`
- **Success Page**: Redirects to `/checkout/success` after payment
- **Cancel Handling**: Returns to `/pricing` if payment is cancelled

## Required Configuration

### Get Your Stripe Secret Key
1. Go to https://dashboard.stripe.com/test/apikeys
2. Copy your **Secret key** (starts with `sk_test_`)
3. Add it to your `.env.local` file:

```env
STRIPE_SECRET_KEY=sk_test_your_actual_secret_key_here
```

### For Production Deployment
When deploying to production:
1. Get your **Live** secret key from https://dashboard.stripe.com/apikeys
2. Set the environment variable in your hosting platform (Netlify, Vercel, etc.)
3. Update the publishable key in `src/components/ShoppingCart.tsx` to your live key

## How It Works

### User Flow
1. User browses pricing page
2. Clicks "Add to Cart" on desired services
3. Cart button shows item count
4. User clicks cart button to review items
5. Clicks "Checkout with Stripe"
6. Redirects to Stripe's hosted checkout page
7. After payment, returns to success page

### Products Available
- Simple Display Website - $25
- Functioning Application Site - $100
- Mobile App - $100
- Website Deployer - $25
- Handyman Monthly Subscription - $25

## Files Modified/Created

### New Files
- `src/lib/cart-context.tsx` - Cart state management
- `src/components/ShoppingCart.tsx` - Cart UI component
- `src/app/api/checkout/route.ts` - Stripe checkout API
- `src/app/checkout/success/page.tsx` - Success page
- `.env.local` - Environment variables

### Modified Files
- `src/app/ClientBody.tsx` - Added CartProvider
- `src/app/pricing/page.tsx` - Added "Add to Cart" buttons
- `src/app/page.tsx` - Added header subtitle
- `package.json` - Added Stripe dependencies

## Testing

### Local Testing
1. Add your test secret key to `.env.local`
2. Restart the dev server
3. Add items to cart
4. Click checkout
5. Use Stripe test card: `4242 4242 4242 4242`
6. Use any future expiry date and any CVC

### Note on Preview Environment
The Stripe.js library may have issues loading in the iframe preview environment due to Content Security Policy restrictions. The integration will work properly when deployed to a live URL.

## Brand Updates
- Added "a division of Fiyah Production llc" subtitle to all headers
- Appears in smaller gray text below "Fiyah Cloner"

## Next Steps
1. Add your Stripe secret key to `.env.local`
2. Test the checkout flow locally
3. When ready for production, update to live Stripe keys
4. Consider adding product images and descriptions
5. Add customer email collection for order confirmations
