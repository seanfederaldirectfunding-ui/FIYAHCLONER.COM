# 🚀 GODADDY DEPLOYMENT GUIDE - FIYAH CLONER

**Complete Step-by-Step Instructions for Deploying to GoDaddy VPS**

---

## 📋 PREREQUISITES

Before starting, you'll need:
- ✅ GoDaddy account
- ✅ VPS or Dedicated Server (Ubuntu recommended)
- ✅ Domain name (optional but recommended)
- ✅ SSH access to your server
- ✅ This completed project

---

## 🎯 DEPLOYMENT OPTIONS

### **Option 1: GoDaddy VPS with Node.js (Recommended)**
- Cost: ~$4.99-$29.99/month
- Full control over server
- Best for production apps
- **Choose this for Fiyah Cloner**

### **Option 2: GoDaddy Shared Hosting**
- Not recommended for Next.js apps
- Limited Node.js support
- Better for static sites only

---

## 🛒 STEP 1: PURCHASE GODADDY VPS

### **1.1 Choose Your Plan**
Go to: https://www.godaddy.com/hosting/vps-hosting

**Recommended Plan for Fiyah Cloner:**
- **Economy VPS:** $4.99/month (Good for starting)
- **Deluxe VPS:** $14.99/month (Better performance)
- **Ultimate VPS:** $29.99/month (Best for production)

**Specifications Needed:**
- RAM: Minimum 1GB (2GB+ recommended)
- Storage: 20GB minimum
- OS: Ubuntu 20.04 or 22.04 LTS

### **1.2 Complete Purchase**
1. Select VPS plan
2. Choose Ubuntu as operating system
3. Select billing period (monthly recommended for testing)
4. Add domain if needed
5. Complete checkout

### **1.3 Wait for Provisioning**
- You'll receive email with:
  - Server IP address
  - Root password
  - SSH access details
- Provisioning takes 5-30 minutes

---

## 🔐 STEP 2: INITIAL SERVER ACCESS

### **2.1 Access Your Server via SSH**

**On Mac/Linux:**
```bash
ssh root@YOUR_SERVER_IP
```

**On Windows:**
- Use PuTTY (download from putty.org)
- Or use Windows Terminal with SSH

**First Login:**
```bash
# You'll be prompted to change password on first login
# Enter current password from email
# Create new strong password
```

### **2.2 Update Server**
```bash
# Update package list
sudo apt update

# Upgrade installed packages
sudo apt upgrade -y

# Install essential tools
sudo apt install -y curl wget git build-essential
```

---

## 📦 STEP 3: INSTALL NODE.JS AND PM2

### **3.1 Install Node.js 20.x (LTS)**
```bash
# Add NodeSource repository
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -

# Install Node.js
sudo apt install -y nodejs

# Verify installation
node --version    # Should show v20.x.x
npm --version     # Should show 10.x.x
```

### **3.2 Install Bun (Alternative to npm)**
```bash
# Install Bun
curl -fsSL https://bun.sh/install | bash

# Add to PATH
source ~/.bashrc

# Verify installation
bun --version
```

### **3.3 Install PM2 (Process Manager)**
```bash
# Install PM2 globally
npm install -g pm2

# Verify installation
pm2 --version

# Setup PM2 to start on boot
pm2 startup
# Run the command it outputs
```

---

## 📂 STEP 4: UPLOAD YOUR PROJECT

### **Option A: Using Git (Recommended)**

**4.1 Create GitHub Repository**
1. Go to github.com
2. Create new repository: `fiyah-cloner`
3. Initialize repository

**4.2 Push Your Code**
On your local machine:
```bash
cd fiyah-cloner

# Initialize git (if not already)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - Fiyah Cloner ready for production"

# Add remote
git remote add origin https://github.com/YOUR_USERNAME/fiyah-cloner.git

# Push
git push -u origin main
```

**4.3 Clone on Server**
```bash
# On GoDaddy VPS
cd /var/www
sudo git clone https://github.com/YOUR_USERNAME/fiyah-cloner.git
cd fiyah-cloner
```

### **Option B: Using FTP/SFTP**

**4.1 Install FileZilla**
Download from: https://filezilla-project.org/

**4.2 Connect to Server**
```
Host: sftp://YOUR_SERVER_IP
Username: root
Password: YOUR_PASSWORD
Port: 22
```

**4.3 Upload Files**
1. Navigate to `/var/www/` on server
2. Create folder: `fiyah-cloner`
3. Upload all project files
4. Keep folder structure intact

---

## 🔧 STEP 5: CONFIGURE PROJECT ON SERVER

### **5.1 Navigate to Project**
```bash
cd /var/www/fiyah-cloner
```

### **5.2 Create Environment File**
```bash
nano .env.local
```

**Add this content:**
```env
# Stripe Configuration - Fiyah Production
STRIPE_SECRET_KEY=sk_test_51SLAHrPLTUnnpuk4XwDfNo8rESenqFE6xE0731ApH3EMw9GDLqqi7TKyP1OSADqVIIwPlLkDR3CfSkwsNdIBeHEy0027yCIRKp

# Production Settings
NODE_ENV=production
PORT=3000

# For production, consider adding:
# NEXTAUTH_URL=https://yourdomain.com
# NEXTAUTH_SECRET=your_generated_secret_here
```

**Save file:**
- Press `Ctrl + X`
- Press `Y`
- Press `Enter`

### **5.3 Install Dependencies**
```bash
# Using Bun (faster)
bun install

# OR using npm
npm install
```

### **5.4 Build Project**
```bash
# Using Bun
bun run build

# OR using npm
npm run build
```

**Expected Output:**
```
✓ Compiled successfully
✓ Generating static pages
✓ Finalizing page optimization
Build completed successfully
```

---

## 🚀 STEP 6: START APPLICATION WITH PM2

### **6.1 Start Application**
```bash
# Using Bun
pm2 start bun --name "fiyah-cloner" -- run start

# OR using npm
pm2 start npm --name "fiyah-cloner" -- start
```

### **6.2 Verify Application**
```bash
# Check PM2 status
pm2 status

# View logs
pm2 logs fiyah-cloner

# Monitor
pm2 monit
```

### **6.3 Save PM2 Configuration**
```bash
# Save current processes
pm2 save

# Ensure PM2 starts on reboot
pm2 startup
```

### **6.4 Test Application**
```bash
# Test if app is running
curl http://localhost:3000

# Should return HTML content
```

---

## 🌐 STEP 7: CONFIGURE NGINX (Reverse Proxy)

### **7.1 Install Nginx**
```bash
sudo apt install -y nginx
```

### **7.2 Create Nginx Configuration**
```bash
sudo nano /etc/nginx/sites-available/fiyah-cloner
```

**Add this configuration:**
```nginx
server {
    listen 80;
    server_name YOUR_DOMAIN.com www.YOUR_DOMAIN.com;
    # If no domain yet, use: server_name YOUR_SERVER_IP;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

**Save file:** `Ctrl + X`, `Y`, `Enter`

### **7.3 Enable Site**
```bash
# Create symbolic link
sudo ln -s /etc/nginx/sites-available/fiyah-cloner /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx

# Enable Nginx on boot
sudo systemctl enable nginx
```

### **7.4 Configure Firewall**
```bash
# Allow SSH
sudo ufw allow 22

# Allow HTTP
sudo ufw allow 80

# Allow HTTPS
sudo ufw allow 443

# Enable firewall
sudo ufw enable

# Check status
sudo ufw status
```

---

## 🔒 STEP 8: INSTALL SSL CERTIFICATE (HTTPS)

### **8.1 Install Certbot**
```bash
sudo apt install -y certbot python3-certbot-nginx
```

### **8.2 Get SSL Certificate**
```bash
# Replace with your domain
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Follow prompts:
# - Enter email address
# - Agree to terms
# - Choose to redirect HTTP to HTTPS (option 2)
```

### **8.3 Test Auto-Renewal**
```bash
sudo certbot renew --dry-run
```

**SSL certificate will auto-renew every 90 days**

---

## 🌍 STEP 9: CONFIGURE DOMAIN (GODADDY)

### **9.1 Access DNS Settings**
1. Go to: https://dcc.godaddy.com/domains
2. Click on your domain
3. Click "DNS" or "Manage DNS"

### **9.2 Update A Records**
**Add/Update these records:**

| Type | Name | Value | TTL |
|------|------|-------|-----|
| A | @ | YOUR_SERVER_IP | 600 |
| A | www | YOUR_SERVER_IP | 600 |

### **9.3 Wait for Propagation**
- DNS changes take 1-48 hours
- Usually updates within 1-4 hours
- Check status: https://whatsmydns.net

---

## ✅ STEP 10: VERIFY DEPLOYMENT

### **10.1 Check Application**
```bash
# Check PM2 status
pm2 status

# View logs
pm2 logs fiyah-cloner --lines 50

# Check Nginx status
sudo systemctl status nginx

# Check if app is accessible
curl -I http://YOUR_DOMAIN.com
```

### **10.2 Access Your Website**
Open browser and visit:
- http://YOUR_DOMAIN.com (or http://YOUR_SERVER_IP)
- https://YOUR_DOMAIN.com (if SSL configured)

### **10.3 Test All Features**
- ✅ Login with admin credentials
- ✅ Add items to cart
- ✅ Test checkout (use Stripe test card)
- ✅ Test all tools
- ✅ Verify responsive design

---

## 🔄 STEP 11: UPDATE APPLICATION (FUTURE UPDATES)

### **11.1 Pull Latest Changes**
```bash
cd /var/www/fiyah-cloner

# Pull updates
git pull origin main

# Install new dependencies
bun install

# Rebuild
bun run build

# Restart PM2
pm2 restart fiyah-cloner
```

### **11.2 Quick Deploy Script**
Create update script:
```bash
nano update.sh
```

**Add:**
```bash
#!/bin/bash
cd /var/www/fiyah-cloner
git pull origin main
bun install
bun run build
pm2 restart fiyah-cloner
echo "✅ Deployment complete!"
```

**Make executable:**
```bash
chmod +x update.sh

# Run updates
./update.sh
```

---

## 🛠️ TROUBLESHOOTING

### **Issue: Application Won't Start**
```bash
# Check logs
pm2 logs fiyah-cloner

# Check port is available
sudo lsof -i :3000

# Restart application
pm2 restart fiyah-cloner
```

### **Issue: 502 Bad Gateway**
```bash
# Check if app is running
pm2 status

# Check Nginx error logs
sudo tail -f /var/log/nginx/error.log

# Restart services
pm2 restart fiyah-cloner
sudo systemctl restart nginx
```

### **Issue: Permission Denied**
```bash
# Fix permissions
sudo chown -R $USER:$USER /var/www/fiyah-cloner
sudo chmod -R 755 /var/www/fiyah-cloner
```

### **Issue: Out of Memory**
```bash
# Check memory
free -h

# Increase swap space (if needed)
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

---

## 📊 MONITORING & MAINTENANCE

### **Monitor Application**
```bash
# Real-time monitoring
pm2 monit

# View detailed info
pm2 show fiyah-cloner

# View logs
pm2 logs fiyah-cloner --lines 100
```

### **Set Up Monitoring Dashboard**
```bash
# Link to PM2 Cloud (optional)
pm2 link YOUR_SECRET_KEY YOUR_PUBLIC_KEY
```

### **Regular Maintenance**
```bash
# Update system monthly
sudo apt update && sudo apt upgrade -y

# Clear PM2 logs
pm2 flush

# Restart application weekly
pm2 restart fiyah-cloner
```

---

## 💰 COST ESTIMATE

### **Monthly Costs:**
- **VPS Hosting:** $4.99 - $29.99/month (GoDaddy)
- **Domain Name:** $0.99 - $14.99/year (if new)
- **SSL Certificate:** FREE (Let's Encrypt)
- **Total:** ~$5-$30/month

### **One-Time Costs:**
- Domain registration: $0.99 - $14.99 (first year)
- Setup time: 1-2 hours

---

## 🎯 QUICK REFERENCE COMMANDS

### **Essential Commands**
```bash
# Start app
pm2 start fiyah-cloner

# Stop app
pm2 stop fiyah-cloner

# Restart app
pm2 restart fiyah-cloner

# View logs
pm2 logs fiyah-cloner

# Rebuild app
cd /var/www/fiyah-cloner && bun run build

# Restart Nginx
sudo systemctl restart nginx
```

---

## 📞 SUPPORT

**GoDaddy Support:**
- Phone: 1-480-505-8877
- Chat: godaddy.com/help
- Documentation: godaddy.com/help

**Fiyah Cloner Support:**
- Email: sean.federaldirectfunding@gmail.com
- Phone: 201-640-4635

---

## ✅ DEPLOYMENT CHECKLIST

Before going live:
- [ ] VPS purchased and configured
- [ ] Node.js and PM2 installed
- [ ] Project uploaded to server
- [ ] Dependencies installed
- [ ] Environment variables set
- [ ] Application built successfully
- [ ] PM2 process running
- [ ] Nginx configured
- [ ] SSL certificate installed
- [ ] Domain DNS configured
- [ ] Firewall rules set
- [ ] Stripe keys tested
- [ ] All features tested
- [ ] Backup plan in place

---

**🎉 CONGRATULATIONS!**

Your Fiyah Cloner application is now live on GoDaddy!

**Access your site at:**
- http://YOUR_DOMAIN.com
- https://YOUR_DOMAIN.com (with SSL)

---

*Last Updated: October 23, 2025*
*Guide Version: 1.0*
