# 🚀 DEPLOY FROM SAME.NEW TO GODADDY - COMPLETE GUIDE

**Fiyah Cloner - Production Deployment Instructions**
**From Same.new Cloud IDE to GoDaddy VPS**

---

## 🎯 OVERVIEW

This guide shows you how to deploy your **Fiyah Cloner** project from Same.new to GoDaddy VPS hosting with your own dedicated IP address.

**What You'll Get:**
- ✅ Your own dedicated IP address (e.g., `123.456.789.012`)
- ✅ Full server control (root access)
- ✅ Custom domain support
- ✅ Production-ready hosting
- ✅ SSL certificate (HTTPS)

---

## 📦 PART 1: EXPORT PROJECT FROM SAME.NEW

### **Method 1: Download as ZIP (Easiest)**

**Step 1.1: Download Project**
1. In Same.new, click the **"☰"** menu (top left)
2. Select **"Download Project"**
3. Save `fiyah-cloner.zip` to your computer
4. Extract the ZIP file

**Step 1.2: Verify Files**
Make sure you have:
```
fiyah-cloner/
├── .env.local              (Stripe keys)
├── package.json
├── next.config.js
├── src/
├── public/
└── ... (all other files)
```

### **Method 2: Clone from Git (Recommended for Updates)**

**Step 2.1: Push to GitHub from Same.new**
1. Open terminal in Same.new
2. Run these commands:

```bash
cd fiyah-cloner

# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Production ready - Fiyah Cloner"

# Create GitHub repo (you'll need to do this on github.com first)
# Then add remote and push:
git remote add origin https://github.com/YOUR_USERNAME/fiyah-cloner.git
git branch -M main
git push -u origin main
```

**Note:** If you need GitHub authentication:
1. Go to GitHub.com → Settings → Developer Settings
2. Create Personal Access Token
3. Use token as password when pushing

---

## 🛒 PART 2: PURCHASE & SETUP GODADDY VPS

### **Step 1: Purchase GoDaddy VPS**

**1.1 Go to GoDaddy VPS**
Visit: https://www.godaddy.com/hosting/vps-hosting

**1.2 Choose Your Plan**
| Plan | Price/Month | RAM | Storage | Best For |
|------|-------------|-----|---------|----------|
| **Economy** | $4.99 | 1GB | 20GB | Testing/Small sites |
| **Deluxe** ⭐ | $14.99 | 2GB | 60GB | **Recommended for Fiyah Cloner** |
| **Ultimate** | $29.99 | 4GB | 120GB | High traffic |

**1.3 Configuration:**
- **Operating System:** Ubuntu 22.04 LTS (REQUIRED)
- **Data Center:** Choose closest to your users
- **Billing:** Start with monthly (can change later)

**1.4 Complete Purchase**
1. Add to cart
2. Add domain if needed (optional)
3. Complete checkout
4. Wait 5-30 minutes for provisioning

### **Step 2: Get Your IP Address & Credentials**

**2.1 Check Your Email**
GoDaddy will send you an email with:

```
Subject: Your GoDaddy VPS is Ready!

Server IP Address: 123.456.789.012  ← YOUR DEDICATED IP
Root Password: TemporaryPassword123
SSH Port: 22
Operating System: Ubuntu 22.04 LTS
```

**2.2 Save This Information**
Write down:
- **IP Address:** `_______________` (e.g., 123.456.789.012)
- **Root Password:** `_______________`
- **SSH Port:** 22 (default)

**2.3 Access GoDaddy Control Panel**
1. Go to: https://myh.godaddy.com/
2. Login to your account
3. Click **"Servers"** → **"All Servers"**
4. You'll see your server with IP address

---

## 🖥️ PART 3: CONNECT TO YOUR GODADDY SERVER

### **Step 1: Connect via SSH**

**On Mac/Linux:**
```bash
# Open Terminal and run:
ssh root@YOUR_IP_ADDRESS

# Example:
ssh root@123.456.789.012

# Enter password when prompted
# You'll be asked to change password on first login
```

**On Windows:**

**Option A: Windows Terminal (Built-in)**
```powershell
# Open Windows Terminal or PowerShell
ssh root@YOUR_IP_ADDRESS

# Example:
ssh root@123.456.789.012
```

**Option B: PuTTY (Alternative)**
1. Download PuTTY: https://www.putty.org/
2. Open PuTTY
3. Enter:
   - **Host Name:** YOUR_IP_ADDRESS (e.g., 123.456.789.012)
   - **Port:** 22
   - **Connection Type:** SSH
4. Click **"Open"**
5. Enter username: `root`
6. Enter password

### **Step 2: First Time Setup**

**2.1 Change Root Password**
```bash
# You'll be prompted automatically on first login
# Follow prompts to create new secure password

# Requirements:
# - At least 12 characters
# - Mix of uppercase, lowercase, numbers, symbols
# - Don't use common words
```

**2.2 Update Server**
```bash
# Update package list
sudo apt update

# Upgrade all packages (takes 2-5 minutes)
sudo apt upgrade -y

# Install essential tools
sudo apt install -y curl wget git build-essential
```

**2.3 Create Non-Root User (Security Best Practice)**
```bash
# Create new user
adduser deployer

# Add to sudo group
usermod -aG sudo deployer

# Switch to new user
su - deployer
```

**From now on, use `deployer` user instead of root.**

---

## 📦 PART 4: INSTALL REQUIRED SOFTWARE

### **Step 1: Install Node.js 20.x**

```bash
# Add NodeSource repository
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -

# Install Node.js
sudo apt install -y nodejs

# Verify installation
node --version
# Should show: v20.x.x

npm --version
# Should show: 10.x.x
```

### **Step 2: Install Bun (Faster Package Manager)**

```bash
# Install Bun
curl -fsSL https://bun.sh/install | bash

# Add to PATH
source ~/.bashrc

# Verify installation
bun --version
# Should show: 1.x.x
```

### **Step 3: Install PM2 (Process Manager)**

```bash
# Install PM2 globally
sudo npm install -g pm2

# Verify installation
pm2 --version

# Setup PM2 to start on boot
pm2 startup
# Copy and run the command it outputs
```

---

## 📂 PART 5: UPLOAD YOUR PROJECT TO GODADDY

### **Method 1: Using Git (Recommended)**

**If you pushed to GitHub earlier:**

```bash
# Create web directory
sudo mkdir -p /var/www
cd /var/www

# Clone your repository
sudo git clone https://github.com/YOUR_USERNAME/fiyah-cloner.git

# Set permissions
sudo chown -R deployer:deployer /var/www/fiyah-cloner

# Navigate to project
cd fiyah-cloner
```

### **Method 2: Using SFTP (FileZilla)**

**Step 1: Install FileZilla**
Download from: https://filezilla-project.org/

**Step 2: Connect to Server**
```
Protocol: SFTP
Host: YOUR_IP_ADDRESS (e.g., 123.456.789.012)
Username: deployer
Password: YOUR_DEPLOYER_PASSWORD
Port: 22
```

**Step 3: Upload Files**
1. **Local (left panel):** Navigate to your extracted `fiyah-cloner` folder
2. **Remote (right panel):** Navigate to `/var/www/`
3. **Right-click on local folder** → Select "Upload"
4. Wait for upload to complete (2-10 minutes depending on connection)

**Step 4: Set Permissions via SSH**
```bash
sudo chown -R deployer:deployer /var/www/fiyah-cloner
cd /var/www/fiyah-cloner
```

### **Method 3: Using SCP (Command Line)**

**From Same.new or your local computer:**

```bash
# First, download the project from Same.new
# Then from your local computer, run:

scp -r fiyah-cloner deployer@YOUR_IP_ADDRESS:/var/www/

# Example:
scp -r fiyah-cloner deployer@123.456.789.012:/var/www/

# Enter password when prompted
```

---

## ⚙️ PART 6: CONFIGURE & BUILD PROJECT

### **Step 1: Navigate to Project**
```bash
cd /var/www/fiyah-cloner
```

### **Step 2: Create Environment File**

```bash
# Create .env.local file
nano .env.local
```

**Add this content:**
```env
# Stripe Configuration - Production
STRIPE_SECRET_KEY=sk_test_51SLAHrPLTUnnpuk4XwDfNo8rESenqFE6xE0731ApH3EMw9GDLqqi7TKyP1OSADqVIIwPlLkDR3CfSkwsNdIBeHEy0027yCIRKp

# Production Settings
NODE_ENV=production
PORT=3000
NEXT_PUBLIC_APP_URL=http://YOUR_IP_ADDRESS

# For production with domain:
# NEXT_PUBLIC_APP_URL=https://yourdomain.com
```

**Save file:**
- Press `Ctrl + X`
- Press `Y` to confirm
- Press `Enter`

### **Step 3: Install Dependencies**

```bash
# Using Bun (faster - recommended)
bun install

# OR using npm
npm install

# This takes 1-3 minutes
```

### **Step 4: Build Project**

```bash
# Using Bun
bun run build

# OR using npm
npm run build

# Expected output:
# ✓ Compiled successfully
# ✓ Generating static pages
# ✓ Finalizing page optimization
# Build completed successfully
```

**If build succeeds, you'll see:**
```
Route (app)                                Size     First Load JS
┌ ○ /                                      101 kB         186 kB
├ ○ /checkout/success                      85.4 kB        170 kB
└ ○ /pricing                               91.2 kB        176 kB

✓ Completed in 6s
```

---

## 🚀 PART 7: START APPLICATION WITH PM2

### **Step 1: Start Application**

```bash
# Start with PM2
pm2 start npm --name "fiyah-cloner" -- start

# OR with Bun:
pm2 start bun --name "fiyah-cloner" -- run start
```

### **Step 2: Verify Application is Running**

```bash
# Check PM2 status
pm2 status

# Expected output:
# ┌─────┬────────────────┬─────────┬─────────┬──────────┐
# │ id  │ name           │ status  │ cpu     │ memory   │
# ├─────┼────────────────┼─────────┼─────────┼──────────┤
# │ 0   │ fiyah-cloner   │ online  │ 0%      │ 75.2mb   │
# └─────┴────────────────┴─────────┴─────────┴──────────┘

# View logs
pm2 logs fiyah-cloner --lines 20

# Test locally on server
curl http://localhost:3000
# Should return HTML
```

### **Step 3: Save PM2 Configuration**

```bash
# Save current processes
pm2 save

# Ensure PM2 starts on reboot
pm2 startup
# Run the command it outputs
```

---

## 🌐 PART 8: CONFIGURE NGINX (WEB SERVER)

### **Step 1: Install Nginx**

```bash
sudo apt install -y nginx
```

### **Step 2: Create Nginx Configuration**

```bash
sudo nano /etc/nginx/sites-available/fiyah-cloner
```

**Add this configuration:**

```nginx
server {
    listen 80;
    listen [::]:80;

    # Replace with your IP or domain
    server_name YOUR_IP_ADDRESS;
    # Example: server_name 123.456.789.012;
    # Or with domain: server_name yourdomain.com www.yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;

    # File upload size
    client_max_body_size 50M;
}
```

**Save file:** `Ctrl + X`, `Y`, `Enter`

### **Step 3: Enable Site**

```bash
# Create symbolic link
sudo ln -s /etc/nginx/sites-available/fiyah-cloner /etc/nginx/sites-enabled/

# Remove default site
sudo rm /etc/nginx/sites-enabled/default

# Test configuration
sudo nginx -t

# Expected output:
# nginx: configuration file /etc/nginx/nginx.conf test is successful

# Restart Nginx
sudo systemctl restart nginx

# Enable Nginx on boot
sudo systemctl enable nginx

# Check status
sudo systemctl status nginx
```

### **Step 4: Configure Firewall**

```bash
# Allow SSH (IMPORTANT - don't lock yourself out!)
sudo ufw allow 22

# Allow HTTP
sudo ufw allow 80

# Allow HTTPS
sudo ufw allow 443

# Enable firewall
sudo ufw enable
# Type 'y' to confirm

# Check status
sudo ufw status

# Expected output:
# Status: active
# To                         Action      From
# --                         ------      ----
# 22                         ALLOW       Anywhere
# 80                         ALLOW       Anywhere
# 443                        ALLOW       Anywhere
```

---

## ✅ PART 9: TEST YOUR DEPLOYMENT

### **Step 1: Test with IP Address**

**Open your web browser and visit:**
```
http://YOUR_IP_ADDRESS

Example: http://123.456.789.012
```

**You should see:** Your Fiyah Cloner homepage! 🎉

### **Step 2: Test All Features**

✅ **Homepage loads**
✅ **Click "Login" button**
✅ **Login with:**
   - Email: `sean.federaldirectfunding@gmail.com`
   - PIN: `6347`
✅ **Browse to Pricing page**
✅ **Add item to cart**
✅ **Click cart icon**
✅ **Test checkout** (use Stripe test card: 4242 4242 4242 4242)

### **Step 3: Check Server Logs**

```bash
# View PM2 logs
pm2 logs fiyah-cloner --lines 50

# View Nginx access logs
sudo tail -f /var/log/nginx/access.log

# View Nginx error logs
sudo tail -f /var/log/nginx/error.log
```

---

## 🌍 PART 10: CONNECT CUSTOM DOMAIN (OPTIONAL)

### **If you have a domain name:**

**Step 1: Update GoDaddy DNS**
1. Go to: https://dcc.godaddy.com/domains
2. Click on your domain
3. Click **"DNS"** or **"Manage DNS"**

**Step 2: Add A Records**

| Type | Name | Value | TTL |
|------|------|-------|-----|
| A | @ | YOUR_IP_ADDRESS | 600 |
| A | www | YOUR_IP_ADDRESS | 600 |

Example:
| Type | Name | Value | TTL |
|------|------|-------|-----|
| A | @ | 123.456.789.012 | 600 |
| A | www | 123.456.789.012 | 600 |

**Step 3: Update Nginx Configuration**

```bash
sudo nano /etc/nginx/sites-available/fiyah-cloner
```

**Change server_name:**
```nginx
# From:
server_name YOUR_IP_ADDRESS;

# To:
server_name yourdomain.com www.yourdomain.com;
```

**Save and restart:**
```bash
sudo nginx -t
sudo systemctl restart nginx
```

**Step 4: Wait for DNS Propagation**
- DNS changes take 1-48 hours
- Usually updates within 1-4 hours
- Check status: https://whatsmydns.net

---

## 🔒 PART 11: INSTALL SSL CERTIFICATE (HTTPS)

### **Step 1: Install Certbot**

```bash
sudo apt install -y certbot python3-certbot-nginx
```

### **Step 2: Get SSL Certificate**

**With Domain:**
```bash
# Replace with your domain
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Follow prompts:
# 1. Enter email address
# 2. Agree to terms (Y)
# 3. Choose to redirect HTTP to HTTPS (option 2)
```

**Expected output:**
```
Congratulations! You have successfully enabled HTTPS!

Your certificate will expire on 2025-01-20.
```

### **Step 3: Test Auto-Renewal**

```bash
sudo certbot renew --dry-run
```

**SSL certificate will auto-renew every 90 days!**

### **Step 4: Test HTTPS**

Visit: `https://yourdomain.com`

You should see:
- ✅ Padlock icon in browser
- ✅ "Secure" or "Connection is secure"
- ✅ Your site loads over HTTPS

---

## 📊 PART 12: MONITORING & MANAGEMENT

### **Essential PM2 Commands**

```bash
# View status
pm2 status

# View logs
pm2 logs fiyah-cloner

# Monitor in real-time
pm2 monit

# Restart app
pm2 restart fiyah-cloner

# Stop app
pm2 stop fiyah-cloner

# Start app
pm2 start fiyah-cloner

# View detailed info
pm2 show fiyah-cloner

# Clear logs
pm2 flush
```

### **Check Application Health**

```bash
# Check if app is responding
curl -I http://localhost:3000

# Check Nginx status
sudo systemctl status nginx

# Check disk space
df -h

# Check memory usage
free -h

# Check CPU usage
top
# Press 'q' to exit
```

---

## 🔄 PART 13: UPDATE YOUR APPLICATION

### **When you make changes in Same.new:**

**Option 1: Using Git (Recommended)**

```bash
# On Same.new, commit and push changes
git add .
git commit -m "Update description"
git push origin main

# On GoDaddy server, pull updates
cd /var/www/fiyah-cloner
git pull origin main
bun install  # Install any new dependencies
bun run build  # Rebuild
pm2 restart fiyah-cloner  # Restart app
```

**Option 2: Manual Upload**

```bash
# Download from Same.new
# Upload via FileZilla to /var/www/fiyah-cloner
# Then on server:
cd /var/www/fiyah-cloner
bun install
bun run build
pm2 restart fiyah-cloner
```

### **Create Quick Update Script**

```bash
nano ~/update-fiyah.sh
```

**Add:**
```bash
#!/bin/bash
cd /var/www/fiyah-cloner
git pull origin main
bun install
bun run build
pm2 restart fiyah-cloner
pm2 logs fiyah-cloner --lines 20
echo "✅ Update complete!"
```

**Make executable:**
```bash
chmod +x ~/update-fiyah.sh

# Run updates:
~/update-fiyah.sh
```

---

## 🆘 TROUBLESHOOTING

### **Issue: Can't connect to IP address**

```bash
# Check if app is running
pm2 status

# If stopped, start it
pm2 start fiyah-cloner

# Check firewall
sudo ufw status

# Check Nginx
sudo systemctl status nginx
```

### **Issue: 502 Bad Gateway**

```bash
# App might be stopped
pm2 restart fiyah-cloner

# Check logs
pm2 logs fiyah-cloner --lines 50

# Check if port 3000 is in use
sudo lsof -i :3000
```

### **Issue: Changes not showing**

```bash
# Clear PM2 cache
pm2 restart fiyah-cloner

# Clear browser cache
# Or use incognito/private browsing

# Rebuild application
cd /var/www/fiyah-cloner
bun run build
pm2 restart fiyah-cloner
```

### **Issue: Out of Memory**

```bash
# Check memory
free -h

# Add swap space
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

# Make permanent
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

### **Issue: Can't SSH into server**

```bash
# Check your IP address
# Make sure you're using correct password
# Try from different network
# Contact GoDaddy support: 1-480-505-8877
```

---

## 📋 QUICK REFERENCE

### **Your Server Information**

```
IP Address: _______________  (e.g., 123.456.789.012)
Username: deployer
Password: _______________
SSH Port: 22
Project Path: /var/www/fiyah-cloner
```

### **Access URLs**

```
Same.new Preview: https://same.new (development only)
GoDaddy IP: http://YOUR_IP_ADDRESS
Custom Domain: http://yourdomain.com (if configured)
HTTPS: https://yourdomain.com (after SSL)
```

### **Important Ports**

```
SSH: 22
HTTP: 80
HTTPS: 443
Next.js App: 3000 (internal only)
```

### **Essential Commands**

```bash
# Connect to server
ssh deployer@YOUR_IP_ADDRESS

# Navigate to project
cd /var/www/fiyah-cloner

# Check app status
pm2 status

# View logs
pm2 logs fiyah-cloner

# Restart app
pm2 restart fiyah-cloner

# Update application
git pull && bun install && bun run build && pm2 restart fiyah-cloner
```

---

## 💰 COST BREAKDOWN

### **Monthly Costs**

| Item | Cost | Notes |
|------|------|-------|
| GoDaddy VPS | $4.99 - $29.99 | Choose plan based on traffic |
| Domain Name | ~$1.25/mo | $14.99/year if new |
| SSL Certificate | FREE | Let's Encrypt |
| **Total** | **$6-$31/month** | |

### **One-Time Costs**

| Item | Cost |
|------|------|
| Domain (1st year) | $0.99 - $14.99 |
| Setup time | 1-2 hours |

---

## ✅ DEPLOYMENT CHECKLIST

**Before Starting:**
- [ ] Downloaded project from Same.new
- [ ] Have GoDaddy account
- [ ] Credit card ready for VPS purchase

**GoDaddy VPS Setup:**
- [ ] Purchased VPS plan
- [ ] Received IP address via email
- [ ] Can SSH into server
- [ ] Changed root password
- [ ] Created deployer user

**Software Installation:**
- [ ] Node.js installed (v20.x)
- [ ] Bun installed
- [ ] PM2 installed
- [ ] Nginx installed

**Project Deployment:**
- [ ] Project uploaded to /var/www/fiyah-cloner
- [ ] Dependencies installed
- [ ] .env.local configured
- [ ] Application built successfully
- [ ] PM2 running application

**Web Server:**
- [ ] Nginx configured
- [ ] Firewall rules set
- [ ] Can access via IP address
- [ ] All features tested

**Optional (Recommended):**
- [ ] Domain DNS configured
- [ ] SSL certificate installed
- [ ] HTTPS working
- [ ] Update script created

---

## 🎉 SUCCESS!

**If you can access your site at `http://YOUR_IP_ADDRESS`, congratulations!**

Your Fiyah Cloner is now live on GoDaddy with your dedicated IP address!

### **What You've Achieved:**

✅ Full production server running Ubuntu
✅ Your own dedicated IP address
✅ Fiyah Cloner application deployed
✅ Authentication system active (10,000 user capacity)
✅ Shopping cart with Stripe integration
✅ All 22 expert tools operational
✅ Professional hosting environment

### **Next Steps:**

1. ✅ Test all features thoroughly
2. ⚠️ Switch to Stripe live keys for production payments
3. ⚠️ Set up domain name (if you haven't)
4. ⚠️ Install SSL certificate for HTTPS
5. ⚠️ Set up regular backups
6. ⚠️ Monitor application performance

---

## 📞 SUPPORT

**GoDaddy VPS Support:**
- Phone: 1-480-505-8877
- Chat: godaddy.com/help
- Help Center: godaddy.com/help

**Fiyah Cloner Support:**
- Email: sean.federaldirectfunding@gmail.com
- Phone: 201-640-4635

**Same.new Support:**
- Email: support@same.new
- Documentation: docs.same.new

---

## 🔗 USEFUL LINKS

- **GoDaddy VPS:** https://www.godaddy.com/hosting/vps-hosting
- **GoDaddy Control Panel:** https://myh.godaddy.com/
- **Domain Management:** https://dcc.godaddy.com/domains
- **SSL Check:** https://www.ssllabs.com/ssltest/
- **DNS Propagation:** https://whatsmydns.net
- **Stripe Dashboard:** https://dashboard.stripe.com

---

**🎊 You're Ready to Go Live!**

Your Fiyah Cloner is now deployed on professional hosting with your own IP address. Time to start accepting customers!

---

*Guide Version: 2.0*
*Last Updated: October 23, 2025*
*Deployment Status: Production Ready ✅*
