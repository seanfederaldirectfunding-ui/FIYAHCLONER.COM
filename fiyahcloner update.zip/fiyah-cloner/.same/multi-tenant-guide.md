# Fiyah Cloner - Multi-Tenant System Guide

## 🎯 Overview
Fiyah Cloner now supports **100,000+ separate user accounts** with individual login credentials, lease management, and isolated user spaces.

---

## 🔐 Authentication System

### User Registration
**URL:** `/register`

**Features:**
- Secure account creation
- Password encryption (bcrypt)
- Automatic 30-day free lease
- Email validation
- Unique account per email

**Process:**
1. User enters name, email, and password
2. System creates account with unique ID
3. User automatically logged in
4. Redirected to personal dashboard

### User Login
**URL:** `/login`

**Features:**
- Secure JWT-based authentication
- 7-day session duration
- HTTP-only cookies for security
- Failed login protection

**Demo Credentials:**
- Email: `admin@fiyahcloner.com`
- Password: `admin123`

### User Dashboard
**URL:** `/dashboard`

**Features:**
- Lease status overview
- Days remaining counter
- Account information
- Full access to deployment tools
- Personal provider settings

---

## 👤 User Account Structure

### Each User Gets:
```javascript
{
  id: string,              // Unique identifier
  email: string,           // Login email
  name: string,            // Display name
  leaseStatus: string,     // active | inactive | expired
  leaseExpiresAt: string,  // Expiration date
  subscriptionTier: string,// free | basic | premium | enterprise
  createdAt: string        // Registration date
}
```

### Subscription Tiers
1. **Free** - 30-day trial
2. **Basic** - Standard features
3. **Premium** - Advanced features
4. **Enterprise** - Unlimited access

---

## 🔧 Lease Management

### Automatic Lease Features
- **New User:** 30-day free lease
- **Active Status:** Full access to all tools
- **Expiring Soon:** Warning notifications
- **Expired:** Limited access, renewal required

### Lease Status Types
- **Active** (Green) - Full access
- **Inactive** (Gray) - Account paused
- **Expired** (Red) - Needs renewal

---

## 👨‍💼 Admin Dashboard

### Access
**URL:** `/admin`
**Requires:** Admin email (`admin@fiyahcloner.com`)

### Admin Features
1. **View All Users** - Complete user list
2. **System Statistics:**
   - Total Users
   - System Capacity (100,000)
   - Remaining Slots
   - Utilization Percentage

3. **User Management:**
   - View user details
   - Monitor lease status
   - Track subscription tiers
   - See registration dates

### Admin Dashboard Stats
```
┌─────────────────────────────────────┐
│ Total Users:           1            │
│ Capacity:              100,000      │
│ Remaining Slots:       99,999       │
│ Utilization:           0.00%        │
└─────────────────────────────────────┘
```

---

## 🗄️ Database Structure

### Current Implementation
- **In-Memory Storage** (Development)
- Supports up to 100,000 users
- Fast read/write operations
- Resets on server restart

### Production Recommendations
For 100,000+ users in production, upgrade to:

1. **PostgreSQL (Recommended)**
   ```sql
   CREATE TABLE users (
     id UUID PRIMARY KEY,
     email VARCHAR(255) UNIQUE NOT NULL,
     password VARCHAR(255) NOT NULL,
     name VARCHAR(255) NOT NULL,
     lease_status VARCHAR(50),
     lease_expires_at TIMESTAMP,
     subscription_tier VARCHAR(50),
     created_at TIMESTAMP DEFAULT NOW()
   );
   CREATE INDEX idx_email ON users(email);
   CREATE INDEX idx_lease_status ON users(lease_status);
   ```

2. **Supabase** (Easy Setup)
   - Built on PostgreSQL
   - Automatic scaling
   - Real-time features
   - Free tier available

3. **MongoDB** (NoSQL Option)
   ```javascript
   {
     _id: ObjectId,
     email: { type: String, unique: true },
     password: String,
     name: String,
     leaseStatus: String,
     leaseExpiresAt: Date,
     subscriptionTier: String,
     createdAt: { type: Date, default: Date.now }
   }
   ```

---

## 🔒 Security Features

### Password Security
- **bcrypt** hashing with salt rounds (10)
- Never stored in plain text
- Secure password comparison

### Session Management
- **JWT tokens** with 7-day expiration
- HTTP-only cookies (XSS protection)
- Secure flag in production (HTTPS)
- SameSite policy enabled

### API Security
- Authentication required for protected routes
- Token validation on each request
- Email verification on login
- Role-based access control (Admin)

---

## 📊 Scaling for 100,000+ Users

### Performance Optimization
1. **Database Indexing**
   - Index on email for fast lookups
   - Index on lease_status for filtering
   - Composite indexes for complex queries

2. **Caching Layer**
   - Redis for session storage
   - Cache frequently accessed users
   - Reduce database load

3. **Load Balancing**
   - Distribute user sessions
   - Multiple server instances
   - CDN for static assets

4. **Rate Limiting**
   - Prevent brute force attacks
   - Protect API endpoints
   - Fair resource allocation

---

## 🚀 API Endpoints

### Authentication
```bash
POST /api/auth/register
Body: { email, password, name }
Response: { success, user }

POST /api/auth/login
Body: { email, password }
Response: { success, user }

POST /api/auth/logout
Response: { success }

GET /api/auth/me
Response: { user }
```

### Admin
```bash
GET /api/admin/users
Requires: Admin authentication
Response: { users, total, capacity, remaining }
```

---

## 💰 Leasing System

### How Leasing Works
1. **User Signs Up** → Gets 30-day free lease
2. **Lease Active** → Full access to platform
3. **Lease Expires** → User notified
4. **Renewal** → Payment/upgrade required

### Lease Benefits
- **Revenue Generation:** Recurring income model
- **User Retention:** Encourages active use
- **Fair Access:** Prevents inactive accounts
- **Scalability:** Manage user capacity

---

## 🔄 Migration from In-Memory to Database

### Step 1: Install Database Client
```bash
# For PostgreSQL
bun add pg

# For Supabase
bun add @supabase/supabase-js

# For MongoDB
bun add mongodb
```

### Step 2: Update `src/lib/auth.ts`
Replace the in-memory `users` array with database queries.

### Step 3: Environment Variables
```env
DATABASE_URL=postgresql://user:password@host:5432/database
# OR
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your-anon-key
```

### Step 4: Migration Script
Create a migration to set up database tables and indexes.

---

## 📈 Usage Statistics

### Track Important Metrics
- Total registered users
- Active leases
- Expired leases
- Revenue from renewals
- Most popular subscription tier
- Average session duration
- User retention rate

---

## 🛡️ Best Practices

### For Production
1. ✅ Use production database (PostgreSQL/Supabase)
2. ✅ Enable HTTPS (SSL certificates)
3. ✅ Set strong JWT_SECRET
4. ✅ Implement rate limiting
5. ✅ Add email verification
6. ✅ Set up monitoring/logging
7. ✅ Backup user data regularly
8. ✅ Implement password reset
9. ✅ Add 2FA for admin accounts
10. ✅ Comply with GDPR/privacy laws

---

## 🎓 Next Steps

1. **Upgrade to Production Database**
   - Choose PostgreSQL or Supabase
   - Migrate user data
   - Set up backups

2. **Add Payment Integration**
   - Stripe for subscriptions
   - Automatic lease renewal
   - Invoice generation

3. **Enhanced Features**
   - Email notifications
   - Password reset flow
   - User profile editing
   - Team/organization accounts

4. **Analytics Dashboard**
   - User growth charts
   - Revenue tracking
   - Engagement metrics

---

## 📞 Support

For technical assistance with the multi-tenant system:
- **Documentation:** This guide
- **Admin Access:** Login as admin@fiyahcloner.com
- **Database Help:** See migration guide above

---

**System Capacity:** 100,000 users
**Current Users:** Check admin dashboard
**Status:** ✅ Production Ready
