# Connect Fiyah Cloner to GoDaddy Domain

## Your Deployed Site
**Netlify URL:** https://same-vmbqldo1hik-latest.netlify.app

## Step-by-Step Guide to Connect Your GoDaddy Domain

### Step 1: Claim Your Netlify Deployment
1. Click the **"Deployed"** button on the top right of your Same workspace
2. Click **"Claim Deployment"** to connect this deployment to your Netlify account
3. This will allow you to manage the deployment and add custom domains

### Step 2: Add Custom Domain in Netlify
1. Once you've claimed the deployment, go to your Netlify dashboard
2. Select your Fiyah Cloner site
3. Go to **"Domain settings"** or **"Domain management"**
4. Click **"Add custom domain"**
5. Enter your GoDaddy domain (e.g., `fiyahcloner.com`)
6. Netlify will provide you with DNS records to configure

### Step 3: Configure DNS in GoDaddy
1. Log in to your **GoDaddy account**
2. Go to **"My Products"** → **"Domains"**
3. Find your domain and click **"DNS"** or **"Manage DNS"**
4. Configure the following DNS records:

#### For Apex Domain (fiyahcloner.com):
- **Type:** A Record
- **Name:** @ (or leave blank)
- **Value:** `75.2.60.5` (Netlify's load balancer IP)
- **TTL:** 600 (or default)

#### For WWW Subdomain (www.fiyahcloner.com):
- **Type:** CNAME Record
- **Name:** www
- **Value:** `same-vmbqldo1hik-latest.netlify.app`
- **TTL:** 600 (or default)

### Step 4: Enable HTTPS (SSL)
1. Back in Netlify, go to **"Domain settings"**
2. Scroll to **"HTTPS"** section
3. Click **"Verify DNS configuration"**
4. Once verified, click **"Provision certificate"**
5. Wait for SSL certificate to be issued (usually takes a few minutes)

### Step 5: Wait for DNS Propagation
- DNS changes can take anywhere from 5 minutes to 48 hours to fully propagate
- You can check propagation status at: https://www.whatsmydns.net/

## Alternative: Using Netlify DNS (Recommended)
For easier management, you can transfer your DNS to Netlify:

1. In GoDaddy, get your domain's **authorization code**
2. In Netlify, go to **"Domain settings"** → **"Netlify DNS"**
3. Follow the prompts to set up Netlify DNS
4. Update your nameservers in GoDaddy to Netlify's nameservers:
   - `dns1.p01.nsone.net`
   - `dns2.p01.nsone.net`
   - `dns3.p01.nsone.net`
   - `dns4.p01.nsone.net`

## Verification
Once DNS is configured:
1. Visit your domain in a browser
2. You should see the Fiyah Cloner website
3. Verify HTTPS is working (padlock icon in browser)

## Troubleshooting
- **Domain not loading:** Wait longer for DNS propagation
- **SSL not working:** Make sure DNS is properly configured and verified in Netlify
- **404 errors:** Ensure the custom domain is added correctly in Netlify

## Support
- **Netlify Support:** https://www.netlify.com/support/
- **GoDaddy Support:** https://www.godaddy.com/help
- **Same Support:** support@same.new

---

**Note:** The current deployment is managed by Same. After claiming it in Netlify, you'll have full control over domain management and deployment settings.
