# 🚀 COMPLETE GODADDY DEPLOYMENT GUIDE

**Project:** Fiyah Cloner
**Date:** October 24, 2025
**For:** Sean Thompson

---

## 📋 TABLE OF CONTENTS

1. [Pre-Deployment Checklist](#pre-deployment-checklist)
2. [Download Your Application](#download-application)
3. [GoDaddy Hosting Setup](#godaddy-hosting-setup)
4. [Deployment Methods](#deployment-methods)
5. [Environment Configuration](#environment-configuration)
6. [Domain Setup](#domain-setup)
7. [SSL Certificate](#ssl-certificate)
8. [Testing & Verification](#testing-verification)
9. [Troubleshooting](#troubleshooting)

---

## ✅ PRE-DEPLOYMENT CHECKLIST

Before deploying to GoDaddy, ensure:

- [x] ✅ All backend functions tested and working
- [x] ✅ Stripe keys configured in `.env.local`
- [x] ✅ Admin account credentials confirmed
- [x] ✅ Shopping cart functional
- [x] ✅ No linting errors
- [x] ✅ Application builds successfully
- [ ] ⚠️ Production Stripe keys ready (optional - can use test keys)
- [ ] ⚠️ Custom domain purchased (if needed)

---

## 📦 DOWNLOAD YOUR APPLICATION

### Method 1: Download from Same.new (Recommended)

1. **Click the Download Button:**
   - Look for the download icon in Same.new interface
   - Or use the file explorer to download the entire `fiyah-cloner` folder

2. **Files You'll Get:**
   ```
   fiyah-cloner/
   ├── src/              (Application code)
   ├── public/           (Static assets)
   ├── .env.local        (Environment variables)
   ├── package.json      (Dependencies)
   ├── next.config.js    (Next.js config)
   └── ...
   ```

### Method 2: Create ZIP Archive

Run this command in Same.new terminal:

```bash
cd /home/project
zip -r fiyah-cloner-deployment.zip fiyah-cloner/ \
  --exclude "fiyah-cloner/node_modules/*" \
  --exclude "fiyah-cloner/.next/*" \
  --exclude "fiyah-cloner/.same/*"
```

Then download `fiyah-cloner-deployment.zip`

---

## 🏠 GODADDY HOSTING SETUP

### Step 1: Choose the Right GoDaddy Plan

**For Next.js Applications, you need:**

#### Option A: GoDaddy Managed WordPress Hosting (NOT Suitable)
❌ **DO NOT USE** - WordPress hosting doesn't support Next.js

#### Option B: GoDaddy VPS (Virtual Private Server) - RECOMMENDED
✅ **BEST CHOICE** for Next.js applications

**Minimum Requirements:**
- 2 GB RAM (4 GB recommended)
- 2 CPU cores
- 40 GB SSD storage
- Root/SSH access
- Ubuntu 20.04 or 22.04

**Pricing:** ~$20-50/month

#### Option C: GoDaddy Dedicated Server
✅ **ENTERPRISE** - Best performance but expensive ($100+/month)

### Step 2: Purchase & Set Up VPS

1. **Go to GoDaddy:**
   - Visit: https://www.godaddy.com/hosting/vps-hosting
   - Select a VPS plan (Economy or Deluxe)

2. **Configure Server:**
   - Operating System: Ubuntu 22.04 LTS
   - Server Location: Nearest to your audience
   - Add-ons: None required (we'll set up manually)

3. **Complete Purchase**

4. **Access Server:**
   - Check your email for server credentials
   - IP Address: `xxx.xxx.xxx.xxx`
   - Username: Usually `root`
   - Password: Sent via email

---

## 🔧 DEPLOYMENT METHODS

### METHOD 1: Direct VPS Deployment (Recommended)

#### Step 1: Connect to Your Server

**On Mac/Linux:**
```bash
ssh root@your-server-ip
```

**On Windows:**
- Use PuTTY or Windows Terminal
- Download PuTTY: https://www.putty.org/

#### Step 2: Install Required Software

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20.x (LTS)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install Bun (faster than npm)
curl -fsSL https://bun.sh/install | bash
source ~/.bashrc

# Install PM2 (process manager)
npm install -g pm2

# Install Nginx (web server)
sudo apt install -y nginx

# Install Git (optional, for updates)
sudo apt install -y git
```

#### Step 3: Upload Your Application

**Option A: Using SCP (Secure Copy)**

From your local machine:
```bash
scp -r /path/to/fiyah-cloner root@your-server-ip:/var/www/
```

**Option B: Using SFTP**
- Use FileZilla: https://filezilla-project.org/
- Host: `sftp://your-server-ip`
- Username: `root`
- Password: Your VPS password
- Upload to: `/var/www/fiyah-cloner`

**Option C: Using Git**

On the server:
```bash
cd /var/www
git clone your-repository-url fiyah-cloner
```

#### Step 4: Install Dependencies & Build

```bash
cd /var/www/fiyah-cloner

# Install dependencies
bun install

# Build for production
bun run build
```

#### Step 5: Configure Environment Variables

```bash
# Create/edit .env.local
nano .env.local
```

Add your production settings:
```env
# Stripe Configuration
STRIPE_SECRET_KEY=sk_live_your_production_key_here

# Or use test keys for testing
STRIPE_SECRET_KEY=sk_test_51SLAHrPLTUnnpuk4XwDfNo8rESenqFE6xE0731ApH3EMw9GDLqqi7TKyP1OSADqVIIwPlLkDR3CfSkwsNdIBeHEy0027yCIRKp

# Add any other environment variables here
NODE_ENV=production
```

Save: `Ctrl+X`, then `Y`, then `Enter`

#### Step 6: Start Application with PM2

```bash
# Start the app
pm2 start bun --name "fiyah-cloner" -- run start

# Save PM2 configuration
pm2 save

# Set PM2 to start on boot
pm2 startup
# Follow the command it provides

# Check status
pm2 status
```

#### Step 7: Configure Nginx as Reverse Proxy

```bash
# Create Nginx configuration
sudo nano /etc/nginx/sites-available/fiyah-cloner
```

Add this configuration:
```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

**Enable the configuration:**
```bash
# Create symbolic link
sudo ln -s /etc/nginx/sites-available/fiyah-cloner /etc/nginx/sites-enabled/

# Remove default site
sudo rm /etc/nginx/sites-enabled/default

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

---

### METHOD 2: Using cPanel (If Available)

Some GoDaddy plans include cPanel. If yours does:

#### Step 1: Access cPanel
- Login to your GoDaddy account
- Go to "My Products"
- Click "cPanel Admin"

#### Step 2: Setup Node.js Application

1. **Find "Setup Node.js App"** in cPanel
2. **Create Application:**
   - Node.js version: 20.x
   - Application mode: Production
   - Application root: `fiyah-cloner`
   - Application URL: `your-domain.com`
   - Application startup file: `server.js`

3. **Upload Files:**
   - Use File Manager in cPanel
   - Navigate to application root
   - Upload your project files

4. **Install Dependencies:**
   - Open Terminal in cPanel
   - Run: `cd fiyah-cloner && bun install && bun run build`

5. **Restart Application** in Node.js App Manager

---

## 🌐 DOMAIN SETUP

### If You Have a Custom Domain

#### Step 1: Point Domain to VPS

1. **Login to GoDaddy Domain Manager:**
   - Go to: https://dcc.godaddy.com/domains
   - Select your domain

2. **Update DNS Records:**

   **Add A Record:**
   ```
   Type: A
   Name: @
   Value: Your VPS IP Address
   TTL: 600 seconds
   ```

   **Add WWW Record:**
   ```
   Type: CNAME
   Name: www
   Value: @
   TTL: 600 seconds
   ```

3. **Wait for DNS Propagation:**
   - Usually takes 1-24 hours
   - Check status: https://www.whatsmydns.net/

#### Step 2: Update Nginx Configuration

Edit your Nginx config:
```bash
sudo nano /etc/nginx/sites-available/fiyah-cloner
```

Replace `your-domain.com` with your actual domain:
```nginx
server_name youractual domain.com www.youractualdomain.com;
```

Restart Nginx:
```bash
sudo systemctl restart nginx
```

---

## 🔒 SSL CERTIFICATE (HTTPS)

### Free SSL with Let's Encrypt

#### Step 1: Install Certbot

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx
```

#### Step 2: Get SSL Certificate

```bash
# Get certificate (replace with your domain)
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

Follow the prompts:
- Email: `sean.federaldirectfunding@gmail.com`
- Agree to terms: Yes
- Redirect HTTP to HTTPS: Yes (recommended)

#### Step 3: Auto-Renewal

```bash
# Test renewal
sudo certbot renew --dry-run

# Certificate will auto-renew every 90 days
```

Your site is now accessible via HTTPS! 🔒

---

## 🔧 ENVIRONMENT CONFIGURATION

### Update Stripe for Production

1. **Get Production Keys:**
   - Login to Stripe: https://dashboard.stripe.com/
   - Switch to "Production" mode (toggle in top-left)
   - Go to Developers → API Keys
   - Copy both keys

2. **Update .env.local:**
```bash
nano /var/www/fiyah-cloner/.env.local
```

```env
# Production Stripe Keys
STRIPE_SECRET_KEY=sk_live_your_real_production_key
STRIPE_PUBLISHABLE_KEY=pk_live_your_real_production_key

NODE_ENV=production
```

3. **Update Frontend:**

Edit `src/app/checkout/page.tsx` or wherever Stripe publishable key is used:
```typescript
const stripePromise = loadStripe('pk_live_your_real_production_key');
```

4. **Restart Application:**
```bash
pm2 restart fiyah-cloner
```

---

## ✅ TESTING & VERIFICATION

### Step 1: Check Server Status

```bash
# Check if app is running
pm2 status

# Check logs
pm2 logs fiyah-cloner

# Check Nginx
sudo systemctl status nginx
```

### Step 2: Test Website

1. **Visit Your Domain:**
   - HTTP: `http://your-domain.com`
   - HTTPS: `https://your-domain.com`

2. **Test All Features:**
   - ✅ Homepage loads
   - ✅ Login with admin credentials
   - ✅ Signup new tenant account
   - ✅ Add items to cart
   - ✅ Checkout with Stripe (test mode first!)
   - ✅ All 22 expert tools work
   - ✅ Responsive design on mobile

### Step 3: Monitor Performance

```bash
# Watch server resources
htop

# Monitor application logs
pm2 logs fiyah-cloner --lines 100

# Check Nginx logs
sudo tail -f /var/log/nginx/error.log
```

---

## 🐛 TROUBLESHOOTING

### Issue 1: Application Won't Start

**Check:**
```bash
# View detailed logs
pm2 logs fiyah-cloner

# Check port availability
sudo lsof -i :3000

# Restart app
pm2 restart fiyah-cloner
```

### Issue 2: "502 Bad Gateway"

**Solutions:**
```bash
# Check if app is running
pm2 status

# Restart app
pm2 restart fiyah-cloner

# Check Nginx config
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

### Issue 3: Stripe Not Working

**Verify:**
1. Environment variables set correctly
2. Stripe keys are for the right mode (test/production)
3. Domain is whitelisted in Stripe dashboard
4. SSL is working (required for production)

### Issue 4: Domain Not Resolving

**Check:**
```bash
# Test DNS
nslookup your-domain.com

# Ping server
ping your-domain.com

# Check DNS propagation
# Visit: https://www.whatsmydns.net/
```

### Issue 5: Permission Errors

```bash
# Fix file permissions
sudo chown -R www-data:www-data /var/www/fiyah-cloner

# Fix executable permissions
chmod +x /var/www/fiyah-cloner/server.js
```

---

## 📊 MONITORING & MAINTENANCE

### Daily Monitoring

```bash
# Check application status
pm2 status

# View recent logs
pm2 logs --lines 50

# Check disk space
df -h

# Check memory
free -h
```

### Weekly Maintenance

```bash
# Update packages
sudo apt update && sudo apt upgrade -y

# Restart application
pm2 restart fiyah-cloner

# Clear old logs
pm2 flush
```

### Backups

```bash
# Create backup script
nano /root/backup.sh
```

Add:
```bash
#!/bin/bash
DATE=$(date +%Y-%m-%d)
tar -czf /root/backups/fiyah-cloner-$DATE.tar.gz /var/www/fiyah-cloner
find /root/backups -type f -mtime +30 -delete
```

Make executable:
```bash
chmod +x /root/backup.sh

# Add to crontab (daily at 2 AM)
crontab -e
```

Add line:
```
0 2 * * * /root/backup.sh
```

---

## 🎯 QUICK REFERENCE COMMANDS

### Application Management
```bash
# Start
pm2 start bun --name "fiyah-cloner" -- run start

# Stop
pm2 stop fiyah-cloner

# Restart
pm2 restart fiyah-cloner

# View logs
pm2 logs fiyah-cloner

# Check status
pm2 status
```

### Nginx Management
```bash
# Test config
sudo nginx -t

# Restart
sudo systemctl restart nginx

# Reload (no downtime)
sudo systemctl reload nginx

# Check status
sudo systemctl status nginx
```

### Server Management
```bash
# Reboot server
sudo reboot

# Check running services
sudo systemctl list-units --type=service

# Monitor resources
htop
```

---

## 📞 SUPPORT RESOURCES

### GoDaddy Support
- **Phone:** 480-505-8877
- **Chat:** https://www.godaddy.com/contact-us
- **Help:** https://www.godaddy.com/help

### Application Support
- **Developer:** AI Assistant via Same.new
- **Email:** sean.federaldirectfunding@gmail.com
- **Phone:** 201-640-4635

---

## ✅ DEPLOYMENT CHECKLIST

Use this checklist to ensure everything is configured:

### Server Setup
- [ ] VPS purchased and accessible
- [ ] Ubuntu installed
- [ ] SSH access working
- [ ] Node.js installed
- [ ] Bun installed
- [ ] PM2 installed
- [ ] Nginx installed

### Application Setup
- [ ] Files uploaded to server
- [ ] Dependencies installed
- [ ] Application built successfully
- [ ] Environment variables configured
- [ ] Application running via PM2
- [ ] PM2 set to start on boot

### Web Server Setup
- [ ] Nginx configured
- [ ] Domain pointed to server
- [ ] DNS records updated
- [ ] SSL certificate installed
- [ ] HTTPS working

### Testing
- [ ] Website accessible
- [ ] Admin login works
- [ ] Tenant signup works
- [ ] Shopping cart functional
- [ ] Stripe checkout works
- [ ] All pages load correctly
- [ ] Mobile responsive working

### Production Readiness
- [ ] Production Stripe keys configured
- [ ] Backups configured
- [ ] Monitoring in place
- [ ] Error logging active
- [ ] Security hardened

---

## 🚀 ALTERNATIVE DEPLOYMENT (Easier)

### If GoDaddy VPS is Too Complex:

#### Option 1: Vercel (Recommended - Easiest)

```bash
# Install Vercel CLI
npm install -g vercel

# Login
vercel login

# Deploy
cd fiyah-cloner
vercel --prod
```

**Advantages:**
- ✅ Free tier available
- ✅ Automatic SSL
- ✅ Global CDN
- ✅ Zero configuration
- ✅ Auto-scaling
- ✅ Easy domain setup

**Then connect your GoDaddy domain:**
1. Copy DNS records from Vercel dashboard
2. Add them in GoDaddy DNS manager

#### Option 2: Netlify

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login
netlify login

# Deploy
cd fiyah-cloner
netlify deploy --prod
```

#### Option 3: Same.new Deployment

Use the built-in Deploy button in Same.new!

---

## 📝 FINAL NOTES

1. **Start with Test Mode:** Deploy with Stripe test keys first to verify everything works

2. **Monitor Initially:** Watch logs closely for the first few days

3. **Regular Backups:** Set up automated backups immediately

4. **Security Updates:** Keep all software updated

5. **Scale as Needed:** Start with smaller VPS, upgrade when needed

---

**Your application is ready for deployment!** 🎉

Follow this guide step-by-step, and you'll have your Fiyah Cloner application running on GoDaddy in no time.

---

*Guide created: October 24, 2025*
*For: Sean Thompson*
*Project: Fiyah Cloner v57*
