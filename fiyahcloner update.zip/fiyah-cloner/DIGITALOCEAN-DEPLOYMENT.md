# DigitalOcean App Platform Deployment Guide

## Fixed Issues
✅ Removed `output: 'export'` from next.config.js (required for API routes)
✅ Updated start command to bind to 0.0.0.0 and use PORT env variable
✅ Created .do/app.yaml configuration file

## Deployment Methods

### Method 1: Deploy from GitHub (Recommended)

1. **Push your code to GitHub:**
   ```bash
   cd fiyah-cloner
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/fiyahcloner.git
   git push -u origin main
   ```

2. **Create App on DigitalOcean:**
   - Go to https://cloud.digitalocean.com/apps
   - Click "Create App"
   - Select "GitHub" as source
   - Authorize DigitalOcean to access your GitHub
   - Select your repository
   - Select the `main` branch

3. **Configure Build Settings:**
   - **Build Command:** `npm install && npm run build`
   - **Run Command:** `npm start`
   - **HTTP Port:** `3000`
   - **Environment Variables:**
     - `NODE_ENV` = `production`
     - `NEXTAUTH_URL` = `${APP_URL}` (auto-filled by DO)
     - `NEXTAUTH_SECRET` = your-secret-key (generate with: `openssl rand -base64 32`)
     - `STRIPE_SECRET_KEY` = your-stripe-secret-key
     - `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` = your-stripe-publishable-key

4. **Deploy:**
   - Click "Next" through the configuration
   - Choose your plan (Basic - $5/month recommended)
   - Click "Create Resources"
   - Wait 5-10 minutes for deployment

### Method 2: Deploy from ZIP (Direct Upload)

1. **Create deployment-ready ZIP:**
   - Download `fiyahcloner-digitalocean.zip` from this workspace
   - Extract it locally

2. **Push to GitHub:**
   - Follow step 1 from Method 1 above
   - Then continue with Method 1 steps 2-4

## Environment Variables Required

Set these in DigitalOcean App Platform settings:

```env
NODE_ENV=production
NEXTAUTH_URL=${APP_URL}
NEXTAUTH_SECRET=your-generated-secret
STRIPE_SECRET_KEY=sk_test_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
```

## Troubleshooting

### Error: "Couldn't find any pages or app directory"
**Fixed!** This was caused by `output: 'export'` in next.config.js. Now removed.

### Build fails with module errors
- Make sure all dependencies are in `package.json`
- DigitalOcean will run `npm install` automatically

### API routes return 404
- Ensure `output: 'export'` is NOT in next.config.js
- API routes require server-side rendering

### App crashes on startup
- Check Environment Variables are set correctly
- Check logs in DigitalOcean dashboard
- Ensure PORT binding is correct (now using ${PORT:-3000})

## Post-Deployment

1. **Custom Domain:**
   - Go to Settings > Domains
   - Add your domain
   - Update DNS records as shown

2. **SSL Certificate:**
   - Auto-enabled by DigitalOcean
   - No configuration needed

3. **Scaling:**
   - Go to Settings > Scale
   - Increase instances or instance size as needed

## Cost Estimate

- **Basic Plan:** $5/month (512MB RAM, 1 vCPU)
- **Professional:** $12/month (1GB RAM, 1 vCPU)
- **Custom domain:** Free
- **SSL:** Free
- **Bandwidth:** 40GB/month included

## Recommended Next Steps

1. Set up monitoring in DigitalOcean dashboard
2. Configure auto-deploy from GitHub
3. Set up staging environment
4. Configure database (if needed later)

## Support

- DigitalOcean Docs: https://docs.digitalocean.com/products/app-platform/
- Community: https://www.digitalocean.com/community/
