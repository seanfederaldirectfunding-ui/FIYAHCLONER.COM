// ============================================================================
// GENIUS AI - PERSONAL SECRETARY SYSTEM
// Voice Recognition | Text-to-Speech | Command Execution | Website Learning
// ============================================================================

class GeniusAI {
    constructor() {
        this.activeAssistants = 1000;
        this.isListening = false;
        this.recognition = null;
        this.synthesis = window.speechSynthesis;
        this.commands = [];
        this.websiteKnowledge = {};

        this.initializeVoiceRecognition();
        this.initializeEventListeners();
        this.updateWelcomeTime();
        this.loadKnowledge();
    }

    // ========================================================================
    // VOICE RECOGNITION SETUP
    // ========================================================================
    initializeVoiceRecognition() {
        try {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            if (SpeechRecognition) {
                this.recognition = new SpeechRecognition();
                this.recognition.continuous = false;
                this.recognition.interimResults = false;
                this.recognition.lang = 'en-US';

                this.recognition.onstart = () => {
                    this.isListening = true;
                    document.getElementById('voice-button').classList.add('listening');
                    document.getElementById('voice-wave').classList.add('active');
                    this.speak('I\'m listening');
                };

                this.recognition.onresult = (event) => {
                    const transcript = event.results[0][0].transcript;
                    this.processVoiceCommand(transcript);
                };

                this.recognition.onerror = (event) => {
                    console.error('Speech recognition error:', event.error);
                    this.stopListening();
                    if (event.error === 'no-speech') {
                        this.speak('I didn\'t hear anything. Please try again.');
                    } else {
                        this.speak('Sorry, I had trouble hearing you. Please try again.');
                    }
                };

                this.recognition.onend = () => {
                    this.stopListening();
                };
            } else {
                console.warn('Speech recognition not supported');
                Utils.showNotification('Voice commands not supported in this browser. Please use Chrome or Edge.', 'info');
            }
        } catch (error) {
            console.error('Voice recognition initialization error:', error);
        }
    }

    // ========================================================================
    // EVENT LISTENERS
    // ========================================================================
    initializeEventListeners() {
        // Voice button
        const voiceBtn = document.getElementById('voice-button');
        if (voiceBtn) {
            voiceBtn.addEventListener('click', () => this.toggleVoiceInput());
        }

        // Send button
        const sendBtn = document.getElementById('send-button');
        if (sendBtn) {
            sendBtn.addEventListener('click', () => this.sendTextMessage());
        }

        // Text input - Enter key
        const textInput = document.getElementById('text-input');
        if (textInput) {
            textInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.sendTextMessage();
                }
            });
        }
    }

    // ========================================================================
    // VOICE CONTROL
    // ========================================================================
    toggleVoiceInput() {
        if (!this.recognition) {
            Utils.showNotification('Voice recognition not available. Please type your command.', 'error');
            return;
        }

        if (this.isListening) {
            this.recognition.stop();
        } else {
            try {
                this.recognition.start();
            } catch (error) {
                console.error('Failed to start recognition:', error);
                Utils.showNotification('Please wait a moment before trying again', 'info');
            }
        }
    }

    stopListening() {
        this.isListening = false;
        document.getElementById('voice-button').classList.remove('listening');
        document.getElementById('voice-wave').classList.remove('active');
    }

    // ========================================================================
    // TEXT-TO-SPEECH
    // ========================================================================
    speak(text) {
        if (!this.synthesis) {
            console.warn('Speech synthesis not available');
            return;
        }

        // Cancel any ongoing speech
        this.synthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;

        // Try to use a female voice
        const voices = this.synthesis.getVoices();
        const femaleVoice = voices.find(voice =>
            voice.name.includes('Female') ||
            voice.name.includes('Samantha') ||
            voice.name.includes('Victoria') ||
            voice.name.includes('Google US English Female')
        );

        if (femaleVoice) {
            utterance.voice = femaleVoice;
        }

        utterance.onend = () => {
            console.log('Speech finished');
        };

        utterance.onerror = (error) => {
            console.error('Speech error:', error);
        };

        this.synthesis.speak(utterance);
    }

    // ========================================================================
    // MESSAGE HANDLING
    // ========================================================================
    sendTextMessage() {
        const input = document.getElementById('text-input');
        const message = input.value.trim();

        if (!message) return;

        this.addMessage(message, 'user');
        input.value = '';

        this.processCommand(message);
    }

    processVoiceCommand(transcript) {
        this.addMessage(transcript, 'user');
        this.processCommand(transcript);
    }

    addMessage(text, sender = 'ai') {
        const chatWindow = document.getElementById('chat-window');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;

        const time = new Date().toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit'
        });

        messageDiv.innerHTML = `
            <div class="message-avatar">${sender === 'ai' ? '🧠' : '👤'}</div>
            <div>
                <div class="message-content">
                    ${sender === 'ai' ? '<strong>GENIUS AI:</strong> ' : ''}${text}
                </div>
                <div class="message-time">${time}</div>
            </div>
        `;

        // Remove typing indicator if exists
        const typingIndicator = document.getElementById('typing-indicator');
        typingIndicator.classList.remove('active');

        chatWindow.appendChild(messageDiv);
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }

    showTyping() {
        const typingIndicator = document.getElementById('typing-indicator');
        typingIndicator.classList.add('active');
        const chatWindow = document.getElementById('chat-window');
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }

    hideTyping() {
        const typingIndicator = document.getElementById('typing-indicator');
        typingIndicator.classList.remove('active');
    }

    // ========================================================================
    // COMMAND PROCESSING
    // ========================================================================
    async processCommand(command) {
        this.showTyping();

        // Log command
        this.commands.push({
            command: command,
            timestamp: new Date().toISOString()
        });
        this.saveCommands();

        // Simulate processing delay
        await new Promise(resolve => setTimeout(resolve, 1000));

        const lowerCommand = command.toLowerCase();
        let response = '';
        let shouldSpeak = true;

        // WEBSITE LEARNING
        if (lowerCommand.includes('learn') && (lowerCommand.includes('website') || lowerCommand.includes('site') || lowerCommand.includes('page'))) {
            response = this.learnWebsite();
        }
        // PRICING CHECK
        else if (lowerCommand.includes('pricing') || lowerCommand.includes('price') || lowerCommand.includes('cost')) {
            response = this.checkPricing();
        }
        // CREATE PROJECT
        else if (lowerCommand.includes('create') && lowerCommand.includes('project')) {
            response = this.createProject();
        }
        // DEPLOY WEBSITE
        else if (lowerCommand.includes('deploy')) {
            response = this.deployWebsite();
        }
        // CHECK CART
        else if (lowerCommand.includes('cart') || lowerCommand.includes('shopping')) {
            response = this.checkCart();
        }
        // USER INFO
        else if (lowerCommand.includes('who am i') || lowerCommand.includes('my account') || lowerCommand.includes('user info')) {
            response = this.getUserInfo();
        }
        // LOGIN
        else if (lowerCommand.includes('log in') || lowerCommand.includes('sign in')) {
            response = 'Redirecting you to the login page...';
            setTimeout(() => window.location.href = 'login.html', 1500);
        }
        // DASHBOARD
        else if (lowerCommand.includes('dashboard') || lowerCommand.includes('home')) {
            response = 'Opening your dashboard...';
            setTimeout(() => window.location.href = 'dashboard.html', 1500);
        }
        // FTP DEPLOYMENT
        else if (lowerCommand.includes('ftp') || lowerCommand.includes('connect')) {
            response = 'Opening FTP deployment interface...';
            setTimeout(() => window.location.href = 'ftp-deploy.html', 1500);
        }
        // HELP
        else if (lowerCommand.includes('help') || lowerCommand.includes('what can you do')) {
            response = this.showHelp();
        }
        // TIME
        else if (lowerCommand.includes('time') || lowerCommand.includes('what time')) {
            response = `The current time is ${new Date().toLocaleTimeString()}`;
        }
        // DATE
        else if (lowerCommand.includes('date') || lowerCommand.includes('what day') || lowerCommand.includes('today')) {
            response = `Today is ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`;
        }
        // WEB SEARCH
        else if (lowerCommand.includes('search') || lowerCommand.includes('google')) {
            const searchTerm = command.replace(/search|google|for|the/gi, '').trim();
            response = `Searching for "${searchTerm}"...`;
            setTimeout(() => {
                window.open(`https://www.google.com/search?q=${encodeURIComponent(searchTerm)}`, '_blank');
            }, 1000);
        }
        // ASSISTANTS STATUS
        else if (lowerCommand.includes('assistant') || lowerCommand.includes('how many')) {
            response = `I currently have ${this.activeAssistants} AI assistants ready to help you with any task!`;
        }
        // OPEN WEBSITE
        else if (lowerCommand.includes('open') && (lowerCommand.includes('.com') || lowerCommand.includes('http'))) {
            const urlMatch = command.match(/(https?:\/\/[^\s]+|[a-zA-Z0-9-]+\.(com|net|org|io|co))/);
            if (urlMatch) {
                let url = urlMatch[0];
                if (!url.startsWith('http')) url = 'https://' + url;
                response = `Opening ${url}...`;
                setTimeout(() => window.open(url, '_blank'), 1000);
            }
        }
        // DEFAULT INTELLIGENT RESPONSE
        else {
            response = this.generateIntelligentResponse(command);
        }

        this.hideTyping();
        this.addMessage(response, 'ai');

        if (shouldSpeak) {
            this.speak(response);
        }
    }

    // ========================================================================
    // SPECIALIZED COMMANDS
    // ========================================================================
    learnWebsite() {
        const currentUrl = window.location.href;
        const domain = window.location.hostname;

        // Analyze current page
        const pageInfo = {
            url: currentUrl,
            title: document.title,
            links: document.querySelectorAll('a').length,
            forms: document.querySelectorAll('form').length,
            buttons: document.querySelectorAll('button').length,
            inputs: document.querySelectorAll('input').length,
            images: document.querySelectorAll('img').length,
            timestamp: new Date().toISOString()
        };

        // Get page structure
        const structure = {
            hasLogin: !!document.querySelector('a[href*="login"]'),
            hasRegister: !!document.querySelector('a[href*="register"]'),
            hasPricing: !!document.querySelector('a[href*="pricing"]'),
            hasDashboard: !!document.querySelector('a[href*="dashboard"]'),
            hasCart: !!document.querySelector('[class*="cart"]'),
            hasFTP: !!document.querySelector('a[href*="ftp"]')
        };

        this.websiteKnowledge[domain] = { pageInfo, structure };
        this.saveKnowledge();

        let response = `I've learned the Fiyah Cloner website! Here's what I found:\n\n`;
        response += `📊 Page Analysis:\n`;
        response += `• ${pageInfo.links} navigation links\n`;
        response += `• ${pageInfo.buttons} interactive buttons\n`;
        response += `• ${pageInfo.forms} forms available\n\n`;

        response += `🎯 Available Features:\n`;
        if (structure.hasLogin) response += `• Login system\n`;
        if (structure.hasRegister) response += `• User registration\n`;
        if (structure.hasPricing) response += `• Pricing page\n`;
        if (structure.hasDashboard) response += `• User dashboard\n`;
        if (structure.hasCart) response += `• Shopping cart\n`;
        if (structure.hasFTP) response += `• FTP deployment\n\n`;

        response += `I can now help you navigate and use any of these features. Just ask!`;

        return response;
    }

    checkPricing() {
        const pricingInfo = `Here are the available pricing tiers:\n\n`;
        const prices = [
            { name: 'Simple Website', price: '$25', desc: 'Perfect for basic sites' },
            { name: 'Functioning App', price: '$50', desc: 'Full web applications' },
            { name: 'Advanced App', price: '$100', desc: 'Complex systems' },
            { name: 'Website Migration', price: '$35', desc: 'Move existing sites' },
            { name: 'Custom Domain', price: '$15', desc: 'Domain setup' },
            { name: 'Monthly Maintenance', price: '$25/mo', desc: 'Ongoing support' }
        ];

        let response = pricingInfo;
        prices.forEach((item, index) => {
            response += `${index + 1}. ${item.name} - ${item.price}\n   ${item.desc}\n`;
        });

        response += `\nWould you like me to add any of these to your cart?`;
        return response;
    }

    createProject() {
        if (!auth.isLoggedIn()) {
            setTimeout(() => window.location.href = 'login.html', 2000);
            return 'You need to be logged in to create a project. Redirecting you to login...';
        }

        return 'I can help you create a new project! Please tell me:\n\n1. What type of project? (Website, App, or Advanced)\n2. Project name?\n3. Any special requirements?\n\nOr I can take you to the dashboard where you can create it manually.';
    }

    deployWebsite() {
        return 'I can help you deploy your website! I\'ll guide you through:\n\n1. FTP connection setup\n2. File preparation\n3. Upload process\n4. Domain configuration\n\nWould you like me to open the FTP deployment page for you?';
    }

    checkCart() {
        const itemCount = cart.getCount();
        const total = cart.getTotal();

        if (itemCount === 0) {
            return 'Your shopping cart is currently empty. Would you like me to show you the pricing options?';
        }

        const items = cart.getItems();
        let response = `You have ${itemCount} item${itemCount > 1 ? 's' : ''} in your cart:\n\n`;

        items.forEach(item => {
            response += `• ${item.name} - $${item.price} (Qty: ${item.quantity})\n`;
        });

        response += `\nTotal: $${total.toFixed(2)}\n\nWould you like to proceed to checkout?`;
        return response;
    }

    getUserInfo() {
        if (!auth.isLoggedIn()) {
            return 'You\'re not currently logged in. Would you like me to take you to the login page?';
        }

        const user = auth.getUser();
        let response = `Account Information:\n\n`;
        response += `👤 Name: ${user.name}\n`;
        response += `📧 Email: ${user.email}\n`;
        response += `🎭 Role: ${user.role === 'master' ? 'Administrator' : 'Tenant User'}\n`;
        response += `📅 Member since: ${new Date(user.createdAt).toLocaleDateString()}\n\n`;
        response += `Is there anything specific you'd like to update?`;

        return response;
    }

    showHelp() {
        return `I'm GENIUS AI, your personal secretary! I can help you with:\n\n` +
               `🎯 Website Navigation:\n` +
               `• "Learn this website" - I'll analyze and understand the site\n` +
               `• "Go to pricing" - Navigate to any page\n` +
               `• "Open dashboard" - Access your dashboard\n\n` +
               `🛒 Shopping:\n` +
               `• "Check cart" - View your cart items\n` +
               `• "Check pricing" - See all pricing options\n` +
               `• "Add [item] to cart" - Add items\n\n` +
               `💼 Tasks:\n` +
               `• "Create project" - Start a new project\n` +
               `• "Deploy website" - Deploy your site\n` +
               `• "Connect FTP" - Set up FTP connection\n\n` +
               `🔍 General:\n` +
               `• "Search for [term]" - Web search\n` +
               `• "What time is it?" - Current time\n` +
               `• "Open [website]" - Open any URL\n\n` +
               `Just speak naturally or type your command!`;
    }

    generateIntelligentResponse(command) {
        const responses = [
            `I understand you want help with "${command}". Let me assist you with that.`,
            `I've analyzed your request about "${command}". Here's what I can do for you...`,
            `Regarding "${command}" - I'm processing that request with my AI assistants.`,
            `I've assigned multiple AI agents to handle "${command}" for you.`
        ];

        let response = responses[Math.floor(Math.random() * responses.length)];
        response += `\n\nCould you provide more details about what you need? For example:\n`;
        response += `• What specific action do you want me to take?\n`;
        response += `• Is this related to creating, viewing, or managing something?\n`;
        response += `• Would you like me to navigate somewhere for you?\n\n`;
        response += `Type "help" to see all my capabilities!`;

        return response;
    }

    // ========================================================================
    // QUICK COMMANDS
    // ========================================================================
    executeQuickCommand(command) {
        const input = document.getElementById('text-input');
        input.value = command;
        this.sendTextMessage();
    }

    // ========================================================================
    // DATA PERSISTENCE
    // ========================================================================
    saveKnowledge() {
        localStorage.setItem('genius_knowledge', JSON.stringify(this.websiteKnowledge));
    }

    loadKnowledge() {
        const saved = localStorage.getItem('genius_knowledge');
        if (saved) {
            this.websiteKnowledge = JSON.parse(saved);
        }
    }

    saveCommands() {
        localStorage.setItem('genius_commands', JSON.stringify(this.commands));
    }

    updateWelcomeTime() {
        const timeElement = document.getElementById('welcome-time');
        if (timeElement) {
            const time = new Date().toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit'
            });
            timeElement.textContent = time;
        }
    }
}

// ============================================================================
// INITIALIZE GENIUS AI
// ============================================================================
let geniusAI;

document.addEventListener('DOMContentLoaded', () => {
    geniusAI = new GeniusAI();

    // Load voices for speech synthesis
    if (window.speechSynthesis) {
        window.speechSynthesis.onvoiceschanged = () => {
            window.speechSynthesis.getVoices();
        };
    }

    console.log('%c🧠 GENIUS AI Initialized!', 'color: #f97316; font-size: 16px; font-weight: bold;');
    console.log('%c1000 AI Assistants Ready', 'color: #10b981; font-size: 14px;');
});

// Export for global use
function executeQuickCommand(command) {
    if (geniusAI) {
        geniusAI.executeQuickCommand(command);
    }
}

window.geniusAI = geniusAI;
window.executeQuickCommand = executeQuickCommand;
