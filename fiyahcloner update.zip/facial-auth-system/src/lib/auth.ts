// Owner credentials
export const OWNER_USERNAME = 'Sthompson72';
export const OWNER_PASSWORD = 'Rasta4iva!';
export const OWNER_NAME = 'Sean A Thompson';

// Authorized emails for Sean A Thompson (kept for reference)
export const AUTHORIZED_EMAILS = [
  'sean@federaldirectfunding',
  'sean.federaldirectfunding@gmail.com',
  'fiyahtruth@gmail.com',
  'fiahtruth@gmail.com'
];

// Get stored password (allows for password changes)
export const getStoredPassword = (): string => {
  const storedPassword = localStorage.getItem('owner_password');
  return storedPassword || OWNER_PASSWORD;
};

// Update password
export const updatePassword = (newPassword: string): void => {
  localStorage.setItem('owner_password', newPassword);
};

// Verify username and password
export const verifyCredentials = (username: string, password: string): boolean => {
  const currentPassword = getStoredPassword();
  return username === OWNER_USERNAME && password === currentPassword;
};

export const getCurrentIP = async (): Promise<string> => {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    return data.ip;
  } catch {
    return 'unknown';
  }
};

// Session management
export const setSession = (username: string, ipAddress: string) => {
  const session = {
    username,
    ipAddress,
    timestamp: Date.now(),
    isOwner: username === OWNER_USERNAME
  };
  localStorage.setItem('auth_session', JSON.stringify(session));
  sessionStorage.setItem('auth_active', 'true');
};

export const getSession = () => {
  const session = localStorage.getItem('auth_session');
  const active = sessionStorage.getItem('auth_active');

  if (!session || !active) return null;
  return JSON.parse(session);
};

export const clearSession = () => {
  localStorage.removeItem('auth_session');
  sessionStorage.removeItem('auth_active');
};

export const isOwner = (): boolean => {
  const session = getSession();
  return session?.isOwner === true;
};
