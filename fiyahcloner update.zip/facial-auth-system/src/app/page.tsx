'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getSession } from '@/lib/auth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default function HomePage() {
  const router = useRouter();

  useEffect(() => {
    // Check if user has an active session
    const session = getSession();
    if (session) {
      router.push('/home');
    } else {
      // Go to login
      setTimeout(() => router.push('/login'), 2000);
    }
  }, [router]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-gray-900/80 border-gray-700 backdrop-blur">
        <CardHeader className="text-center">
          <CardTitle className="text-4xl font-bold text-white mb-4">
            Product Security System
          </CardTitle>
          <CardDescription className="text-gray-400 text-lg">
            Secure Authentication & Copy Protection
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          <div className="text-gray-300 space-y-3">
            <p className="text-xl">🔒 Protected by:</p>
            <ul className="space-y-2">
              <li>✓ Username & Password Authentication</li>
              <li>✓ IP Address Tracking</li>
              <li>✓ Secure Copy Protection</li>
              <li>✓ Access Control System</li>
            </ul>
          </div>
          <div className="pt-6">
            <div className="animate-pulse text-gray-400">
              Initializing security protocols...
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
