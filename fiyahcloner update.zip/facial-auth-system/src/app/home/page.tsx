'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { getSession, clearSession, OWNER_NAME } from '@/lib/auth';

export default function HomePage() {
  const router = useRouter();
  const [session, setSessionState] = useState<{ username: string; ipAddress: string; isOwner: boolean } | null>(null);

  useEffect(() => {
    const currentSession = getSession();
    if (!currentSession) {
      router.push('/login');
      return;
    }
    setSessionState(currentSession);
  }, [router]);

  const handleLogout = () => {
    clearSession();
    router.push('/login');
  };

  if (!session) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex items-center justify-center p-8">
      <div className="max-w-4xl w-full">
        <Card className="bg-gray-900/80 border-gray-700 backdrop-blur">
          <CardHeader className="text-center">
            <CardTitle className="text-5xl font-bold text-white mb-4">
              Welcome, {OWNER_NAME}
            </CardTitle>
            <CardDescription className="text-gray-400 text-xl">
              You are successfully logged in
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            {/* User Info */}
            <div className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border border-blue-700/50 rounded-lg p-6">
              <h3 className="text-2xl font-semibold text-white mb-4">Account Information</h3>
              <div className="space-y-3 text-lg">
                <p className="text-gray-300">
                  <span className="text-gray-400">Username:</span>{' '}
                  <span className="text-green-400 font-semibold">{session.username}</span>
                </p>
                <p className="text-gray-300">
                  <span className="text-gray-400">Status:</span>{' '}
                  <span className="text-yellow-400 font-semibold">Owner Account</span>
                </p>
                <p className="text-gray-300">
                  <span className="text-gray-400">IP Address:</span>{' '}
                  <span className="text-blue-400 font-semibold">{session.ipAddress}</span>
                </p>
              </div>
            </div>

            {/* Security Status */}
            <div className="bg-green-900/20 border border-green-700 rounded-lg p-6">
              <h3 className="text-2xl font-semibold text-white mb-4 flex items-center gap-2">
                <span className="text-3xl">🔒</span>
                Security Status
              </h3>
              <div className="space-y-2 text-gray-300">
                <p className="flex items-center gap-2">
                  <span className="text-green-400">✓</span> Authentication successful
                </p>
                <p className="flex items-center gap-2">
                  <span className="text-green-400">✓</span> Session active and secure
                </p>
                <p className="flex items-center gap-2">
                  <span className="text-green-400">✓</span> IP address tracked
                </p>
                <p className="flex items-center gap-2">
                  <span className="text-green-400">✓</span> Protected access enabled
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                onClick={() => router.push('/settings')}
                className="flex-1 h-14 text-lg"
                variant="outline"
              >
                Account Settings
              </Button>
              <Button
                onClick={handleLogout}
                className="flex-1 h-14 text-lg bg-red-600 hover:bg-red-700"
              >
                Logout
              </Button>
            </div>

            {/* Welcome Message */}
            <div className="text-center pt-4">
              <p className="text-gray-400 text-lg">
                Your account is secure and protected. You can manage your settings or logout anytime.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
