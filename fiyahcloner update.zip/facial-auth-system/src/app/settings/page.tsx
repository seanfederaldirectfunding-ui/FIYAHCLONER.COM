'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  getSession,
  verifyCredentials,
  updatePassword,
  OWNER_USERNAME,
  OWNER_NAME
} from '@/lib/auth';

export default function SettingsPage() {
  const router = useRouter();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const session = getSession();
    if (!session) {
      router.push('/login');
    }
  }, [router]);

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setIsLoading(true);

    try {
      // Verify current password
      if (!verifyCredentials(OWNER_USERNAME, currentPassword)) {
        setError('Current password is incorrect.');
        setIsLoading(false);
        return;
      }

      // Validate new password
      if (newPassword.length < 6) {
        setError('New password must be at least 6 characters long.');
        setIsLoading(false);
        return;
      }

      // Check if passwords match
      if (newPassword !== confirmPassword) {
        setError('New passwords do not match.');
        setIsLoading(false);
        return;
      }

      // Check if new password is different from current
      if (currentPassword === newPassword) {
        setError('New password must be different from current password.');
        setIsLoading(false);
        return;
      }

      // Update password
      updatePassword(newPassword);
      setSuccess('Password changed successfully! Please use your new password for future logins.');

      // Clear form
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setIsLoading(false);
    } catch (err) {
      setError('Failed to change password. Please try again.');
      setIsLoading(false);
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black p-8">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <Button onClick={() => router.push('/home')} variant="outline">
            ← Back to Home
          </Button>
        </div>

        <Card className="bg-gray-900/80 border-gray-700 backdrop-blur">
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-white">Account Settings</CardTitle>
            <CardDescription className="text-gray-400">
              {OWNER_NAME} - Security Settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {error && (
              <Alert variant="destructive" className="bg-red-900/50 border-red-700">
                <AlertDescription className="font-bold">{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="bg-green-900/50 border-green-700">
                <AlertDescription className="text-green-200">{success}</AlertDescription>
              </Alert>
            )}

            <div className="border-b border-gray-700 pb-4">
              <h3 className="text-xl font-semibold text-white mb-2">Account Information</h3>
              <div className="space-y-2 text-gray-300">
                <p><span className="text-gray-400">Username:</span> <span className="text-white font-medium">{OWNER_USERNAME}</span></p>
                <p><span className="text-gray-400">Owner:</span> <span className="text-white font-medium">{OWNER_NAME}</span></p>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-white mb-4">Change Password</h3>
              <form onSubmit={handlePasswordChange} className="space-y-4">
                <div>
                  <Label htmlFor="currentPassword" className="text-white">Current Password</Label>
                  <Input
                    id="currentPassword"
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="Enter your current password"
                    className="bg-gray-800 border-gray-700 text-white"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="newPassword" className="text-white">New Password</Label>
                  <Input
                    id="newPassword"
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter your new password (min 6 characters)"
                    className="bg-gray-800 border-gray-700 text-white"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="confirmPassword" className="text-white">Confirm New Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter your new password"
                    className="bg-gray-800 border-gray-700 text-white"
                    required
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? 'Changing Password...' : 'Change Password'}
                </Button>
              </form>
            </div>

            <div className="mt-6 p-4 bg-blue-900/20 border border-blue-700 rounded-lg">
              <h4 className="text-white font-semibold mb-2">Password Security Tips:</h4>
              <ul className="text-xs text-blue-200 space-y-1">
                <li>• Use at least 6 characters (longer is better)</li>
                <li>• Include uppercase and lowercase letters</li>
                <li>• Add numbers and special characters (!@#$%)</li>
                <li>• Don't use common words or personal information</li>
                <li>• Keep your password confidential</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
