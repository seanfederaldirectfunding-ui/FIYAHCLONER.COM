'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  verifyCredentials,
  setSession,
  getCurrentIP,
  OWNER_NAME
} from '@/lib/auth';

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      // Verify credentials
      if (!verifyCredentials(username, password)) {
        setError('ACCESS DENIED: Invalid username or password.');
        setIsLoading(false);
        return;
      }

      // Get IP address
      const ipAddress = await getCurrentIP();

      // Set session
      setSession(username, ipAddress);

      // Redirect to home page
      setTimeout(() => {
        router.push('/home');
      }, 500);
    } catch (err) {
      setError('Login failed. Please try again.');
      setIsLoading(false);
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-gray-900/80 border-gray-700 backdrop-blur">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-white">Secure Login</CardTitle>
          <CardDescription className="text-gray-400">
            Product Protection System - {OWNER_NAME}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-6 bg-red-900/50 border-red-700">
              <AlertDescription className="font-bold">{error}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="username" className="text-white">Username</Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                className="bg-gray-800 border-gray-700 text-white"
                required
              />
            </div>

            <div>
              <Label htmlFor="password" className="text-white">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="bg-gray-800 border-gray-700 text-white"
                required
              />
            </div>

            <Button
              type="submit"
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? 'Logging in...' : 'Login'}
            </Button>
          </form>

          <div className="mt-6 p-4 bg-blue-900/20 border border-blue-700 rounded-lg">
            <p className="text-xs text-blue-200 text-center">
              🔒 Secure access to protected products
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
