# Testing Guide - Product Security System

## 🎯 Testing Overview

This guide will walk you through testing all features of the system.

---

## Test 1: Login with Default Credentials

### Steps:
1. **Open the application** - You should see the login page
2. **Enter credentials:**
   - Username: `Sthompson72`
   - Password: `Rasta4iva!`
3. **Click "Login"**

### Expected Result:
✅ You should be redirected to the Dashboard
✅ You should see: "Logged in as: Sthompson72"
✅ You should see: "(Owner - Sean A Thompson)"
✅ Your IP address should be displayed

### If Login Fails:
❌ Check that you entered the credentials exactly:
   - Username is case-sensitive: `Sthompson72` (capital S)
   - Password includes special character: `Rasta4iva!` (capital R, number 4, exclamation mark)

---

## Test 2: Dashboard Access

### Once Logged In, You Should See:

#### Protected Products (3 items):
1. Financial Management System
2. Direct Funding Platform
3. Security Authentication Suite

**Each should have:**
- 🔒 Password Protected label
- "Copy/Download" button (green, enabled)

#### Public Products (2 items):
1. Public Template Library
2. Sample Dashboard

**Each should have:**
- 🔓 Open Access label
- "Copy/Download" button (enabled)

### Test Copy Protection:
1. **Click "Copy/Download" on any Protected Product**
   - ✅ Expected: File downloads successfully (JSON file)
   - ✅ Success message appears: "Successfully copied: [Product Name]"

2. **Click "Copy/Download" on any Public Product**
   - ✅ Expected: File downloads successfully

---

## Test 3: Access Settings Page

### Steps:
1. **From Dashboard**, locate the top-right buttons
2. **Click "Settings"** button

### Expected Result:
✅ You should be redirected to `/settings`
✅ Page title: "Account Settings"
✅ You should see:
   - Username: Sthompson72
   - Owner: Sean A Thompson
   - Password change form

---

## Test 4: Change Password

### Steps:
1. **Navigate to Settings** (from dashboard)
2. **Fill in the password change form:**
   - Current Password: `Rasta4iva!`
   - New Password: `NewSecurePass123!` (or your choice)
   - Confirm New Password: `NewSecurePass123!` (same as above)
3. **Click "Change Password"**

### Expected Result:
✅ Success message appears: "Password changed successfully! Please use your new password for future logins."
✅ Form fields are cleared
✅ No errors shown

### Test the New Password:
1. **Click "Back to Dashboard"**
2. **Click "Logout"**
3. **Try logging in with OLD password** (`Rasta4iva!`)
   - ❌ Expected: "ACCESS DENIED: Invalid username or password"
4. **Try logging in with NEW password** (`NewSecurePass123!`)
   - ✅ Expected: Login successful, redirected to dashboard

---

## Test 5: Password Validation

### Test Case 1: Wrong Current Password
1. Go to Settings
2. Enter wrong current password
3. Click "Change Password"
- ❌ Expected error: "Current password is incorrect."

### Test Case 2: Passwords Don't Match
1. Go to Settings
2. Current Password: (correct)
3. New Password: `Test123`
4. Confirm New Password: `Test456` (different)
5. Click "Change Password"
- ❌ Expected error: "New passwords do not match."

### Test Case 3: Password Too Short
1. Go to Settings
2. Current Password: (correct)
3. New Password: `abc`
4. Confirm New Password: `abc`
5. Click "Change Password"
- ❌ Expected error: "New password must be at least 6 characters long."

### Test Case 4: Same as Current Password
1. Go to Settings
2. Current Password: `Rasta4iva!`
3. New Password: `Rasta4iva!` (same)
4. Confirm New Password: `Rasta4iva!`
5. Click "Change Password"
- ❌ Expected error: "New password must be different from current password."

---

## Test 6: Session Management

### Test Session Persistence:
1. **Login** with your credentials
2. **Navigate** to Dashboard
3. **Refresh the page** (F5 or Cmd+R)
- ✅ Expected: You remain logged in
- ✅ Expected: Dashboard still displays

### Test Session Expiration:
1. **Login** with your credentials
2. **Close the browser tab**
3. **Open a new tab** and go to the app
- ✅ Expected: Redirected to login page
- ✅ Expected: Must login again

---

## Test 7: Unauthorized Access

### Test Accessing Dashboard Without Login:
1. **Logout** if logged in
2. **Manually navigate** to `/dashboard` in the URL
- ✅ Expected: Automatically redirected to `/login`

### Test Accessing Settings Without Login:
1. **Logout** if logged in
2. **Manually navigate** to `/settings` in the URL
- ✅ Expected: Automatically redirected to `/login`

---

## Test 8: IP Tracking

### Steps:
1. **Login** successfully
2. **Check Dashboard** header
3. **Look for IP address** display

### Expected Result:
✅ You should see: "IP: [your IP address]"
✅ IP should be a valid format (e.g., "203.0.113.1")
✅ If IP fetch fails, you should see: "IP: unknown"

---

## Test 9: Logout Functionality

### Steps:
1. **Login** successfully
2. **Navigate to Dashboard**
3. **Click "Logout"** button (top-right)

### Expected Result:
✅ Redirected to login page
✅ Session cleared
✅ Cannot access dashboard without logging in again

---

## Test 10: Copy Protection (Simulated Unauthorized User)

### Simulating an Unauthorized User:
Since we only have one account, we'll simulate this by:

1. **Open Developer Console** (F12 or Cmd+Option+I)
2. **Go to "Application" or "Storage" tab**
3. **Find localStorage**
4. **Delete the item**: `owner_password`
5. **Set a fake password**:
   ```javascript
   localStorage.setItem('owner_password', 'WrongPassword123')
   ```
6. **Refresh the page**
7. **Try to login** with `Rasta4iva!`
   - ❌ Expected: "ACCESS DENIED: Invalid username or password"
8. **Restore original password**:
   ```javascript
   localStorage.setItem('owner_password', 'Rasta4iva!')
   ```
9. **Login again** - Should work now

---

## Quick Testing Checklist

- [ ] Login with default credentials (Sthompson72 / Rasta4iva!)
- [ ] View dashboard and see all products
- [ ] Download a protected product
- [ ] Download a public product
- [ ] Access settings page
- [ ] Change password successfully
- [ ] Logout and login with new password
- [ ] Test password validation errors
- [ ] Verify session persistence on page refresh
- [ ] Verify session clears on browser close
- [ ] Test IP tracking display
- [ ] Test logout functionality

---

## Important Notes

### Default Credentials:
- **Username:** `Sthompson72`
- **Password:** `Rasta4iva!`

### After Changing Password:
- Remember your new password!
- Old password will no longer work
- Password is stored in browser localStorage
- Clearing browser data will reset password to default

### Resetting to Default Password:
If you forget your password:
1. Open Developer Console (F12)
2. Go to Application > localStorage
3. Delete the `owner_password` item
4. Refresh the page
5. Login with default password: `Rasta4iva!`

---

## Troubleshooting

### Can't Login:
- Check username is exactly: `Sthompson72`
- Check password is exactly: `Rasta4iva!` (or your new password if changed)
- Clear browser cache and try again
- Check for typos (case-sensitive)

### Can't Change Password:
- Ensure current password is correct
- Ensure new password is at least 6 characters
- Ensure new passwords match
- Ensure new password is different from current

### Products Not Downloading:
- Check that you're logged in
- Click the "Copy/Download" button
- Check browser's download folder
- Allow downloads in browser settings

---

**Happy Testing!** 🚀

If you encounter any issues not covered in this guide, check the browser console (F12) for error messages.
